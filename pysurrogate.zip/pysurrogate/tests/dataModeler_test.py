#!/usr/bin/python
import unittest
import pySurrogate as pySur
import numpy as np
import os
from time import localtime, asctime
import warnings
warnings.filterwarnings('error')

DM = pySur.DataModeler

class sinusoid_test(unittest.TestCase):

    def setUp(self):

        ################ Define the problem ##########
        def f(w, t):
            return np.sin(w*t)

        tMin = 0.
        tMax = 10.
        nDomain = 1000

        wMin = 1.
        wMax = 2.
        ##############################################

        self.times = np.linspace(tMin, tMax, nDomain)
        self.func = f
        self.wMin = wMin
        self.wMax = wMax

    def test_basic(self):
        dm = DM(self.times, 'sinusoid modeler')
        dm.setupEmpiricalInterpolants(basisTol=1.e-6)
        dm.setupFits(minVals = 1., maxVals=2.)
        ts = np.linspace(self.wMin, self.wMax, 10)
        for x in ts:
            data = self.func(x, self.times)
            dm.addKnownDataSet(np.array([x]), data)
        dm.createEmpiricalInterpolant()
        dm.fit(absTol=1.e-10) # Overfit for now

        # Test empirical interpolation
        for x in ts:
            data = self.func(x, self.times)
            ei_recon = dm.testEI(x, data)
            self.assertLess(max(abs(data - ei_recon)), 1.e-6)

        # Test full model with (over)fit
        for x in ts:
            data = self.func(x, self.times)
            recon = dm(np.array([x]))
            self.assertLess(max(abs(data - recon)), 1.e-6)

        # Test full model with reasonable fit
        dm.fit(absTol=1.e-2, bfTypes='polynomial')
        testSpace = np.linspace(self.wMin, self.wMax, 20)
        for x in testSpace:
            data = self.func(x, self.times)
            recon = dm(np.array([x]))
            self.assertLess(max(abs(data - recon)), 1.e-1)

        # Make sure we can save and load it
        dm.saveH5('test.h5')
        dm2 = DM(np.array([0., 1.]), "blah")
        dm2.loadH5('test.h5')
        for x in ts:
            recon1 = dm(np.array([x]))
            recon2 = dm2(np.array([x]))
            self.assertLess(max(abs(recon1 - recon2)), 1.e-12)

    def tearDown(self):
        if os.path.exists('test.h5'):
            os.remove('test.h5')

class complex_exponential_test(unittest.TestCase):

    def setUp(self):

        ################ Define the problem ##########
        def f(w, t):
            return np.exp(1.j*w*t)

        tMin = 0.
        tMax = 10.
        nDomain = 1000

        wMin = 1.
        wMax = 2.
        ##############################################

        self.times = np.linspace(tMin, tMax, nDomain)
        self.func = f
        self.wMin = wMin
        self.wMax = wMax

    def test_basic(self):
        dm = DM(self.times, 'complex exponential modeler')
        dm.setupEmpiricalInterpolants(basisTol=1.e-6)
        dm.setupFits(minVals = 1., maxVals=2.)
        ts = np.linspace(self.wMin, self.wMax, 10)
        for x in ts:
            data = self.func(x, self.times)
            dm.addKnownDataSet(np.array([x]), data)
        dm.createEmpiricalInterpolant()
        dm.fit(absTol=1.e-10) # Overfit for now

        # Test empirical interpolation
        for x in ts:
            data = self.func(x, self.times)
            ei_recon = dm.testEI(x, data)
            self.assertLess(max(abs(data - ei_recon)), 1.e-6)

        # Test full model with (over)fit
        for x in ts:
            data = self.func(x, self.times)
            recon = dm(np.array([x]))
            self.assertLess(max(abs(data - recon)), 1.e-6)

        # Test full model with reasonable fit
        dm.fit(absTol=1.e-2)
        testSpace = np.linspace(self.wMin, self.wMax, 20)
        for x in testSpace:
            data = self.func(x, self.times)
            recon = dm(np.array([x]))
            self.assertLess(max(abs(data - recon)), 1.e-1)

        # Make sure we can save and load it
        dm.saveH5('test.h5')
        dm2 = DM(np.array([0., 1.]), "blah")
        dm2.loadH5('test.h5')
        for x in ts:
            recon1 = dm(np.array([x]))
            recon2 = dm2(np.array([x]))
            self.assertLess(max(abs(recon1 - recon2)), 1.e-12)

    def test_misc_funcs(self):
        dm = DM(self.times, 'complex exp modeler')
        dm.setupEmpiricalInterpolants(storeRB=1)
        noDataEval = dm(np.array([3.]))
        self.assertEqual(np.shape(dm(np.array([3.]))), np.shape(self.times))
        self.assertEqual(max(abs(dm(np.array([3.])))), 0.)
        self.assertEqual(len(dm.nodeModelers), 0)
        testEval = dm.test(np.array([1.]), np.ones(len(self.times)))
        self.assertEqual(np.shape(testEval), (3, len(self.times)))
        testEval2 = dm.testEI(np.array([3.]), self.times)
        testEval3 = dm.testRB(np.array([4.]), np.zeros(len(self.times)))
        self.assertEqual(np.shape(testEval3), np.shape(self.times))
        self.assertEqual(max(abs(testEval3)), 0.)
        self.assertEqual(max(abs(dm.testErrors['Full']['xVals'] - np.array([[1.]]))), 0.)
        self.assertEqual(max(abs(dm.testErrors['EI']['xVals'] - np.array([[1.], [3.]]))), 0.)
        self.assertEqual(max(abs(dm.testErrors['RB']['xVals'] - np.array([[1.], [4.]]))), 0.)
        self.assertEqual(max(abs(dm.testErrors['EI']['LInf'][1] - np.array([max(abs(self.times))]))), 0.)
        self.assertEqual(max(abs(dm.testErrors['EI']['RMS'][1] - np.array([np.sqrt(np.mean(self.times**2.))]))), 0.)
        self.assertEqual(max(abs(dm.testErrors['EI']['maxErrVsDomain'] - np.amax(np.array([abs(self.times), np.ones(len(self.times))]), 0))), 0.)
        self.assertEqual(max(abs(dm.testErrors['EI']['rmsErrVsDomain'] - np.sqrt(0.5*self.times**2 + 0.5))), 0.)
        dm.clearCheckedErrors()
        self.assertEqual(np.shape(dm.testErrors['Full']['xVals']), np.shape(np.array([])))

    def tearDown(self):
        if os.path.exists('test.h5'):
            os.remove('test.h5')

class stupid_linear_test(unittest.TestCase):

    def setUp(self):

        ################ Define the problem ##########
        def f(w, t):
            return np.ones(len(t))

        tMin = 0.
        tMax = 10.
        nDomain = 1000

        wMin = 1.
        wMax = 2.
        ##############################################

        self.times = np.linspace(tMin, tMax, nDomain)
        self.func = f
        self.wMin = wMin
        self.wMax = wMax

    def test_basic(self):
        dm = DM(self.times, 'constant modeler')
        dm.setupEmpiricalInterpolants(basisTol=1.e-6)
        dm.setupFits(minVals = 1., maxVals=2.)
        ts = np.linspace(self.wMin, self.wMax, 10)
        for x in ts:
            data = self.func(x, self.times)
            dm.addKnownDataSet(np.array([x]), data)
        dm.createEmpiricalInterpolant()
        dm.fit(absTol=1.e-10) # Overfit for now

        # Test empirical interpolation
        for x in ts:
            data = self.func(x, self.times)
            ei_recon = dm.testEI(x, data)
            self.assertLess(max(abs(data - ei_recon)), 1.e-6)

        # Test full model with (over)fit
        for x in ts:
            data = self.func(x, self.times)
            recon = dm(np.array([x]))
            self.assertLess(max(abs(data - recon)), 1.e-6)

        # Test full model with reasonable fit
        dm.fit(absTol=1.e-2)
        testSpace = np.linspace(self.wMin, self.wMax, 20)
        for x in testSpace:
            data = self.func(x, self.times)
            recon = dm(np.array([x]))
            self.assertLess(max(abs(data - recon)), 1.e-1)

        # Make sure we can save and load it
        dm.saveH5('test.h5')
        dm2 = DM(np.array([0., 1.]), "blah")
        dm2.loadH5('test.h5')
        for x in ts:
            recon1 = dm(np.array([x]))
            recon2 = dm2(np.array([x]))
            self.assertLess(max(abs(recon1 - recon2)), 1.e-12)

    def tearDown(self):
        if os.path.exists('test.h5'):
            os.remove('test.h5')
  
def main():
    unittest.main(exit=False)
    stopTime = str(asctime(localtime()))
    print("Finished {} at {}".format(os.path.basename(__file__),stopTime))

if __name__ == '__main__':
    main()

