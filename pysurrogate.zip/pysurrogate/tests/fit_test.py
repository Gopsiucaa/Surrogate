#!/usr/bin/python
import unittest
import pySurrogate as pySur
import numpy as np
import os
from time import localtime, asctime
import warnings
warnings.filterwarnings('error')

fit = pySur.fit
fit_greedy = pySur.fit_greedy
evaluate_fit = pySur.evaluate_fit

class fit_test(unittest.TestCase):

    def test_basis_function(self):
        bf = evaluate_fit.basisFunction('polynomial', 2, -3., 1.)
        for x in np.linspace(-1., 1., 5):
            self.assertEqual(bf(x*2. - 1.), x**2.)

    def test_custom_basis_function(self):
        bf_instance = evaluate_fit.BasisFunction('cos',
            lambda n, x: np.cos(n*x), 0., np.pi)
        for x in np.linspace(0., np.pi, 5):
            self.assertEqual(bf_instance(3, x), np.cos(3*x))
        bf = bf_instance.mappedFunc(3, 0., 1.)
        for x in np.linspace(0., 1., 5):
            self.assertEqual(bf(x), np.cos(3.*np.pi*x))

    def checkCutoffs(self, xVals, yVals, fitOptions):
        def check(cutoff):
            fitOptions['absTol'] = cutoff
            result = fit.fitWrapper(xVals, yVals, **fitOptions)
            reconFunc = evaluate_fit.getFitEvaluator(result)
            reconVals = np.array([reconFunc(x) for x in xVals])
            maxErr = max(abs(reconVals - yVals))
            self.assertLess(maxErr, cutoff)
        for cutoff in [1.e-2, 1.e-6, 1.e-10]:
            check(cutoff)

    def test_edge_cases(self):
        self.checkCutoffs(np.array([[1.]]), np.array([0.]), {})

    def test_empty_fit(self):
        warnings.filterwarnings('ignore')
        result = fit.fitWrapper(np.array([]), np.array([]))
        warnings.filterwarnings('error')
        reconFunc = evaluate_fit.getFitEvaluator(result)
        self.assertEqual(reconFunc(np.array([0.])), 0.)

    def test_1d_polynomial(self):
        xVals = np.array([np.linspace(1., 3., 10)]).T
        yVals = np.sin(xVals.T[0])
        options = {
                    'minVals': 1.,
                    'maxVals': 3.,
                  }
        self.checkCutoffs(xVals, yVals, options)

    def test_1d_complex_polynomial(self):
        xVals = np.array([np.linspace(1., 3., 10)]).T
        yVals = np.exp(1.j*xVals.T[0])
        options = {
                    'minVals': 1.,
                    'maxVals': 3.,
                  }
        self.checkCutoffs(xVals, yVals, options)

    def test_1d_periodic(self):
        xVals = np.array([np.linspace(0., 2.*np.pi, 10)]).T
        yVals = np.sqrt(2. + np.sin(xVals.T[0]))
        options = {
                    'minVals': 0.,
                    'maxVals': 2.*np.pi,
                    'bfTypes': 'periodic',
                 }
        self.checkCutoffs(xVals, yVals, options)

    def test_1d_complex_periodic(self):
        xVals = np.array([np.linspace(0., 2.*np.pi, 10)]).T
        yVals = np.sqrt(2. + np.sin(xVals.T[0])) + 1.j*np.sqrt(3. + np.sin(xVals.T[0]))
        options = {
                    'minVals': 0.,
                    'maxVals': 2.*np.pi,
                    'bfTypes': 'complexPeriodic',
                 }
        self.checkCutoffs(xVals, yVals, options)

    def test_noise1d(self):
        def test(n):
            xVals = np.array([np.linspace(0., 1., n)]).T
            yVals = np.random.random(n)
            options = {
                    'minVals': 0.,
                    'maxVals': 1.
                    }
            self.checkCutoffs(xVals, yVals, options)
        for n in [3, 10, 27]:
            test(n)

    def test_getBFOrders(self):
        bfMaxOrders = [3, 2, 4]
        bfOrders = []
        for i in range(4):
            for j in range(3):
                for k in range(5):
                    bfOrders.append([i, j, k])
        test = fit_greedy.getBFOrders(bfMaxOrders)
        self.assertEqual(test, bfOrders)

def main():
    unittest.main(exit=False)
    stopTime = str(asctime(localtime()))
    print("Finished {} at {}".format(os.path.basename(__file__),stopTime))

if __name__ == '__main__':
    main()

