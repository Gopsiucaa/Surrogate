import numpy as np
from . import fit as fit_module
from .eval_pysur import evaluate_fit
from pySurrogate import SaveH5Object
import warnings
try:
    from sklearn import gaussian_process
except:
    print("No sklearn, cannot use gaussian_process in GPFunction")

def _nodeClass(nodeType):
    if nodeType == 'Fit':
        return FittedFunction
    elif nodeType == 'VectorFit':
        return VectorFittedFunction
    elif nodeType == 'GP':
        return GPFunction
    elif nodeType == 'None':
        return FunctionModeler
    else:
        raise ValueError("Unknown nodeType: %s"%nodeType)

class FunctionModeler(SaveH5Object):
    """
This is a base class to model a single real/complex function
of one or more parameters, given knowledge of the function at
various points in the domain.  Often used to fit empirical
interpolant node data.

Typically, we first add data with addKnownDataSet()
Then we call fit() to calibrate the model to the data
Finally, we can call the object to evaluate the model.
    """

    def __init__(self, name):

        SaveH5Object.__init__(self, name=name)

        self.xVals = np.array([])
        self.yVals = np.array([])
        self.checkedXVals = np.array([])
        self.checkedErrors = np.array([])
        self.addDataTests = []

    def __call__(self, x):
        raise NotImplementedError("Please override me.")

    def addKnownDataSet(self, newX, newY):
        if len(self.xVals)==0:
            self.xVals = np.array([newX])
            self.yVals = np.array([newY])
        else:
            matchIndices = np.where(np.all(newX==self.xVals, 1))[0]
            if len(matchIndices) > 0:
                raise ValueError("%s already has a data point at %s!"%(
                                 self.name, newX))
            self.xVals = np.append(self.xVals, np.array([newX]), 0)
            self.yVals = np.append(self.yVals, newY)

    def getDataSet(self, x):
        indices = np.where(np.all(self.xVals == x, axis=1))[0]
        if len(indices) == 0:
            warnings.warn('%s found no data for %s, returning zero.'%(
                    self.name, x))
            return 0.
        if len(indices) > 1:
            warnings.warn('%s found multiple data for %s.'%(
                    self.name, x))
        return self.yVals[indices[0]]

    def modifyDataPoint(self, index, newXVal, newYVal):
        self.xVals[index] = newXVal
        self.yVals[index] = newYVal

    def removeDataPoint(self, index):
        savedIndices = list(range(0, index)) + list(range(index+1, len(self.xVals)))
        self.xVals = self.xVals[savedIndices]
        self.yVals = self.yVals[savedIndices]

    def clearCheckedErrors(self, recursive=None):
        self.checkedXVals = np.array([])
        self.checkedErrors= np.array([])

    def fit(self, *args, **kwargs):
        """Calibrate the model to the known data"""
        raise NotImplementedError("Please override me.")

    def leaveSomeOutFit(self, xExcluded, *args, **kwargs):
        """Calibrate the model to the known data, excluding any
        xVals in the list xExcluded."""
        raise NotImplementedError("Please override me.")

    def _getFitInput(self, *args, **kwargs):
        """Return all data needed to perform a fit.
        Useful for doing many fits in parallel."""
        raise NotImplementedError("Please override me.")

    def _giveFitResults(self, result):
        """After fitting the data from self.getFitInput(),
        return the result with this function."""
        raise NotImplementedError("Please override me.")

    def _getLSOFitInput(self, xExcluded, *args, **kwargs):
        """Like getFitInput, but for leaveSomeOut fits.
        The regular giveFitResults function can be used to
        return the result."""
        raise NotImplementedError("Please override me.")

    def setupFits(self, **kwargs):
        """Set up model parameters (for example, the polynomial
        fit degree, tolerances, etc)"""
        raise NotImplementedError("Please override me.")

    def test(self, x, testData):
        """Use this rather than calling to evaluate the model
        when the true result is known.  Stores all checked points
        and errors as self.checkedXVals and self.checkedErrors."""
        prediction = self(x)
        err = np.array([abs(prediction - testData)])
        if len(self.checkedErrors)==0:
            self.checkedErrors = err
            self.checkedXVals = np.array([x])
        else:
            self.checkedErrors = np.append(self.checkedErrors, err)
            self.checkedXVals = np.append(self.checkedXVals, np.array([x]), 0)
        return prediction

##############################################################################
class FittedFunction(FunctionModeler):

    def __init__(self, name, **kwargs):
        FunctionModeler.__init__(self, name)

        self.fitOptions= {}
        self.fitResults = None

        self.evalFunc = None
        self.evalGPRErrorFunc = None
        self._doNotWriteToH5.append('evalFunc')
        self._doNotWriteToH5.append('evalGPRErrorFunc')

        self.setupFits(**kwargs)

    def __call__(self, x):
        if self.fitResults is None:
            raise Exception('Cannot call {} before fitting'.format(self.name))
        if (
                np.any(x > self.fitResults['maxVals']) or
                np.any(x < self.fitResults['minVals'])):
            warnings.warn('Params {} outside of fit range!'.format(x))
        return self.evalFunc(x)

    def fit(self, **kwargs):
        """Fits the known data."""
        kwargs = self._getFitInput(**kwargs)
        fitResults = fit_module.fitWrapper(**kwargs)
        self._giveFitResults(fitResults)

    def leaveSomeOutFit(self, xExcluded, **kwargs):
        kwargs = self._getLSOFitInput(xExcluded, **kwargs)
        fitResults = fit_module.fitWrapper(**kwargs)
        self._giveFitResults(fitResults)

    def _getFitInput(self, **kwargs):
        """For parallel fitting.  Calling
            _getFitInput
            <Fitting the input>
            _giveFitResults
        is equivalent to calling fit."""
        self.setupFits(**kwargs)
        opts = {
                "xVals": self.xVals,
                "yVals": self.yVals,
                "name": self.name,
                }
        opts.update(**self.fitOptions)
        return opts

    def _getLSOFitInput(self, xExcluded, **kwargs):
        self.setupFits(**kwargs)
        if len(xExcluded) == 0:
            warnings.warn("{} got no excluded values".format(self.name))

        indices = [i for i, x in enumerate(self.xVals) if not x in xExcluded]
        if len(indices) == len(self.xVals):
            warnings.warn("{} did not exclude any values".format(self.name))

        opts = {
                "xVals": self.xVals[indices],
                "yVals": self.yVals[indices],
                "name": self.name,
                }
        opts.update(**self.fitOptions)
        return opts

    def _giveFitResults(self, result):
        self.fitResults = result
        self._setupEvalFunc()
        if ('fitType' in list(self.fitResults.keys()) and \
            self.fitResults['fitType'] == 'GPR') or \
            ('fitType' in list(self.fitOptions.keys()) and \
            self.fitOptions['fitType'] == 'GPR'):

            self._setupGPRErrorEvalFunc()


    def setupFits(self, **kwargs):
        self.fitOptions.update(**kwargs)

    def _setupGPRErrorEvalFunc(self):
        self.evalGPRErrorFunc = evaluate_fit.getGPRErrorEvaluator(
            self.fitResults)

    def _setupEvalFunc(self):
        self.evalFunc = evaluate_fit.getFitEvaluator(self.fitResults)

    def _prepareForSubload(self, isFirst):
        self._setupEvalFunc()

##############################################################################
class GPFunction(FunctionModeler):

    def __init__(self, name, **kwargs):
        FunctionModeler.__init__(self, name)

        self.fitOptions = {
                "theta0": 1.e-2,
                "thetaL": 1.e-5,
                "thetaU": 1.e-0,
                "random_state": 0,
                }
        self.fitResults = None

        self.GP = None
        self._doNotWriteToH5.append('GP')

        self.setupFits(**kwargs)

    def __call__(self, x):
        if self.GP is None:
            raise Exception('Cannot call {} before fitting'.format(self.name))
        res = self.GP.predict(x.reshape(1, -1), eval_MSE=False)
        return res[0]

    def fit(self, **kwargs):
        """Fits the known data."""
        kwargs = self._getFitInput(**kwargs)
        gp = gaussian_process.GaussianProcess(**kwargs)
        res = gp.fit(self.xVals, self.yVals)
        self._giveFitResults(res)
        self.GP = gp

    def leaveSomeOutFit(self, xExcluded, **kwargs):
        kwargs = self._getLSOFitInput(xExcluded, **kwargs)
        gp = gaussian_process.GaussianProcess(**kwargs)
        indices = [i for i, x in enumerate(self.xVals) if not x in xExcluded]
        if len(indices) == len(self.xVals):
            warnings.warn("{} did not exclude any values".format(self.name))
        gp = gaussian_process.GaussianProcess(**kwargs)
        res = gp.fit(self.xVals[indices], self.yVals[indices])
        self._giveFitResults(res)
        self.GP = gp

    def _getFitInput(self, **kwargs):
        """For parallel fitting.  Calling
            _getFitInput
            <Fitting the input>
            _giveFitResults
        is equivalent to calling fit."""
        self.setupFits(**kwargs)
        opts = {
                }
        opts.update(**self.fitOptions)
        return opts

    def _getLSOFitInput(self, xExcluded, **kwargs):
        if len(xExcluded) == 0:
            warnings.warn("{} got no excluded values".format(self.name))
        return self._getFitInput(**kwargs)

    def _giveFitResults(self, result):
        pass

    def setupFits(self, **kwargs):
        self.fitOptions.update(**kwargs)

    def _setupEvalFunc(self):
        kwargs = self._getFitInput()
        gp = gaussian_process.GaussianProcess(**kwargs)
        res = gp.fit(self.xVals, self.yVals)
        self.GP = gp

    def _prepareForSubload(self, isFirst):
        self._setupEvalFunc()

##############################################################################
class VectorFittedFunction(FunctionModeler):

    def __init__(self, name, dim, component_type='Fit'):
        SaveH5Object.__init__(self, name)
        self.dim = dim
        self.component_type = component_type
        self.components = []
        self.components_fitResults = []
        self._doNotWriteToH5.append('components')
        for i in range(dim):
            cname = '%s_%s'%(name, i)
            c = _nodeClass(component_type)(cname)
            self.components.append(c)

    def __call__(self, x):
        return np.array([c(x) for c in self.components])

    def addKnownDataSet(self, newX, newY):
        for c, yc in zip(self.components, newY):
            c.addKnownDataSet(newX, yc)

    def getDataSet(self, x):
        return np.array([c.getDataSet(x) for c in self.components])

    def clearCheckedErrors(self, recursive=None):
        for c in self.components:
            c.clearCheckedErrors()

    def fit(self, *args, **kwargs):
        self.components_fitResults = []
        for c in self.components:
            c.fit(*args, **kwargs)
            self.components_fitResults.append(c.fitResults)

    def leaveSomeOutFit(self, xExcluded, *args, **kwargs):
        for c in self.components:
            c.leaveSomeOutFit(xExcluded, *args, **kwargs)

    def setupFits(self, **kwargs):
        for c in self.components:
            c.setupFits(**kwargs)

    def _prepareForSubload(self, isFirst):
        self.components = []
        for i in range(self.dim):
            cname = '%s_%s'%(self.name, i)
            c = _nodeClass(self.component_type)(cname)
            c._giveFitResults(self.components_fitResults[i])
            self.components.append(c)
