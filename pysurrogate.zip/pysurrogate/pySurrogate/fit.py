#!/usr/bin/python
import numpy as np
from math import pi, ceil
import warnings

from . import fit_gpr
from . import fit_greedy

############### The main fit function ########################################

def parallelFit(kwargs):

    # process-level seed
    np.random.seed(None)

    print('Starting %s fit with %s data points...'%(kwargs['name'],
            len(kwargs['xVals'])))
    res = fitWrapper(**kwargs)
    if 'fitType' in res and res['fitType'] == 'GPR':
        print('...done fitting %s'%(kwargs['name']))
    else:
        print('...got %s coefs for %s'%(len(res['coefs']), kwargs['name']))
    return res

def fitWrapper(xVals, yVals, name='Fit', **options):
    """
Fits data using greedy fitting or GPR fitting. Greedy fitting
also include cross validation fitting.

inputs:
-------
xVals: A 2d array of domain values, with shape (nPoints, dim).
yVals: A 1d array of real or complex values with shape (nPoints,).
name: An identifying string used in printed output/warnings/errors.

options:
-------
fitType: if 'GPR' will use GPR fitting, else will use greedy fitting.
See fit_greedy.greedy_fit_wrapper for options for greedy fitting.
See fit_gpr.gpr_fit_wrapper for options for GPR fitting.

returns:
--------
results

results: A dictionary containing all relevant fit information.
    Use evaluate_fit.getFitEvaluator(result) to get the fit function.
    """

    if 'fitType' in options and options['fitType'] == 'GPR':
        res = fit_gpr.gpr_fit_wrapper(xVals, yVals, name, **options)
    else:
        res = fit_greedy.greedy_fit_wrapper(xVals, yVals, name, **options)

    return res
