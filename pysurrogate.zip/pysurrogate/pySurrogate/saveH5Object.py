import os
import h5py
import numpy as np

def writeDict(f, d, skippedKeys=[]):
    for k, v in d.items():

        # The following restrictions on attribute key/vals allow us
        # to save None, dictionaries and lists in h5 format:
        if type(v) == str and v in ["NONE", "EMPTYARR"]:
            raise Exception("Key {} has invalid value %s".format(k, v))

        if k[:5] in ["DICT_", "LIST_"]:
            raise Exception("Key {} is invalid".format(k))

        if not k in skippedKeys:
            if v is None:
                f.create_dataset(k, data="NONE")
            elif type(v) == dict:
                g = f.create_group("DICT_%s"%(k))
                writeDict(g, v)
            elif type(v) == list:
                g = f.create_group("LIST_%s"%(k))
                writeDict(g, {str(i): vv for i, vv in enumerate(v)})
            elif type(v) == np.ndarray and len(v) == 0:
                f.create_dataset(k, data="EMPTYARR")
            elif type(v) is np.ndarray and type(v[0]) is np.str_:
                # Can't use fixed-length UTF-8 (yet?), must convert
                # See http://docs.h5py.org/en/stable/strings.html#compatibility
                f.create_dataset(k, data=v.astype(np.string_))
            else:
                f.create_dataset(k, data=v)

def readDict(f):
    d = {}
    for k, item in f.items():
        if type(item) == h5py._hl.dataset.Dataset:
            v = item[()]
            if type(v) == np.string_:
                v = str(v)
            elif type(v) == bytes:
                v = v.decode()
            if type(v) == str and v == "NONE":
                d[k] = None
            elif type(v) == str and v == "EMPTYARR":
                d[k] = np.array([])
            else:
                d[k] = v
        elif k[:5] == "DICT_":
            d[k[5:]] = readDict(item)
        elif k[:5] == "LIST_":
            tmpD = readDict(item)
            d[k[5:]] = [tmpD[str(i)] for i in range(len(tmpD))]
    return d

class SaveH5Object:
    """A base class which Enables hierarchical saving and loading of data."""

    # info.txt files indicate structure with white space:
    # MainGroup
    #   Subgroup1
    #     Subgroup1_property
    #   Subgroup2
    #     Subgroup2_property
    textOffsetIncrease = 2

    def __init__(self, name):
        """Names of different objects should be unique if they are
        subordinates of a common SaveH5Object."""
        self.name = name
        self._doNotWriteToH5 = []

    def iterH5Subordinates(self):
        """Iterates over all subordinate saveH5Objects."""
        # By default we have no subordinates.
        # Include 'yield' so python knows it's a generator
        return
        yield

    def __iter__(self):
        # We might as well include this by default.
        # It can of course be overridden with something more useful.
        return self.iterH5Subordinates()

    def __str__(self):
        return '%s: %s'%(self.__class__.__name__, self.name)

    def __repr__(self):
        s = '%s'%(self)
        for i, sub in enumerate(self.iterH5Subordinates()):
            if i==0:
                s += ':'
            lines = repr(sub).split('\n')
            for l in lines:
                s += '\n  ' + l
        return s

    def saveH5(self, h5FileName):
        """Save this object as a .h5 file.
        h5FileName must not exist.
        Use save(saveDirName) to get an extra human-readable .txt file
        with information about the object."""

        if os.path.exists(h5FileName):
            raise IOError("File {} already exists!".format(h5FileName))

        with h5py.File(h5FileName, 'w') as f:
            self._writeData(f)

    def save(self, saveDirName):
        """Save this object as a directory containing:
            info.txt: Text information about the object hierarchy
            data.h5: The object's data
        The directory must not currently exist."""

        if os.path.exists(saveDirName):
            raise IOError("Directory {} already exists!".format(saveDirName))

        os.mkdir(saveDirName)

        with open(saveDirName + '/info.txt', 'w') as f:
            self._writeInfo(f)

        self.saveH5(saveDirName + '/data.h5')

    def infoStrings(self):
        """Returns a list of strings to be included as lines in info.txt"""
        return []

    def _writeInfo(self, f, offset=0):
        offsetStr = ""
        for i in range(offset):
            offsetStr += " "

        f.write(offsetStr + self.__class__.__name__ + ": " + self.name + '\n')
        for tmp in self.infoStrings():
            f.write(offsetStr + tmp + "\n")

        for item in self.iterH5Subordinates():
            item._writeInfo(f, offset + self.textOffsetIncrease)

    def _writeData(self, f):
        writeDict(f, self.__dict__, skippedKeys=self._doNotWriteToH5)
        for item in self.iterH5Subordinates():
            g = f.create_group(item.name)
            item._writeData(g)

    def loadH5(self, h5FileName):
        """Loads an object saved with 'saveH5'"""

        with h5py.File(h5FileName, 'r') as f:
            self._loadData(f, isFirst=1)

    def load(self, loadDirName):
        """Loads an object saved with 'save'"""

        with open(loadDirName + '/info.txt', 'r') as f:
            classname = f.readline().split()[0][:-1]
            if not classname == self.__class__.__name__:
                raise Exception("Cannot load a {} as a {}."%(
                                    classname, self.__class__.__name__))

        self.loadH5(loadDirName + '/data.h5')

    def _loadData(self, f, isFirst=0):
        self.__dict__.update(readDict(f))

        self._prepareForSubload(isFirst)

        for item in self.iterH5Subordinates():
            g = f[item.name]
            item._loadData(g)

    # Objects may need to initiate other objects and/or do other preparations
    # before loading the data of other SaveH5Objects they contain
    def _prepareForSubload(self, isFirst):
        return

