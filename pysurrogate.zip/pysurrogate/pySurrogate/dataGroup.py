import os
import numpy as np
from pySurrogate.dataHolder import DataHolder
from pySurrogate.saveH5Object import SaveH5Object
from pySurrogate.fit import parallelFit
from pySurrogate.ei import parallelBuildEI
from multiprocessing import Pool
import h5py
import warnings

class DataGroup(DataHolder):
    """
This class is meant to be a surrogate model with more structure
than a DataModeler has - the data in this DataGroup will be
decomposed into possibly many DataModelers, other DataGroups and
even FittedFunctions.  A simple example would be to model a complex
function by splitting it into (magnitude, phase) functions and
modeling each of those with a DataModeler.  Instead of keeping around
two DataModelers and replicating commands, a single DataGroup will
automatically decompose and reconstruct all data and model predictions.
This becomes useful when the data is decomposed into many pieces.
    """

    def __init__(self, *args, **kwargs):
        """Either specify a location to load, or:
    domain - the domain of the output
    name - str
    storeData=False - store dataSets before decomposing them
    numericsHandler=None - generated automatically if none
        """
        if len(args) == 1 and type(args[0]) == str:
            self._init(np.arange(3), 'tmp')
            path = args[0]
            if os.path.isfile(path):
                self.loadH5(path)
            else:
                self.load(path)

        else:
            self._init(*args, **kwargs)

    def _init(self, domain, name, storeData=False, numericsHandler=None):

        DataHolder.__init__(self, domain, name, storeData=storeData,
                numericsHandler=numericsHandler)

        self.dataPieces = []
        self._doNotWriteToH5.append("dataPieces")

        self._decomposeSelf()

#-------- Custom methods that must be overridden ----------------------------#

    def _decomposeSelf(self):
        raise NotImplementedError("Please override me.")

    def decomposeData(self, data):
        raise NotImplementedError("Please override me.")

    def combineData(self, pieces):
        raise NotImplementedError("Please override me.")

    def errVsDomain(self, data, prediction):
        raise NotImplementedError("Please override me.")

#-------- Testing self and all subordinates ---------------------------------#

    def _get_sub_tests(self, x, testData, mode='full'):
        """
Helper function for test_components in case DataGroups need to
modify the output of their subordinates before continuing.
        """

        testPieces = self.decomposeData(testData)
        component_tests = []
        for i, tmp in enumerate(self):
            if hasattr(tmp, "test_components"):
                component_tests.append(tmp.test_components(x, testPieces[i], mode))
            else:
                if mode == 'null':
                    component_tests.append(0.*tmp(x))
                elif mode == 'full' or (not hasattr(tmp, "testEI")):
                    component_tests.append(tmp(x))
                elif mode == 'EI':
                    component_tests.append(tmp.testEI(x, testPieces[i]))
                elif mode == 'basis':
                    component_tests.append(tmp.testRB(x, testPieces[i]))
                else:
                    raise Exception("Bad mode: %s"%(mode))

        return testPieces, component_tests

    def test_components(self, x, testData, mode='full'):
        """
Decomposes the testData, replaces some component with the model evaluation,
then reassembles the data. Does this for all levels in the subordinate
hierarchy, as well as when replacing the full result and replacing nothing.
Returns a dictionary of evaluations labeled by the name of the replaced
element.
modes:
    'full': Replace the component with the model evaluation
    'EI': Replace the component with the EI evaluation
    'basis': Replace the component with the basis projection
    'null': Replace the component with zeros
        """
        testPieces, component_tests = self._get_sub_tests(x, testData, mode=mode)
        res = {}

        # Replacing self (all replaced)
        replaced_pieces = []
        for i, tmp in enumerate(self):
            piece = component_tests[i]
            if hasattr(tmp, "test_components"):
                piece = piece[tmp.name]
            replaced_pieces.append(piece)
        res[self.name] = self.combineData(replaced_pieces)

        # No replacements (tests reconstruction)
        reconstructed_pieces = []
        for i, tmp in enumerate(self):
            if hasattr(tmp, "test_components"):
                reconstructed_pieces.append(component_tests[i]['None'])
            else:
                reconstructed_pieces.append(testPieces[i])
        res['None'] = self.combineData(reconstructed_pieces)

        # Incorporate subordinate results
        tmp_pieces = [piece for piece in reconstructed_pieces]
        for i, tmp in enumerate(self):
            if hasattr(tmp, "test_components"):
                for k, v in component_tests[i].items():
                    if k != 'None':
                        tmp_pieces[i] = v
                        res[k] = self.combineData(tmp_pieces)
            else:
                tmp_pieces[i] = component_tests[i]
                res[tmp.name] = self.combineData(tmp_pieces)
            tmp_pieces[i] = reconstructed_pieces[i]
        return res

#-------- Overriding DataHolder ---------------------------------------------#

    def __call__(self, x):
        pieces = [tmp(x) for tmp in self]
        return self.combineData(pieces)

    def _testCall(self, x, testData, keys):
        testPieces = self.decomposeData(testData)
        pieces = [[] for _ in keys]
        for i, tmp in enumerate(self):
            if hasattr(tmp, "nNodes"):
                keyRes = tmp.test(x, testPieces[i], keys=keys)
                for j, r in enumerate(keyRes):
                    pieces[j].append(r)
            else:
                for j, key in enumerate(keys):
                    if key=='Full':
                        pieces[j].append(tmp.test(x, testPieces[i]))
                    else:
                        # When testing RB or EI, assume fits are perfect
                        pieces[j].append(testPieces[i])
        results = [self.combineData(p) for p in pieces]
        return results

    def iterH5Subordinates(self):
        for tmp in self.dataPieces:
            yield tmp

#-------- Manipulating data sets --------------------------------------------#

    def addKnownDataSet(self, newX, newData, addBasisData=True, tflag=0):
        """Decompose newData and add it.
        See self.addDecomposedDataSet."""
        pieces = self.fullDecomposition(newData)
        self.addDecomposedDataSet(newX, pieces, addBasisData, tflag)

    def addDecomposedDataSet(self, newX, pieces, addBasisData=True, tflag=0):
        """Add decomposed pieces corresponding to parameters newX.
        addBasisData: if false, only add FunctionModeler data for fits.
        tflag:  We first run self.addDataTest to determine if any pieces
                should not be added. If they should not be added:
                   -1 - raise Exception
                    0 - warn, do not add the piece (defult).
                    1 - silent, do not add the piece.
                    2 - warn, add the data anyway.
                    3 - silent, add the data anyway with 'fail' option.
                        Adds index to failed_test_indices of subordinates.
                    'fail' - Treat all pieces as failing, then set tflag to 3.
                (See self.addDataTest)"""

        pieces_passed = self.addDataTest(newX, pieces)
        if tflag == 'fail':
            pieces_passed = [0 for _ in pieces_passed]
            tflag = 3

        self._append_x(newX)
        for tmp, p, passed in zip(self.dataPieces, pieces, pieces_passed):
            new_flag = tflag
            if not passed:
                if tflag == 2 or tflag == 3:
                    new_flag = 'fail'
                    if tflag==2:
                        warnings.warn("Adding bad %s data at x=%s"%(
                                tmp.name, newX))
                    if hasattr(tmp, "failed_test_indices"):
                        tmp.failed_test_indices.append(len(tmp.xVals))
                    else:
                        tmp.failed_test_indices = [len(tmp.xVals)]
                elif tflag==1:
                    continue
                elif tflag==0:
                    warnings.warn("%s: Data failed test"%(tmp.name))
                    continue
                else:
                    raise Exception("Data for %s at x=%s failed test"%(
                            tmp.name, newX))

            if hasattr(tmp, "addDecomposedDataSet"):
                tmp.addDecomposedDataSet(newX, p, addBasisData, new_flag)
            elif hasattr(tmp, "EIOptions"):
                tmp.addKnownDataSet(newX, p, addBasisData)
            else:
                tmp.addKnownDataSet(newX, p)

    def addDataTest(self, newX, pieces):
        """By default, all pieces pass"""
        return [1 for _ in pieces]

    def fullDecomposition(self, data):
        pieces = self.decomposeData(data)
        for i, item in enumerate(self):
            if hasattr(item, 'fullDecomposition'):
                pieces[i] = item.fullDecomposition(pieces[i])
        return pieces

    def fullCombine(self, pieces):
        for i, item in enumerate(self):
            if hasattr(item, 'fullCombine'):
                pieces[i] = item.fullCombine(pieces[i])
        return self.combineData(pieces)

    def saveDecomposedData(self, pieces, filename):
        """Saves fully decomposed data as an h5 file."""

        if os.path.exists(filename):
            raise Exception("%s already exists!"%filename)

        with h5py.File(filename, 'w') as f:
            self._saveDecomposedData(pieces, f)

    def _saveDecomposedData(self, pieces, f):
        for i, item in enumerate(self):
            if hasattr(item, '_saveDecomposedData'):
                g = f.create_group(item.name)
                item._saveDecomposedData(pieces[i], g)
            else:
                f.create_dataset(item.name, data=pieces[i])

    def loadDecomposedData(self, filename):
        """Loads fully decomposed data from an h5 file."""

        with h5py.File(filename, 'r') as f:
            pieces = self._loadDecomposedData(f)

        return pieces

    def _loadDecomposedData(self, f):
        pieces = []
        for item in self:
            if hasattr(item, '_loadDecomposedData'):
                pieces.append(item._loadDecomposedData(f[item.name]))
            else:
                pieces.append(f[item.name][()])
        return pieces

    def getDataSet(self, x):
        if self.storeData:
            return DataHolder.getDataSet(self, x)
        else:
            return self.combineData([tmp.getDataSet(x) for tmp in self])

#--------- Empirical Interpolation ------------------------------------------#

    def nDataModelers(self):
        n = 0
        for tmp in self:
            if hasattr(tmp, "nDataModelers"):
                n += tmp.nDataModelers()
            elif hasattr(tmp, "_getEIInput"):
                n += 1
        return n

    def createEmpiricalInterpolant(self, nProcs=None, **kwargs):
        if nProcs is None:
            for tmp in self:
                if hasattr(tmp, 'createEmpiricalInterpolant'):
                    tmp.createEmpiricalInterpolant(**kwargs)
        else:
            inputs = self._getEIInput(**kwargs)
            print('Building %s RBs/EIs with %s procs...'%(
                len(inputs), nProcs))
            p = Pool(nProcs)
            results = p.map(parallelBuildEI, inputs)
            p.close()
            p.join()
            print('...done building empirical interpolants')
            self._giveEIResults(results)

    def createLSOEmpiricalInterpolant(self, xExcluded, nProcs=None, **kwargs):
        if nProcs is None:
            for tmp in self:
                if hasattr(tmp, 'createLSOEmpiricalInterpolant'):
                    tmp.createLSOEmpiricalInterpolant(xExcluded, **kwargs)
        else:
            inputs = self._getLSOEIInput(xExcluded, **kwargs)
            print('Building %s LSO RBs/EIs with %s procs...'%(
                len(inputs), nProcs))
            p = Pool(nProcs)
            results = p.map(parallelBuildEI, inputs)
            p.close()
            p.join()
            print('...done building empirical interpolants')
            self._giveEIResults(results)

    def _getEIInput(self, **kwargs):
        inputs = []
        for item in self:
            if hasattr(item, "nDataModelers"):
                inputs += item._getEIInput(**kwargs)
            elif hasattr(item, "_getEIInput"):
                inputs.append(item._getEIInput(**kwargs))
        return inputs

    def _getLSOEIInput(self, xExcluded, **kwargs):
        inputs = []
        for item in self:
            if hasattr(item, "nDataModelers"):
                inputs += item._getLSOEIInput(xExcluded, **kwargs)
            elif hasattr(item, "_getLSOEIInput"):
                inputs.append(item._getLSOEIInput(xExcluded, **kwargs))
        return inputs

    def _giveEIResults(self, manyResults):
        for item in self:
            if hasattr(item, "nDataModelers"):
                n = item.nDataModelers()
                item._giveEIResults(manyResults[:n])
                manyResults = manyResults[n:]
            elif hasattr(item, "_giveEIResults"):
                item._giveEIResults(manyResults[0])
                manyResults = manyResults[1:]
        if not len(manyResults) == 0:
            raise Exception('%s: Have leftover EI results'.format(self.name))

#--------- Fitting Nodes ----------------------------------------------------#

    def nNodes(self):
        n = 0
        for tmp in self:
            if hasattr(tmp, "nNodes"):
                n += tmp.nNodes()
            else:
                n += 1
        return n
        
    def fit(self, nProcs=1, **kwargs):
        if nProcs is None:
            for tmp in self:
                tmp.fit(**kwargs)
        else:
            inputs = self._getFitInput(**kwargs)
            print('Fitting %s functions with %s procs...'%(
                    len(inputs), nProcs))
            p = Pool(nProcs)
            results = p.map(parallelFit, inputs)
            p.close()
            p.join()
            print('...done fitting')
            self._giveFitResults(results)

    def leaveSomeOutFit(self, xExcluded, nProcs=1, **kwargs):
        if nProcs is None:
            for tmp in self:
                tmp.leaveSomeOutFit(xExcluded, **kwargs)
        else:
            inputs = self._getLSOFitInput(xExcluded, **kwargs)
            print('Fitting %s functions with %s procs...'%(
                    len(inputs), nProcs))
            p = Pool(nProcs)
            results = p.map(parallelFit, inputs)
            p.close()
            p.join()
            print('...done fitting')
            self._giveFitResults(results)

    def _getFitInput(self, **kwargs):
        inputs = []
        for item in self:
            if hasattr(item, "nNodes"):
                inputs += item._getFitInput(**kwargs)
            else:
                inputs.append(item._getFitInput(**kwargs))
        return inputs

    def _getLSOFitInput(self, xExcluded, **kwargs):
        inputs = []
        for item in self:
            if hasattr(item, "nNodes"):
                inputs += item._getLSOFitInput(xExcluded, **kwargs)
            else:
                inputs.append(item._getLSOFitInput(xExcluded, **kwargs))
        return inputs

    def _giveFitResults(self, manyResults):
        for item in self:
            if hasattr(item, "nNodes"):
                n = item.nNodes()
                item._giveFitResults(manyResults[:n])
                manyResults = manyResults[n:]
            else:
                item._giveFitResults(manyResults[0])
                manyResults = manyResults[1:]
        if not len(manyResults) == 0:
            raise Exception('%s: Have leftover fit results'.format(self.name))

    def infoStrings(self):
        s = ["DataGroup - " + self.__class__.__name__]
        return s

    def _prepareForSubload(self, isFirst):
        if isFirst:
            self._setupNH()
        self._doNotWriteToH5 = list(self._doNotWriteToH5)
        self.dataPieces = []
        self._decomposeSelf()
