#!/usr/bin/python
import unittest
import numpy as np
import pySurrogate as pySur
from time import localtime, asctime
import shutil
import os
import warnings
warnings.filterwarnings('error')

def rmdir(path):
    if os.path.exists(path):
        shutil.rmtree(path)

def rm(path):
    if os.path.exists(path):
        os.remove(path)

SaveH5Object = pySur.SaveH5Object

class DataHolder(SaveH5Object):
    def __init__(self, name, data):
        SaveH5Object.__init__(self, name)
        self.data = data

class HolderHolder(SaveH5Object):
    def __init__(self, name, things):
        SaveH5Object.__init__(self, name)
        self.subNames = np.array([t.name for t in things])
        self.things = things
        self._doNotWriteToH5.append('things')

    def iterH5Subordinates(self):
        for thing in self.things:
            yield thing

    def _prepareForSubload(self, isFirst):
        self.things = [DataHolder(name, -1) for name in self.subNames]

class h5Object_test(unittest.TestCase):

    def tearDown(self):
        rm('test.h5')
        rm('test2.h5')
        rm('testNone.h5')
        rm('testDict.h5')
        rm('testDict2.h5')
        rm('testEmptyList.h5')
        rm('testList.h5')
        rm('testEmptyArray.h5')
        rmdir('testDir')
        rmdir('testDir2')

    def test_simpleH5(self):
        dh = DataHolder('test', 3)
        dh.saveH5('test.h5')
        dh2 = DataHolder('recover', 2)
        dh2.loadH5('test.h5')
        self.assertEqual(dh2.data, 3)
        self.assertEqual(dh2.name, 'test')

    def test_simple(self):
        dh = DataHolder('test', 3)
        dh.save('testDir')
        dh2 = DataHolder('recover', 2)
        dh2.load('testDir')
        self.assertEqual(dh2.data, 3)
        self.assertEqual(dh2.name, 'test')

    def test_None(self):
        dh = DataHolder('test', None)
        dh.saveH5('testNone.h5')
        dh2 = DataHolder('recover', 2)
        dh2.loadH5('testNone.h5')
        self.assertIsNone(dh2.data)
        self.assertEqual(dh2.name, 'test')

    def test_dict(self):
        dh = DataHolder('test', {'a': 3, 'b': 'hello'})
        dh.saveH5('testDict.h5')
        dh2 = DataHolder('recover', 2)
        dh2.loadH5('testDict.h5')
        self.assertEqual(type(dh2.data), dict)
        self.assertEqual(len(dh2.data), len(dh.data))
        for k, v in dh.data.items():
            self.assertEqual(dh2.data[k], v)

    def test_nested_dict(self):
        dh = DataHolder('test', {
                'a': 3,
                'b': {
                    'aa': 9.2,
                    'bb': [1, 3, "hi"],
                    'cc': {'asdf': 1, 'asd': 0},
                    },
                'c': [1, "hi", {
                    'aaa': 3,
                    'bbb': [1, 'a'],
                    'ccc': {'a': 3, 'b': 2.3},
                    }]})
        dh.saveH5('testDict2.h5')
        dh2 = DataHolder('recover', 2)
        dh2.loadH5('testDict2.h5')
        self.assertEqual(type(dh2.data), dict)
        self.assertEqual(len(dh2.data), len(dh.data))
        for k, v in dh.data.items():
            self.assertEqual(dh2.data[k], v)

    def test_emptyList(self):
        dh = DataHolder('test', [])
        dh.saveH5('testEmptyList.h5')
        dh2 = DataHolder('recover', 2)
        dh2.loadH5('testEmptyList.h5')
        self.assertEqual(dh.data, [])

    def test_list(self):
        dh = DataHolder('test', [1., 'asdf', 3])
        dh.saveH5('testList.h5')
        dh2 = DataHolder('recover', 2)
        dh2.loadH5('testList.h5')
        self.assertEqual(dh.data, [1., 'asdf', 3])

    def test_emptyArray(self):
        dh = DataHolder('test', np.array([]))
        dh.saveH5('testEmptyArray.h5')
        dh2 = DataHolder('recover', 2)
        dh2.loadH5('testEmptyArray.h5')
        self.assertEqual(type(dh2.data), np.ndarray)
        self.assertEqual(dh.data.shape, (0,))

    def test_nestedH5(self):
        n = 3
        vals = list(range(n))
        names = ['thing%d'%i for i in range(n)]
        dhs = [DataHolder(names[i], vals[i]) for i in range(3)]
        hh = HolderHolder('testHolder', dhs)
        hh.saveH5('test2.h5')
        hh2 = HolderHolder('recover', [])
        hh2.loadH5('test2.h5')
        self.assertEqual(hh2.name, 'testHolder')
        self.assertEqual(len(hh2.things), n)
        for i, thing in enumerate(hh2):
            self.assertEqual(thing.name, dhs[i].name)
            self.assertEqual(thing.data, i)

    def test_nested(self):
        n = 3
        vals = list(range(n))
        names = ['thing%d'%i for i in range(n)]
        dhs = [DataHolder(names[i], vals[i]) for i in range(3)]
        hh = HolderHolder('testHolder', dhs)
        hh.save('testDir2')
        hh2 = HolderHolder('recover', [])
        hh2.load('testDir2')
        self.assertEqual(hh2.name, 'testHolder')
        self.assertEqual(len(hh2.things), n)
        for i, thing in enumerate(hh2):
            self.assertEqual(thing.name, dhs[i].name)
            self.assertEqual(thing.data, i)


def main():
    unittest.main(exit=False)
    stopTime = str(asctime(localtime()))
    print("Finished {} at {}".format(os.path.basename(__file__),stopTime))

if __name__ == '__main__':
    main()

