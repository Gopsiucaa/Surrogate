"""
A collection of regression tests. Each Jupyter notebook in the 
folder notebooks/ has a corresponding set of test(s). 

Regression data is stored in npz files.

It is assumed pytest is run from the top-level folder.
"""

from __future__ import division
import numpy as np
import os
import random

import pySurrogate as pySur
fit = pySur.fit
evalute_fit = pySur.evaluate_fit

# set global tolerances for floating point comparisons (see np.testing.assert_allclose)
atol = 0.0
rtol = 1.e-9 # some tests fail with 1e-11... should we be able to hit closer to 1e-15?


def test_1d_fits():
  """ Regression test of the following

  pySur.fit
  pySur.evaluate_fit

  Test taken from
    Notebook: fitting.ipynb
    Section: Simple 1-d polynomial fit example
    git hash: 3ecd20702f4042b1109d7bce7402dddf3f0c2963
  """

  def f(x):
    return np.sin(x)

  # Choose some data points - let's fit between 0 and 5:
  xMin = 0.
  xMax = 5.
  nPts = 10
  xVals = np.linspace(xMin, xMax, nPts)
  yVals = f(xVals)

  # fit expects each x value to be an array
  xVals = np.array([xVals]).T

  # Some fit options:
  options = {
            'minVals': xMin,
            'maxVals': xMax,
            'absTol': 1.e-2,
  }

  # Do the fits
  result = fit.fitWrapper(xVals, yVals, **options)

  # regresison test fit
  np.testing.assert_allclose(result["maxResids"][6],0.005352169211242042, rtol=rtol, atol=atol)
  np.testing.assert_allclose(result["bfOrders"][:,0],np.array([1, 2, 3, 4, 0, 5]), rtol=rtol, atol=atol)
  np.testing.assert_allclose(result["coefs"][5],-0.031451758582569385, rtol=rtol, atol=atol)

  # Get a function which evaluates the fit:
  fitFunc = evalute_fit.getFitEvaluator(result)

  # regresison test fit evaluation
  np.testing.assert_allclose(fitFunc(np.array([.1])),0.09451004179320316, rtol=rtol, atol=atol)


def test_2d_fits():
  """ Regression test of the following

  pySur.fit
  pySur.evaluate_fit

  Test taken from
    Notebook: fitting.ipynb
    Section:  2-d complex fit example using polynomials and complex exponentials
    git hash: 3ecd20702f4042b1109d7bce7402dddf3f0c2963
  """

  def f(x):
    x0, x1 = x
    return np.sqrt(2. + x0*x0 + np.sin(x1)) + 1.j*np.sqrt(3. + x0*x0 + np.cos(x1))

  # Choose some data points:
  xMin = np.array([0., 0.])
  xMax = np.array([3., 8.])
  ptsPerDim = 7
  xVals = np.array([[x1, x2] for x1 in np.linspace(xMin[0], xMax[0], ptsPerDim)
                           for x2 in np.linspace(xMin[1], xMax[1], ptsPerDim)])
  yVals = np.array(list(map(f, xVals)))

  # Use at most 6th degree basis functions in each dimension:
  bfMaxOrders = [6, 6]

  # Fit options:
  options = {
            'minVals': xMin,
            'maxVals': xMax,
            'absTol': 1.e-3,
            'bfMaxOrders': bfMaxOrders,
            }

  # Do the fit:
  result = fit.fitWrapper(xVals, yVals, **options)

  # regresison test fit
  bf_reg = np.array([[0, 0],[1, 0],[2, 0],[0, 3],[0, 2],[0, 4],[0, 5],\
    [3, 0],[1, 3],[1, 2],[1, 4],[0, 1],[1, 5],[0, 6],[4, 0],[1, 1],[3, 3],\
    [3, 2],[3, 4],[2, 2],[1, 6],[2, 4],[2, 3],[4, 3],[2, 5],[3, 5],[4, 2],
    [4, 4],[4, 5],[3, 1],[5, 0],[2, 1],[5, 2],[4, 1],[5, 3],[5, 4],[3, 6]])

  np.testing.assert_allclose(result["maxResids"][-1],0.0009448153371242912, rtol=rtol, atol=atol)
  np.testing.assert_allclose(result["bfOrders"],bf_reg, rtol=rtol, atol=atol)
  np.testing.assert_allclose(result["coefs"][-1],0.0008029405911706942+0.0002790934695401786*1.0j, rtol=rtol, atol=atol)

  # Get a function which evaluates the fit:
  fitFunc = evalute_fit.getFitEvaluator(result)

  # regresison test fit evaluation
  np.testing.assert_allclose(fitFunc([1., 1.0]),(1.9391634452398638+2.1435303896843596*1.0j), rtol=rtol, atol=atol)


def test_1d_fit_FittedFunction():
  """ Regression test of the following

  pySur.fit
  pySur.evaluate_fit

  Test taken from
    Notebook: fitting.ipynb
    Section: Simple 1-d polynomial fit example with FittedFunction object
    git hash: 3ecd20702f4042b1109d7bce7402dddf3f0c2963
  """


  def f(x):
    return np.sin(x)

  # Make a FittedFunction object and give it a name:
  ff = pySur.FittedFunction('1d-polynomial-fitter')

  # Choose some data points - let's fit between 0 and 5:
  xMin = 0.
  xMax = 5.
  nPts = 10

  # Add the data points to the FittedFunction:
  for x in np.linspace(xMin, xMax, nPts):
    ff.addKnownDataSet(np.array([x]), f(x))

  ff.setupFits(minVals=xMin, maxVals=xMax, absTol=1.e-2)

  # Do the fit:
  ff.fit()

  # regresison test fit evaluation
  np.testing.assert_allclose(ff([3.]),0.14079554627634785, rtol=rtol, atol=atol)


def test_spherical_ball_fit():
  """ Regression test of the following

  pySur.fit
  pySur.evaluate_fit

  Test taken from
    Notebook: fit_3d_spherical.ipynb
    Section: Spherical ball test case
    git hash: 7145a07207e10f929c41fcf2825dd1bbd39355a3
  """


  np.random.seed(0)
  random.seed(0)

  # Here is the exact solution (phi-independent)
  def f(x, y, z):
    r = np.sqrt(x*x + y*y + z*z)
    return 1.3 + .5*z + np.sin(r)*np.sqrt(1 + 3.*z*z)

  # Setup the parameter space
  rMax = 1.
  def rand_sph_params():
    r = np.random.random()*rMax
    theta = np.arccos(2*np.random.random() - 1.)
    phi = np.random.random()
    return r, theta, phi

  def x_y_z(r, theta, phi):
    return r*np.array([np.sin(theta)*np.cos(phi), np.sin(theta)*np.sin(phi), np.cos(theta)])

  def rand_params():
    r, theta, phi = rand_sph_params()
    return x_y_z(r, theta, phi)

  npts = 2000
  xVals = np.array([rand_sph_params() for _ in range(npts)])
  yVals = np.array([f(*x_y_z(*x)) for x in xVals])

  bf_cos = evalute_fit.BasisFunction('cos', lambda n, x: np.cos(n*x), 0., np.pi)
  evalute_fit.bf_dict['cos'] = bf_cos
  bfTypes = ['polynomial', 'cos', 'polynomial']

  minVals = np.array([-rMax, 0., 0.])
  maxVals = np.array([rMax, np.pi, 2.*np.pi])

  options = {
    'minVals': minVals,
    'maxVals': maxVals,
    'bfMaxOrders': [10, 10, 0],
    'absTol': 1.e-8,
    'bfTypes': bfTypes,
  }


  # TEST: fit without cross validation
  result = fit.fitWrapper(xVals, yVals, **options)

  # regresison test fit
  bf_reg_first_10 = np.array(([[ 0,  0,  0],[ 2,  0,  0],[ 0,  1,  0],\
    [ 0,  2,  0],[ 3,  2,  0],[ 2,  1,  0],[ 8,  0,  0],[ 0,  4,  0],\
    [ 1,  0,  0],[ 2,  4,  0]]))

  bf_reg_last_10 = np.array(([[ 7,  8,  0],[ 6,  3,  0],[ 7,  7,  0],\
    [ 7, 10,  0],[ 7,  4,  0],[ 7,  1,  0],[ 7,  2,  0],[ 7,  0,  0],\
    [ 8,  5,  0], [ 7,  6,  0]]))


  np.testing.assert_allclose(result["maxResids"][-1],9.143979598125185e-05, rtol=rtol, atol=atol)
  np.testing.assert_allclose(result["bfOrders"][:10],bf_reg_first_10, rtol=rtol, atol=atol)
  np.testing.assert_allclose(result["bfOrders"][111:],bf_reg_last_10, rtol=rtol, atol=atol)
  # bump up tolerance ... last coeff is expected to have lots of round-off error
  np.testing.assert_allclose(result["coefs"][-1],2.1094018416736735, rtol=1e-7, atol=atol)

  # TEST: fit with cross validation
  # NOTE: since CV calls the underlying fit routine, we don't need
  # as extensive testing -- rather just to check the "right" fit is found
  options = {
    'minVals': minVals,
    'maxVals': maxVals,
    'bfTypes': bfTypes,
    'bfMaxOrders': [10, 10, 0],
    'rmsCutoff': 'crossValidation',
    'cv_N': 100,
    'cv_nTrials': 10,
  }
  result_CV = fit.fitWrapper(xVals, yVals, **options)

  np.testing.assert_allclose(result_CV["maxResids"][-1],0.00010785605611175757, rtol=rtol, atol=atol)
  np.testing.assert_allclose(result_CV["coefs"][-1],-0.0006345746415784919, rtol=rtol, atol=atol)

def test_GPR_fit():
  """ Regression test of the following

  pySur.fit
  pySur.evaluate_fit

  Test taken from
  Notebook: GPR_fitting.ipynb
  Section: Simple 1-d GPR fit example
  git hash: 3ecd20702f4042b1109d7bce7402dddf3f0c2963
  """

  np.random.seed(0)

  # Exact solution
  def f(x):
    return x*np.sin(x)

  # The data can be noisy
  def apply_noise(data):
    noise_level = 0.1
    dy = noise_level * np.random.random(data.shape)
    noise = np.random.normal(0, dy)
    return data + noise

  # Choose some data points - let's fit between 1 and 8:
  xMin = 1
  xMax = 8
  nPts = 6
  xVals = np.linspace(xMin, xMax, nPts)
  yVals = apply_noise(f(xVals))

  # Setup a function modeler
  ff = pySur.FittedFunction('1d-polynomial-fitter')
  for x, y in zip(xVals, yVals):
    ff.addKnownDataSet(np.array([x]), y)

  # Setup GPR and do the fit
  ff.setupFits(minVals=[xMin], maxVals=[xMax], fitType='GPR')
  ff.fit()

  # regresison test fit evaluation
  np.testing.assert_allclose(ff([3.14]),0.021457876100102746, rtol=rtol, atol=atol)

  # regression test error estimation
  np.testing.assert_allclose(ff.evalGPRErrorFunc([3.14]),0.15529270563351616, rtol=rtol, atol=atol)

  # test save and reload
  ff.saveH5('GPR_regression_test.h5')
  ff = pySur.FittedFunction('1d-polynomial-fitter')
  ff.loadH5('GPR_regression_test.h5')
  np.testing.assert_allclose(ff([3.14]),0.021457876100102746, rtol=rtol, atol=atol)
  os.remove('GPR_regression_test.h5')

  # TODO: for some reason, the error estimator is saving or loading
  #np.testing.assert_allclose(ff.evalGPRErrorFunc([3.14]),0.15529270563351616, rtol=rtol, atol=atol)


def test_simple_surrogate():
  """ Regression test of the following

  pySur.DataModeler
  pySur.createEmpiricalInterpolant
  pySur.fit

  Test taken from
  Notebook: Surrogates.ipynb
  Section: Simple example of a parametrized complex exponential using a DataModeler
  git hash: 3ecd20702f4042b1109d7bce7402dddf3f0c2963
  """

  np.random.seed(0)
  random.seed(0)

  noiseLevel = 1.e-4

  def f(w, t):
    return np.exp(1.j*w*t) + noiseLevel*np.exp(1000.j*w*w*t)

  # Setup the domain
  tMin = 0.
  tMax = 10.
  nDomain = 10000
  times = np.linspace(tMin, tMax, nDomain)

  # Setup the training space
  wMin = 1.
  wMax = 2.
  nTS = 20
  ts = np.linspace(wMin, wMax, nTS)

  # Make a DataModeler object as our surrogate
  sur = pySur.DataModeler(times, "Complex exponential surrogate")

  # Add the data
  for w in ts:
    sur.addKnownDataSet(np.array([w]), f(w, times))
    
  # Build a reduced basis and empirical interpolant
  sur.createEmpiricalInterpolant(basisTol=noiseLevel*2)

  # Setup fits - these options will be remembered for all fits unless we override them
  sur.setupFits(minVals=wMin, maxVals=wMax, absTol=1.e-2)

  # Fit the data
  sur.fit()

  # regression tests
  np.testing.assert_allclose(sur(np.array([1.7171717]))[3],0.9999032082695891 + 1.0j*0.0051926307490798, rtol=rtol, atol=atol)

  # testing data
  validationSpace = np.linspace(wMin, wMax, nTS*10)
  for w in validationSpace:
    exact_sol = f(w, times)
    test_evals = sur.test(np.array([w]), exact_sol)

  np.testing.assert_allclose(sur.testErrors['EI']['LInf'][10],0.0006088976339456773, rtol=rtol, atol=atol)


def test_DataGroup_simple_surrogate():
  """ Regression test of the following

  pySur.DataModeler
  pySur.createEmpiricalInterpolant
  pySur.fit
  pySur.DataGroup

  Test taken from
  Notebook: Surrogates.ipynb
  Section: Simple example of a parametrized complex exponential using DataGroup to model the real/imaginary parts
  git hash: 3ecd20702f4042b1109d7bce7402dddf3f0c2963
  """

  np.random.seed(0)
  random.seed(0)

  # Setup the domain
  tMin = 0.
  tMax = 10.
  nDomain = 10000
  times = np.linspace(tMin, tMax, nDomain)

  # Setup the training space
  wMin = 1.
  wMax = 2.
  nTS = 20
  ts = np.linspace(wMin, wMax, nTS)

  validationSpace = np.linspace(wMin, wMax, nTS*10)

  noiseLevel = 1.e-4

  def f(w, t):
    return np.exp(1.j*w*t) + noiseLevel*np.exp(1000.j*w*w*t)


  # Setup the complex -> real/imag decomposition
  class reImDG(pySur.DataGroup):
    def _decomposeSelf(self):
      self.dataPieces.append(pySur.DataModeler(self.domain, self.name + '_re',
            numericsHandler=self.nh))
      self.dataPieces.append(pySur.DataModeler(self.domain, self.name + '_im',
            numericsHandler=self.nh))

    def decomposeData(self, data):
      return [np.real(data), np.imag(data)]

    def combineData(self, pieces):
      return pieces[0] + 1.j*pieces[1]

    def errVsDomain(self, data, prediction):
      return abs(data - prediction)

    # Let's also add a normalized L1 error:
    def clearCheckedErrors(self, recursive=1):
      pySur.DataGroup.clearCheckedErrors(self, recursive)
      for errType, errDict in self.testErrors.items():
        errDict['normL1'] = np.array([])

    def _recordErrors(self, x, data, prediction, key):
      pySur.dataHolder.DataHolder._recordErrors(self, x, data, prediction, key)
      err = np.sum(abs(data - prediction))/np.sum(abs(data))
      if len(self.testErrors[key]['normL1']) == 0:
        self.testErrors[key]['normL1'] = np.array([err])
      else:
        self.testErrors[key]['normL1'] = np.append(self.testErrors[key]['normL1'], err)

  # Make our surrogate a reImDG object:
  sur = reImDG(times, "re/im surrogate")

  # Add the data
  for w in ts:
    sur.addKnownDataSet(np.array([w]), f(w, times))
    
  # Build a reduced basis and empirical interpolant
  sur.createEmpiricalInterpolant(basisTol=noiseLevel*2)

  # Fit the data
  sur.fit(minVals=wMin, maxVals=wMax, absTol=1.e-2)

  # Check the surrogate
  for w in ts:
    exact_sol = f(w, times)
    test_evals = sur.test(np.array([w]), exact_sol)
  sur.clearCheckedErrors()  # tests that we can clear checked Errors
  for w in validationSpace:
    exact_sol = f(w, times)
    test_evals = sur.test(np.array([w]), exact_sol)

  # regression against validation errors
  np.testing.assert_allclose(np.max(sur.testErrors['EI']['LInf']),0.0011570231916687647, rtol=rtol, atol=atol)
  np.testing.assert_allclose(np.max(sur.testErrors['RB']['LInf']),0.0007421829884615361, rtol=rtol, atol=atol)
  np.testing.assert_allclose(np.max(sur.testErrors['Full']['LInf']),0.01631632618278929, rtol=rtol, atol=atol)


  # regression test for leave-on-out study using nProcs = 4
  np.random.seed(0)
  random.seed(0)

  w_excluded = np.array([ts[2]])
  sur.createLSOEmpiricalInterpolant([w_excluded], basisTol=noiseLevel*2, nProcs=4)

  np.random.seed(0)
  random.seed(0)

  sur.leaveSomeOutFit([w_excluded], minVals=wMin, maxVals=wMax, absTol=1.e-2, nProcs=4)

  for w in ts:
    if w != w_excluded[0]:
      sur_eval = sur.test(np.array([w]), f(w, times))
  np.testing.assert_allclose(np.max(sur.testErrors['Full']['RMS']),0.0065721189582189, rtol=rtol, atol=atol)

  sur.clearCheckedErrors()
  np.random.seed(0)
  random.seed(0)

  sur_evals = sur.test(w_excluded, f(w_excluded[0], times))
  tmp = np.max( np.abs(sur_evals[2] - f(w_excluded[0], times)) )
  np.testing.assert_allclose(tmp,0.0003243503682784, rtol=rtol, atol=atol)

  sur.clearCheckedErrors()
  np.random.seed(0)
  random.seed(0)

  sur_evals = sur.test(w_excluded, f(w_excluded[0], times))

  tmp = np.max( np.abs(sur_evals[1] - f(w_excluded[0], times)) )
  np.testing.assert_allclose(tmp,0.0005381721189171, rtol=rtol, atol=atol)



