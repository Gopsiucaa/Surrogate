#!/usr/bin/python
import unittest
import pySurrogate as pySur
import numpy as np
import os
from time import localtime, asctime
import warnings
warnings.filterwarnings('error')
DG = pySur.DataGroup
DM = pySur.DataModeler

class reImDG(DG):
    def _decomposeSelf(self):
        self.dataPieces.append(DM(self.domain, self.name + '_re',
                numericsHandler=self.nh))
        self.dataPieces.append(DM(self.domain, self.name + '_im',
                numericsHandler=self.nh))

    def decomposeData(self, data):
        return [np.real(data), np.imag(data)]

    def combineData(self, pieces):
        return pieces[0] + 1.j*pieces[1]

    def errVsDomain(self, data, prediction):
        return abs(data - prediction)

class ampPhaseDG(DG):
    def _decomposeSelf(self):
        self.dataPieces.append(DM(self.domain, self.name + '_amp',
                numericsHandler=self.nh))
        self.dataPieces.append(DM(self.domain, self.name + '_amp',
                numericsHandler=self.nh))

    def decomposeData(self, data):
        return [np.abs(data), np.unwrap(np.angle(data))]

    def combineData(self, pieces):
        return pieces[0]*np.exp(1.j*pieces[1])

    def errVsDomain(self, data, prediction):
        return abs(data - prediction)

class complex_exponential_test(unittest.TestCase):

    def setUp(self):

        ################ Define the problem ##########
        def f(w, t):
            return np.exp(1.j*w*t)

        tMin = 0.
        tMax = 10.
        nDomain = 1000

        wMin = 1.
        wMax = 2.
        ##############################################

        self.times = np.linspace(tMin, tMax, nDomain)
        self.func = f
        self.wMin = wMin
        self.wMax = wMax

    def test_reIm(self):
        dg = reImDG(self.times, 'complex exponential modeler')
        dg.setupEmpiricalInterpolants(basisTol=1.e-6)
        dg.setupFits(minVals = 1., maxVals=2.)
        ts = np.linspace(self.wMin, self.wMax, 10)
        for x in ts:
            data = self.func(x, self.times)
            dg.addKnownDataSet(np.array([x]), data)
        dg.createEmpiricalInterpolant()
        dg.fit(absTol=1.e-10) # Overfit for now

        # Test empirical interpolation
        for x in ts:
            data = self.func(x, self.times)
            ei_recon = dg.test(x, data, keys=["EI"])[0]
            self.assertLess(max(abs(data - ei_recon)), 1.e-5)

        # Test full model with (over)fit
        for x in ts:
            data = self.func(x, self.times)
            recon = dg(np.array([x]))
            self.assertLess(max(abs(data - recon)), 1.e-5)

        # Test full model with reasonable fit
        dg.fit(absTol=1.e-2, bfTypes='polynomial')
        testSpace = np.linspace(self.wMin, self.wMax, 20)
        for x in testSpace:
            data = self.func(x, self.times)
            recon = dg(np.array([x]))
            self.assertLess(max(abs(data - recon)), 1.e-1)

        # Make sure we can save and load it
        dg.saveH5('test.h5')
        dg2 = reImDG('test.h5')
        for x in ts:
            recon1 = dg(np.array([x]))
            recon2 = dg2(np.array([x]))
            self.assertLess(max(abs(recon1 - recon2)), 1.e-12)

        # Stress test?
        dg = reImDG(self.times, 'stress tester')
        dg.setupEmpiricalInterpolants(basisTol=1.e-6)
        dg.setupFits(minVals = 1., maxVals=3.)
        ts = np.linspace(1., 3., 500)
        for x in ts:
            data = self.func(x, self.times)
            dg.addKnownDataSet(np.array([x]), data)
        dg.createEmpiricalInterpolant(nProcs=4)
        dg.fit(absTol=1.e-3, maxCoefConst=20, nProcs=4)
        testSpace = np.linspace(self.wMin, self.wMax, 77)
        for x in testSpace:
            data = self.func(x, self.times)
            recon = dg(np.array([x]))
            self.assertLess(max(abs(data - recon)), 1.e-2)


    def test_ampPhase(self):
        dg = ampPhaseDG(self.times, 'complex exponential modeler')
        dg.setupEmpiricalInterpolants(basisTol=1.e-6)
        dg.setupFits(minVals = 1., maxVals=2.)
        ts = np.linspace(self.wMin, self.wMax, 10)
        for x in ts:
            data = self.func(x, self.times)
            dg.addKnownDataSet(np.array([x]), data)
        dg.createEmpiricalInterpolant()
        dg.fit(absTol=1.e-10) # Overfit for now

        # Test empirical interpolation
        for x in ts:
            data = self.func(x, self.times)
            ei_recon = dg.test(x, data, keys=["EI"])[0]
            self.assertLess(max(abs(data - ei_recon)), 1.e-5)

        # Test full model with (over)fit
        for x in ts:
            data = self.func(x, self.times)
            recon = dg(np.array([x]))
            self.assertLess(max(abs(data - recon)), 1.e-5)

        # Test full model with reasonable fit
        dg.fit(absTol=1.e-2)
        testSpace = np.linspace(self.wMin, self.wMax, 20)
        for x in testSpace:
            data = self.func(x, self.times)
            recon = dg(np.array([x]))
            self.assertLess(max(abs(data - recon)), 1.e-1)

    def tearDown(self):
        if os.path.exists('test.h5'):
            os.remove('test.h5')


def main():
    unittest.main(exit=False)
    stopTime = str(asctime(localtime()))
    print("Finished {} at {}".format(os.path.basename(__file__),stopTime))

if __name__ == '__main__':
    main()

