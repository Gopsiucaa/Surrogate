from multiprocessing import Pool, freeze_support
from pySurrogate.fit import parallelFit
def fit(self, nProcs=None, **kwargs):
        if nProcs is None:
            print('%s is fitting %s nodes'%(self.name, len(self.nodeModelers)))
            for nm in self:
                nm.fit(**kwargs)
        else:
            print('%s is fitting %s nodes with %s procs'%(
                    self.name, len(self.nodeModelers), nProcs))
            if __name__ == '__main__':
                freeze_support()
                inputs = [nm._getFitInput(**kwargs) for nm in self]
                p = Pool(nProcs)
                results = p.map(parallelFit, inputs)
                for nm, res in zip(self.nodeModelers, results):
                    nm._giveFitResults(res)