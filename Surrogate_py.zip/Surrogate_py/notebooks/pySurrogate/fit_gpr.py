#!/usr/bin/python
import numpy as np
import warnings
import scipy

from .eval_pysur import evaluate_fit

try:
    from sklearn import gaussian_process
    from sklearn.gaussian_process import GaussianProcessRegressor
    from sklearn.gaussian_process.kernels import RBF, ConstantKernel, \
        WhiteKernel, Matern, ExpSineSquared
    from sklearn import linear_model
except:
    print("No sklearn, cannot do GPR fits.")


GPR_DEFAULTS = {
        'fitType': 'GPR',
        'kernelType': 'RBF',    # Radial Basis Function
        'optimizer': 'fmin_l_bfgs_b',
        'optimizer_nTrials': 10,
        'doLinearFitBeforeGPR': True,
        'minVals': 0.,
        'maxVals': 1.,
        'noiseKernel_init': 1.e-4,
        'noiseKernel_bounds': (1.e-7, 1.e-2),
        'constKernel_init': 1.,
        'constKernel_bounds': (1e-2, 1e2),
        'lengthScale_bounds_factors': (1e-2, 1e1),
        'nu_Matern': 1.5,
}


OPTIMIZER_DICT = ['Nelder-Mead', 'Powell', 'CG', 'BFGS', 'Newton-CG', 'TNC',
    'COBYLA', 'SLSQP', 'dogleg', 'trust-ncg',]

# -------------------------------------------------------------------------
def optimizer_func(obj_func, initial_theta, bounds, opts_dict):
    """ Optimizer for GPR."""

    def obj_func_wrapper(theta):
        """ Wrapper for obj_func.
        Looks like minimize expects only obj_func[0],
        which is the function evaluation.
        We also implement the bounds using this wrapper.
        """
        outside_bounds = False
        for i in range(len(theta)):
            if theta[i] < bounds[i][0] or theta[i] > bounds[i][1]:
                outside_bounds = True

        #TODO: Check that the bounds are actually working
        if outside_bounds:
            return 1e100
        else:
            return obj_func(theta)[0]

    tol = 1e-7
    method = opts_dict['optimizer']
    res = scipy.optimize.minimize(obj_func_wrapper, initial_theta, \
        method=method, tol=tol)
    theta_opt = res.x
    func_min = res.fun
    return theta_opt, func_min


# ---------------------------------------------------------------------------
class GPRFitter:
    def __init__(self, xVals, yVals, name, **kwargs):
        """
        Class to construct and store GPR fits.
        """

        self.name = name
        self.xVals = xVals
        self.yVals = yVals
        self.doLinearFitBeforeGPR = kwargs['doLinearFitBeforeGPR']

        # Initialize kernel
        kernel = self._setup_kernel(**kwargs)


        # Use several initial guesses to avoid being stuck at local minima
        n_restarts_optimizer = kwargs['optimizer_nTrials']

        # TODO: get normalize_y from default values and
        # see if this is different from manual normalization

        ## Initialize GPR
        if(kwargs['optimizer'] == 'fmin_l_bfgs_b'):
            self.GPR_obj = GaussianProcessRegressor(\
                                kernel=kernel, \
                                optimizer='fmin_l_bfgs_b', \
                                n_restarts_optimizer=n_restarts_optimizer, \
                                normalize_y=False)

        elif kwargs['optimizer'] in OPTIMIZER_DICT:
            self.GPR_obj = GaussianProcessRegressor(\
                                kernel=kernel, \
                                optimizer=partial(optimizer_func, \
                                    opts_dict=kwargs), \
                                n_restarts_optimizer=n_restarts_optimizer, \
                                normalize_y=False)
        else:
            raise NotImplementedError("This optimizer: '%s' is not "
                "implemented. Add it yourself."%kwargs['optimizer'])


    def _setup_kernel(self, **kwargs):
        """ Sets up the kernel or Covariance function for GPR.
            The kernel's hyperparameters are optimized during fitting,
            but here we set initial guesses and bounds.
        """
        kernelType = kwargs['kernelType']
        ndims = self.xVals.shape[1]

        ## Initial guesses for Kernel hyperparameters

        # ConstantKernel will be used as a product-kernel to scale the
        # magnitude of the main kernel
        constKernel_init = kwargs['constKernel_init']
        constKernel_bounds = kwargs['constKernel_bounds']

        # NoiseKernel (WhiteKernel) will be used as a sum-kernel to account
        # for the noise
        noiseKernel_init = kwargs['noiseKernel_init']
        noiseKernel_bounds = kwargs['noiseKernel_bounds']

        # Initial guess for length scale for the main Kernel in each dimension
        # is chosen as the range of the xVals in that dimension
        lengthScale_init = np.asarray([(np.max(self.xVals[:, i]) \
            -np.min(self.xVals[:, i])) for i in range(ndims)])

        # For the bounds of the length scales, we allow from
        # lengthScale_bounds_factors[0] times to
        # lengthScale_bounds_factors[1] times the above length scales.
        lengthScale_bounds_factors = kwargs['lengthScale_bounds_factors']
        lengthScale_bounds = np.asarray( \
            [(lengthScale_bounds_factors[0] * L_i,
            lengthScale_bounds_factors[1] * L_i) \
            for L_i in lengthScale_init]
        )

        if kernelType == 'RBF':
            mainKernel = RBF(length_scale=lengthScale_init, \
                             length_scale_bounds=lengthScale_bounds)
        elif kernelType == 'Matern':
            mainKernel = Matern(length_scale=lengthScale_init, \
                                length_scale_bounds=lengthScale_bounds, \
                                nu=kwargs['nu_Matern'])
        else:
            raise NotImplementedError("This kernel: '%s' is not "
                "implemented. Add it yourself."%kernelType)

        kernel = ConstantKernel(constant_value=constKernel_init, \
                            constant_value_bounds=constKernel_bounds) \
                      *mainKernel \
                      + WhiteKernel(noiseKernel_init, noiseKernel_bounds)

        return kernel



    def _normalize(self, data):
        """
        Function to normalize the data so that it has mean 0 and std_dev 1.
        Returns the normalized data, mean and std_dev.
        """
        if np.cov(data) != 0:
            return (data - np.mean(data))/np.sqrt(np.cov(data)), \
                np.mean(data), np.sqrt(np.cov(data))
        else:
            return np.zeros_like(data), np.mean(data), 0

    def _get_kernel_params(self, kernel_obj):
        """ Recursively gets kernel parameters as a dict.
            This is useful in saving the fitted function to a h5 file.
        """
        params = kernel_obj.get_params()
        save_params = {}
        for key in list(params.keys()):
            if isinstance(params[key], gaussian_process.kernels.Kernel):
                # recursively extract params
                save_params[key] = self._get_kernel_params(params[key])
                save_params[key]['name'] = params[key].__class__.__name__
            else:
                save_params[key] = params[key]
        return save_params

    def _get_gpr_params(self, gp_obj):
        """ Gets the parameters for the fitted GPR object.
            This is needed to save the fit to disk so that in the future,
            we can just load and evaluate.
        """

        # get sklearn version, uses format X.XX.X
        import sklearn
        sklearn_version = 100*int(sklearn.__version__.split('.')[0]) + \
                              int(sklearn.__version__.split('.')[1] )

        gp_params = {}
        for attr in evaluate_fit.GPR_SAVE_ATTRS_DICT:
            if attr == 'kernel_':
                kernel = gp_obj.kernel_
                gp_params[attr] = self._get_kernel_params(kernel)
                gp_params[attr]['name'] = kernel.__class__.__name__
            else:
                try:
                    gp_params[attr] = getattr(gp_obj, attr)
                except AttributeError:
                    # In scikit-learn versions before 0.23, there was no _y_train_std.
                    # building GPR fits with older sklearn versions require that 
                    # we ingnore _y_train_std when saving a fit (see eval_pysur/evaluate_fit.py)
                    if attr == '_y_train_std' and sklearn_version <= 23:
                        warnings.warn('sklearn < 0.24 is does not support _y_train_std....OK')
                    else:
                        raise AttributeError
        return gp_params

    def _get_lin_reg_params(self, lr_obj):
        """ Gets the parameters for the fitted LinearRegression object.
            This is needed to save the fit to disk so that in the future,
            we can just load and evaluate.
        """
        lr_params = {}
        for attr in evaluate_fit.LINREG_SAVE_ATTRS_DICT:
            lr_params[attr] = getattr(lr_obj, attr)
        return lr_params


    def GPR_fit(self):
        """ Does the GPR fit.
            If doLinearFitBeforeGPR = True, first subtracts a linear fit from
            the data. Then normalizes the data such that it has 0 mean and
            1 std_dev. Finally builds a fit for the normalized data.
        """

        if self.doLinearFitBeforeGPR:
            # Linear regression and subtraction
            lin_regr = linear_model.LinearRegression()
            lin_regr.fit(self.xVals, self.yVals)
            data = self.yVals - lin_regr.predict(self.xVals)
            # Get fit data as a dict
            lin_reg_params = self._get_lin_reg_params(lin_regr)
        else:
            data = self.yVals

        # Normalize data such that it has 0 mean and 1 std_dev
        data_normalized, data_mean, data_std = self._normalize(data)

        # Do the fit
        self.GPR_obj.fit(np.asarray(self.xVals), np.asarray(data_normalized))

        # Get fit data as a dict
        GPR_params = self._get_gpr_params(self.GPR_obj)

        fitResult = {
            'GPR_params': GPR_params,
            'data_mean': data_mean,
            'data_std': data_std,
            'lin_reg_params': None,
        }

        if self.doLinearFitBeforeGPR:
            fitResult['lin_reg_params'] = lin_reg_params

        return fitResult


# --------------------------------------------------------------------------
def gpr_fit_wrapper(xVals, yVals, name, **options):
    """
Wrapper for GPRFitter class.
Does GPR fitting using sklearn.GaussianProcessRegressor.
The kernel or covariance function is set as
    kernel = ConstantKernel * MainKernel + WhiteKernel
    Here ConstantKernel just rescales the magnitude, MainKernel is set using
    the 'kernelType' option and WhiteKernel accounts for noise.
    We optimize the hyperparameters of the kernel and get the maximum
    likelihood values.

    Initial guess for length scale for the MainKernel in each dimension is
    chosen as the range of the xVals in that dimension. For the bounds of the
    length scales, we allow from 1/100 times to 10 times the above length
    scales. Smaller and larger scales are not expected to be important or
    resolvable.

inputs:
-------

xVals: A 2d array of domain values, with shape (nPoints, dim).
yVals: A 1d array of real or complex values with shape (nPoints,).
name: An identifying string used in printed output/warnings/errors.

options:
--------
minVals: A minimum value for domain values, or a list/array with one value per
    dimension. Default 0.

maxVals: Similar to minVals. Default 1.

kernelType: Choice of 'MainKernel'. Default 'RBF'. Currently only 'RBF' and
    'Matern' are implemented.

nu_Matern: '\\nu' parameter for Matern kernel. Only used if
    kernelType='Matern'. Default 1.5.

optimizer: Optimizer used to vary hyperparameters to get MLE.
    Valid options are ['Nelder-Mead', 'Powell', 'CG', 'BFGS', 'Newton-CG',
    'TNC', 'COBYLA', 'SLSQP', 'dogleg', 'trust-ncg'] but only 'fmin_l_bfgs_b'
    is well tested. Default: 'fmin_l_bfgs_b'.

optimizer_nTrials: Number of times the optimizer runs with different initial
    guesses to avoid being stuck at local minima. Default: 10.

noiseKernel_init: Initial guess for noise level. Default 1.e-4.

noiseKernel_bounds: Range in which to to optimize noise level.
    Default (1.e-7, 1.e-2).

constKernel_init: Initial guess for constant to multiply MainKernel. Default 1.

constKernel_bounds: Range in which to optimize this constant.
    Default (0.01, 100.).

doLinearFitBeforeGPR: If True, first subtract a linear fit to the data and
    then do a GPR fit. Default True.

returns:
--------
results

results: A dictionary containing all relevant fit information.
    Use evaluate_fit.getFitEvaluator(result) in fit.py to get the fit function.
    """

    for k in options:
        if k not in list(GPR_DEFAULTS.keys()):
            raise Exception('Invalid option: {}'.format(k))

    # .get obtains the key and the value, and the default value v will
    # be filled in only when k is not available.
    opts = {k: options.get(k, v) for k, v in GPR_DEFAULTS.items()}

    # Initialize GPR
    gpr_fitObject = GPRFitter(xVals, yVals, name, **opts)

    # Do the fit
    GPR_results = gpr_fitObject.GPR_fit()

    # Writing the fit results into the 'res' dictionary
    res = opts
    for k,v in GPR_results.items():     # copy GPR_results
        res[k] = GPR_results[k]

    return res
