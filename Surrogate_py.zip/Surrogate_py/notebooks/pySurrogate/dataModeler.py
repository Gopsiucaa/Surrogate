import numpy as np
from pySurrogate import nodeModeler
from pySurrogate.dataHolder import DataHolder
import warnings
from multiprocessing import Pool, freeze_support
from pySurrogate.fit import parallelFit
import pySurrogate.ei as ei
import copy

import matplotlib as mpl
mpl.use('Agg')
import matplotlib as plt
import matplotlib.gridspec as gridspec

class DataModeler(DataHolder):
    """
This class is designed to be a surrogate of a single function
which has a fixed 1d domain as well as one or more parameters.
    """
    def __init__(self, domain, name, numericsHandler=None):

        DataHolder.__init__(self, domain, name, storeData=1,
                numericsHandler=numericsHandler)

        # Empirical interpolation stuff
        self.xVals_for_RB = []
        self.RB = None
        self.RB_errors = None
        self.EIBasis = None
        self.maxLinfEIReconErr = 0.
        self.maxRMSEIReconErr = 0.
        self.maxLinfRBReconErr = 0.
        self.maxRMSRBReconErr = 0.

        # Empirical Node stuff
        self.nodeModelers = []
        self._doNotWriteToH5.append("nodeModelers")
        self.nodeIndices = []
        self.nodeType = "Fit"

#------ Calling and testing the surrogate -----------------------------------#

    # Useful to have this so we can override it in the vector case
    def _eval_EI(self, nodes):
        return nodes.dot(self.EIBasis)

    # This as well
    def _basis_dots(self, basis, data):
        return np.array([data.dot(b.conjugate()) for b in basis])

    # ...and this
    def _eval_nodes(self, x):
        return np.array([nm(x) for nm in self])

    def _test_nodes(self, x, data):
        return np.array([nm.test(x, d) for nm, d in
                         zip(self.nodeModelers, data[self.nodeIndices])])

    def __call__(self, x):
        if self.EIBasis is None:
            return 0.*self.domain
        return self._eval_EI(self._eval_nodes(x))

    def _testCall(self, x, data, keys):
        predictions = []
        if 'Full' in keys:
            nodePredictions = self._test_nodes(x, data)
            if self.EIBasis is None:
                predictions.append(0.*self.domain)
            else:
                predictions.append(self._eval_EI(nodePredictions))
        if 'EI' in keys:
            if self.EIBasis is None:
                predictions.append(0.*self.domain)
            else:
                predictions.append(self._eval_EI(data[self.nodeIndices]))
        if 'RB' in keys:
            if self.RB is None:
                predictions.append(0.*self.domain)
            else:
                if self.EIOptions['basisType'] == 'rompy':
                    dtype = 'real'
                    if np.iscomplexobj(self.RB):
                        dtype = 'complex'
                    predictions.append(np.array([self.nh.dot(b, data, dtype)
                            for b in self.RB]).dot(self.RB))
                else:
                    predictions.append(np.array([data.dot(b.conjugate())
                            for b in self.RB]).dot(self.RB))
        if not len(predictions) == len(keys):
            raise Exception("%s: Got %s predictions with keys %s"%(
                    self.name, len(predictions), keys))
        return predictions

    def errVsDomain(self, data, prediction):
        return abs(data - prediction)

#------ Adding data --------------------------------------------------------#

    def addKnownDataSet(self, newX, newData, addBasisData=True):
        self._append_x(newX)

        if addBasisData:
            self.xVals_for_RB.append(newX)
            if type(self.dataSets) == list:
                self.dataSets.append(newData)
            else:
                self.dataSets = np.append(self.dataSets,
                        np.array([newData]), 0)

        for i, nm in enumerate(self):
            nm.addKnownDataSet(newX, newData[self.nodeIndices[i]])

    def nNodes(self):
        return len(self.nodeModelers)

#------ Building an Empirical Interpolant ----------------------------------#

    def createEmpiricalInterpolant(self, **kwargs):
        """Creates a basis and empirical interpolant using the known data.
        The nodes may then be assigned nodeModelers of type nodeType."""

        btype, data, inner, basisTol, i1, i2, first_indices = self._getEIInput(**kwargs)
        print("Creating a %s %s RB/EI from %s data sets with tol %s for %s"%(
                    data.dtype, btype, len(data), basisTol, self.name))
        res = ei.buildEI(btype, data, inner, basisTol, i1, i2, first_indices)
        print('...got %s basis elements'%len(res[2]))
        self._giveEIResults(res)

    def createLSOEmpiricalInterpolant(self, xExcluded, **kwargs):
        """Creates an empirical interpolant, omitting data with xVals
        in xExcluded.  Useful for cross-validation studies."""

        s = self._getLSOEIInput(xExcluded, **kwargs)
        print("Creating a %s %s LSO basis/EI, %s data sets, tol %s for %s..."%(
                    s[1].dtype, s[0], len(s[1]), s[-1], self.name))
        res = ei.buildEI(*s)
        print('...got %s basis elements'%len(res[2]))
        self._giveEIResults(res)

    def _getEIInput(self, **kwargs):
        self.setupEmpiricalInterpolants(**kwargs)
        btype = self.EIOptions['basisType']
        btol = self.EIOptions['basisTol']
        iMin = self.EIOptions['i_min_EI']
        iMax = self.EIOptions['i_max_EI']
        first_indices = self.EIOptions['first_indices_EI']
        return btype, np.array(self.dataSets), self.nh, btol, iMin, iMax, first_indices

    def _getLSOEIInput(self, xExcluded, **kwargs):
        self.setupEmpiricalInterpolants(**kwargs)
        btype = self.EIOptions['basisType']
        btol = self.EIOptions['basisTol']
        iMin = self.EIOptions['i_min_EI']
        iMax = self.EIOptions['i_max_EI']
        indices = [i for i, x in enumerate(self.xVals) if not x in xExcluded]
        if len(indices) == len(self.xVals):
            warnings.warn("%s is building a LSO EI but excluded nothing."%(
                        self.name))
        data = np.array(self.dataSets)[indices]
        return btype, data, self.nh, btol, iMin, iMax

    def _giveEIResults(self, results):
        rb_basis, ei_basis, ei_indices, rb_errors = results
        if self.EIOptions['storeRB']:
            self.RB = rb_basis
            self.RB_errors = rb_errors
        if self.EIOptions['plotDir'] is not None:
            print (f'Plotting basis for {self.name}')
            # Plot the reduced basis
            figname_tag = f"{self.name}_RB"
            self._plotBasis(rb_basis, figname_tag)
            # Plot the EI basis alsong with the EI times
            figname_tag = f"{self.name}_EI"
            self._plotBasis(ei_basis, figname_tag, ei_indices=ei_indices)
            # Plot basis number vs error
            figname_tag = f"{self.name}_errs"
            self._plotBasis_size_vs_error(rb_errors, figname_tag)

        self.EIBasis = ei_basis
        self.nodeIndices = ei_indices
        if rb_basis is not None:
            self.updateBasisErrors(basis=rb_basis)
        self.setupNodeModelers(self.nodeType)
        self.xVals_for_RB = copy.deepcopy(self.xVals)

    def _plotBasis_size_vs_error(self, rb_errors, figname_tag):
        fig, ax = plt.subplots(1,1,figsize=(6,4))
        ax.semilogy(range(1, len(rb_errors)+1), rb_errors, marker='o')
        ax.set_xlabel(f'Basis size', fontsize=12)
        ax.set_ylabel(f'Error', fontsize=12)
        ax.get_xaxis().set_tick_params(which='both', direction='in')
        ax.get_yaxis().set_tick_params(which='both', direction='in')
        ax.grid(which='both', ls='--')
        plt.savefig(f"{self.EIOptions['plotDir']}/{figname_tag}.png",
                    bbox_inches='tight')
        plt.close()

    def _plotBasis(self, basis, figname_tag, ei_indices=None,
            markersize=15, markercolor='salmon'):

        num_basis = len(basis)
        fig = plt.figure(figsize=(6, 1.5*num_basis))
        gs = gridspec.GridSpec(num_basis, 2, width_ratios=[3, 1])
        plt.subplots_adjust(wspace=0.01, hspace=0.05)

        if self.domain[0] < -100:
            # This only really makes sense when we have a ringdown, and
            # t=0 is set at the peak. But that is the typical case we
            # deal with.
            split_time = -100
        else:
            # This is what we want, for example, for PN data with
            # no ringdown
            split_time = self.domain[-1]

        brIdx = np.argmin(np.abs(self.domain - split_time))
        for idx, data in enumerate(basis):

            # For setting same ylim for pre/post ringdown
            minYval = np.min(data)
            maxYval = np.max(data)
            if maxYval > 0:
                maxYval = 1.1*maxYval
            else:
                maxYval = 0.9*maxYval
            if minYval > 0:
                minYval = 0.9*minYval
            else:
                minYval = 1.1*minYval

            # pre-ringdown plot
            ax = plt.subplot(gs[idx,0])
            ax.plot(self.domain[:brIdx], data[:brIdx])
            if ei_indices is not None:
                # Plot EI times, but only as many as the basis number
                # so we get an idea of the order in which the times are
                # added.
                ax.scatter(self.domain[ei_indices][:idx+1],
                           data[ei_indices][:idx+1],
                           c=markercolor,
                           s=markersize)
            ax.set_ylim(min(data), max(data))
            ax.set_xlim(self.domain[0], split_time)
            ax.set_ylim(minYval, maxYval)
            ax.set_title(f'basis num={idx}', fontsize=12, y=0.7)
            ax.yaxis.tick_left()
            if idx != num_basis - 1:
                ax.get_xaxis().set_tick_params(which='both',
                        direction='in', labelbottom=0, top=0)

            # ringdown plot
            ax = plt.subplot(gs[idx,1])
            ax.plot(self.domain[brIdx:], data[brIdx:])
            if ei_indices is not None:
                # Plot EI times, but only as many as the basis number
                # so we get an idea of the order in which the times are
                # added.
                ax.scatter(self.domain[ei_indices][:idx+1],
                           data[ei_indices][:idx+1],
                           c=markercolor,
                           s=markersize)
            ax.set_ylim(min(data), max(data))
            ax.set_xlim(split_time, self.domain[-1])
            ax.set_ylim(minYval, maxYval)
            ax.yaxis.tick_right()
            if idx != num_basis - 1:
                ax.get_xaxis().set_tick_params(which='both',
                        direction='in', labelbottom=0, top=0)

        plt.suptitle(figname_tag, fontsize=14, y=0.92)
        plt.savefig(f"{self.EIOptions['plotDir']}/{figname_tag}.png",
                    bbox_inches='tight')
        plt.close()

    def updateBasisErrors(self, basis=None):
        if basis is None:
            basis = self.RB
        if basis is None:
            raise Exception('%s: No RB available!'%(self.name))
        if self.EIBasis is not None:
            errs = [self.errVsDomain(tmp, self._eval_EI(tmp[self.nodeIndices]))
                    for tmp in self.dataSets]
        elif len(self.dataSets) > 0:
            errs = [self.errVsDomain(tmp, 0*tmp) for tmp in self.dataSets]
        else:
            errs = [0.*self.domain]
        self.maxLinfEIReconErr = max([max(e) for e in errs])
        self.maxRMSEIReconErr = max([np.sqrt(np.mean(abs(e*e)))
                for e in errs])
        if len(self.dataSets) > 0:
            errs = [self.errVsDomain(tmp, self._eval_EI(
                        self._basis_dots(basis, tmp)))
                    for tmp in self.dataSets]
        else:
            errs = [0.*self.domain]
        self.maxLinfRBReconErr = max([max(e) for e in errs])
        self.maxRMSRBReconErr = max([np.sqrt(np.mean(abs(e*e)))
                for e in errs])

    def setupNodeModelers(self, nodeType="Fit"):
        nodeClass = nodeModeler._nodeClass(nodeType)
        self.nodeType = nodeType
        self.nodeModelers = []
        for i, ni in enumerate(self.nodeIndices):
            nm = nodeClass(name=self._nodeName(i, ni), **self.fitOptions)
            for j, x in enumerate(self.xVals):
                nm.addKnownDataSet(x, self.dataSets[j][ni])
            self.nodeModelers.append(nm)

#---------- Fitting empirical nodes -----------------------------------------#

    def fit(self, nProcs=None, **kwargs):
        if nProcs is None:
            print('%s is fitting %s nodes'%(self.name, len(self.nodeModelers)))
            for nm in self:
                nm.fit(**kwargs)
        else:
            print('%s is fitting %s nodes with %s procs'%(
                    self.name, len(self.nodeModelers), nProcs))
            
            inputs = [nm._getFitInput(**kwargs) for nm in self]
            p = Pool(nProcs)
            results = p.map(parallelFit, inputs)
            for nm, res in zip(self.nodeModelers, results):
                nm._giveFitResults(res)
               

    def leaveSomeOutFit(self, xExcluded, nProcs=None, **kwargs):
        if nProcs is None:
            print('%s is fitting %s nodes'%(self.name, len(self.nodeModelers)))
            for nm in self:
                nm.leaveSomeOutFit(xExcluded, **kwargs)
        else:
            print('%s is fitting %s nodes with %s procs'%(
                    self.name, len(self.nodeModelers), nProcs))
            # This block is required to avoid the "bootstrapping" error on some platforms
           
            inputs = [nm._getLSOFitInput(**kwargs) for nm in self]
            p = Pool(nProcs)
            results = p.map(parallelFit, inputs)
            for nm, res in zip(self.nodeModelers, results):
                   nm._giveFitResults(res)


    def _getFitInput(self, **kwargs):
        return [nm._getFitInput(**kwargs) for nm in self]

    def _getLSOFitInput(self, xExcluded, **kwargs):
        return [nm._getLSOFitInput(xExcluded, **kwargs) for nm in self]

    def _giveFitResults(self, manyResults):
        if not len(manyResults) == len(self.nodeModelers):
            raise Exception('%s: Wrong number of fit results'%(self.name))
        for i, res in enumerate(manyResults):
            self.nodeModelers[i]._giveFitResults(res)

#------------- Misc ---------------------------------------------------------#

    def iterH5Subordinates(self):
        for nm in self.nodeModelers:
            yield nm

    def infoStrings(self):
        # Can put more simple info in this file later
        res = []
        res.append("basisTol: %s"%self.EIOptions['basisTol'])
        res.append("maxLinfEIReconErr: %s"%self.maxLinfEIReconErr)
        return res

    def _nodeName(self, i, nodeIndex):
        return self.name + "_node%s_idx%s"%(i, nodeIndex)

    def _prepareForSubload(self, isFirst=0):
        if isFirst:
            self._setupNH()
        nodeClass = nodeModeler._nodeClass(self.nodeType)
        self.nodeModelers = [nodeClass(self._nodeName(i, ni))
                             for i, ni in enumerate(self.nodeIndices)]

    def test_func(self):
        print("The test function works")    
