import numpy as np
from pySurrogate.dataModeler import DataModeler

class VectorDataModeler(DataModeler):
    """
This class is designed to be a surrogate of a single vector function
with shape (N, m) where N = len(self.domain) and m is the number of
vector components.

When building a basis, all components will be treated equally and a
**single** basis will be built from the combination of all components.
This way, we will obtain a single set of empirical nodes.

When fitting, we will fit the whole vector at once. At the NodeModeler
level this can be handled as desired - for example fitting each
component individually.
    """

    def __init__(self, domain, name, dim, numericsHandler=None):
        DataModeler.__init__(self, domain, name, numericsHandler)
        self.fitOptions['dim'] = dim
        self.nodeType = "VectorFit"

    def errVsDomain(self, data, prediction):
        return np.sqrt(np.sum(abs(data - prediction)**2, 1))

#------ Calling and testing the surrogate -----------------------------------#

    def _eval_EI(self, nodes):
        return nodes.T.dot(self.EIBasis).T

    def _basis_dots(self, basis, data):
        return np.array([data.T.dot(b.conjugate()) for b in basis])

#------ Building an Empirical Interpolant ----------------------------------#

    def _EI_input_wrapper(self, btype, data, nh, btol, i1, i2):
        nVecs, length, vecDim = data.shape
        data = data.transpose(0, 2, 1).reshape((nVecs*vecDim, length))
        return btype, data, nh, btol, i1, i2

    def _getEIInput(self, **kwargs):
        args = DataModeler._getEIInput(self, **kwargs)
        return self._EI_input_wrapper(*args)

    def _getLSOEIInput(self, xExcluded, **kwargs):
        args = DataModeler._getLSOEIInput(self, xExcluded, **kwargs)
        return self._EI_input_wrapper(*args)

    def setupNodeModelers(self, nodeType="VectorFit"):
        DataModeler.setupNodeModelers(self, nodeType=nodeType)
