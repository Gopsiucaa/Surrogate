import numpy as np
import warnings

#------------------------------------------------------------------------
def parallelBuildEI(args):
    """Helper function for parallelizing buildEI"""
    return buildEI(*args)

#------------------------------------------------------------------------
def buildEI(solType, dataSets, inner, basisTol, i_min_EI=None,
        i_max_EI=None, first_indices_EI=[]):

    # If some of first_indices_EI are negative, convert them to positive
    # indicies for simplicity.
    first_indices_EI = [tmp if tmp >= 0 else len(dataSets[0]) + tmp
                        for tmp in first_indices_EI]

    if solType == 'rompy':
        if i_min_EI is not None or i_max_EI is not None or len(first_indices_EI) > 0:
            raise Exception('rompy does not support i_min_EI and i_max_EI')
        return buildRompyEI(dataSets, inner, basisTol)

    elif solType == 'pySur':
        # If i_min_EI or i_max_EI are given they are used to restrict the
        # range of data used in computing basis projection errors as well
        # as empirical time nodes.
        rb, rb_errors, rb_indices = buildPySurRB(dataSets, basisTol,
                                                 i_min_EI, i_max_EI)
        eiBasis, nodeIndices = buildPySurEI(rb, i_min_EI, i_max_EI,
                                            first_indices=first_indices_EI)
        return rb, eiBasis, nodeIndices, rb_errors

    elif solType == 'pySurSVD':
        # If i_min_EI or i_max_EI are given they are used to restrict the
        # range of allowed empirical time nodes.
        rb, rb_errors = buildPySurSVD(dataSets, basisTol)
        eiBasis, nodeIndices = buildPySurEI(rb, i_min_EI, i_max_EI, \
            first_indices=first_indices_EI)
        return rb, eiBasis, nodeIndices, rb_errors

    else:
        raise Exception("Bad basis type: %s"%solType)

#------------------------------------------------------------------------
def buildRompyEI(data, inner, basisTol):
    """A wrapper for rompy"""
    import rompy as rp
    basis = rp.algorithms.ReducedBasis(inner)
    basis.make(data, 0, basisTol**2)

    ei = rp.algorithms.EmpiricalInterpolant(basis.basis)

    return basis.basis, ei.B, ei.indices

#-------------------------------------------------------------------------
def buildPySurRB(data, basisTol, i1=None, i2=None):
    """Builds a reduced basis for the data with maximum RMS projection error
    less than basisTol

    If i1, i2 are given, they restrict the range of the data used in
    computing basis projection errors to lie in [i1, i2). Note that the
    basis itself will include the full range. This is useful for example
    if we know that the late time data is noisy and not important.
    """

    if len(data) < 1:
        return None

    if i1 is None:
        i1 = 0
    if i2 is None:
        i2 = len(data[0])

    def norm(x):
        return np.sqrt(np.mean(abs(x*x)[i1:i2]))

    errors = [norm(d) for d in data]
    basis = np.array([])
    usedIndices = []
    basis_errs = []
    while max(errors) > basisTol or len(basis)==0:
        nextIndex = np.argmax(errors)
        if nextIndex in usedIndices:
            warnings.warn("Tried to reuse an index! Tol=%s, err=%s"%(
                    basisTol, max(errors)))
            return basis
        usedIndices.append(nextIndex)
        uu, ss, basis = np.linalg.svd(data[usedIndices], full_matrices=0)
        errors = [norm(d - np.array([d.dot(b.conjugate())
                for b in basis]).dot(basis)) for d in data]
        basis_errs.append(max(errors))
        #print '%s/%s, %s, %s'%(len(basis), len(data), max(errors), basisTol)
    if len(basis) == 0:
        return None

    return basis, basis_errs, usedIndices

#-------------------------------------------------------------------------
def buildPySurSVD(data, basisTol):
    """Uses SVD to build an orthonormal basis for the data with maximum
    RMS projection error less than basisTol"""

    if len(data) < 1:
        return None

    l = len(data[0])

    uu, ss, basis = np.linalg.svd(data, full_matrices=0)

    # If projection error j for a basis size of i is e_{i, j}, then
    # e_{i, j} \cdot e_{i, j} = \sum_{j=i}^n { ss[j]^2 uu[i,j]^2 }
    errors = np.array([max(np.sqrt((ss[i:]**2).dot(uu.T[i:]**2)/l))
            for i in range(len(data) + 1)])

    if errors[-1] > basisTol:
        raise Exception("SVD failed to reach tolerance %s"%basisTol)

    n_basis = np.where(errors < basisTol)[0][0]
    if n_basis == 0:
        n_basis = 1
    return basis[:n_basis], errors[:n_basis]

#-------------------------------------------------------------------------
def buildPySurEI(basis, i1=None, i2=None, returnV=False, first_indices=[]):
    """
    Builds an empirical interpolant from the given basis.

    If i1, i2 are given, they restrict the range of the empirical nodes
    to lie in [i1, i2).

    If returnV is True, the Vandermonde matrix is computed and returned.

    The first m empirical node indices may be given in first_indices.
    The remaining indices will be chosen as usual with the argmax of the
    residual error.
    """

    if basis is None or len(basis) == 0:
        return None, []

    if i1 is None:
        i1 = 0
    if i2 is None:
        i2 = len(basis[0])

    resids = np.copy(basis)
    nodeIndices = []
    eiBasis = []

    for i in range(len(basis)):
        if i < len(first_indices):
            ni = first_indices[i]
        else:
            ni = i1 + np.argmax(abs(resids[i,i1:i2]))
        nodeIndices.append(ni)
        eiBasis.append(resids[i]/resids[i][nodeIndices[-1]])
        for j in range(len(basis)):
            resids[j] -= eiBasis[-1]*resids[j][nodeIndices[-1]]
    eiBasis = np.array(eiBasis)
    vInv = np.zeros((len(eiBasis), len(eiBasis)))*eiBasis[0][0]
    for i in range(len(eiBasis)):
        alpha = np.array([])
        if i > 0:
            alpha = -1.*np.array([tmp.dot(eiBasis.T[nodeIndices[i]][:i])
                    for tmp in vInv[:i,:i].T])
        vInv[i] = np.append(np.append(alpha, 1.), np.zeros(len(eiBasis) - i - 1))
    eiBasis = vInv.T.dot(eiBasis)

    if returnV:
      V = basis[:, nodeIndices] # allows for basis = np.dot(V,ei_basis)
      return eiBasis, nodeIndices, V
    else:
      return eiBasis, nodeIndices
