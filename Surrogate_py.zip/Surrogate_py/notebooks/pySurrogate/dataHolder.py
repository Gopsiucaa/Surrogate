import numpy as np
from pySurrogate import SaveH5Object
import warnings

class DataHolder(SaveH5Object):
    """DataModeler and DataGroup both hold many sets of data
    associated with particular parameters and a domain.
    This class contains their shared functionality."""

    def __init__(self, domain, name, storeData=True, numericsHandler=None):
        """domain: a 1-d increasing numpy array
        name: an identifying name (string)
        domain: the domain of output data
        storeData: If the purpose of this DataHolder is just to decompose
                   and recombine data to/from its subordinates, it may not
                   need to actually store data sets.
        numericsHandler: If none, will be generated automatically.
        """

        SaveH5Object.__init__(self, name)

        self.domain = domain

        # Setup the numericsHandler which can integrate on the domain
        # TODO: take derivatives as well
        if numericsHandler is None:
            self._setupNH()
        else:
            self.nh = numericsHandler
        # We can't save it, so just regenerate it when we load.
        self._doNotWriteToH5.append("nh")

        self.xVals = []
        self.dataSets = []
        self.storeData = storeData

        self.fitOptions = {}
        self.EIOptions = {
                'basisType': 'pySur',
                'basisTol': 1.e-12,
                'storeRB': True,
                'plotDir': None,
                'i_min_EI': None,
                'i_max_EI': None,
                'first_indices_EI': [],
                    }
        self.testErrors = {}
        self.clearCheckedErrors(0)


    def _append_x(self, x):
        if type(self.xVals) == list:
            self.xVals.append(x)
        else:
            self.xVals = np.append(self.xVals, np.array([x]), 0)

#------ Things to be overridden ---------------------------------------------#

    def __call__(self, x):
        """Predict the data at parameter x"""
        raise NotImplementedError("Please override me.")

    def _testCall(self, x, data, keys):
        """Predict the data set at parameters x by calling 'test' methods
        of subordinates so they can log their errors as well.
        Return one result for each key ("Full", "EI", "RB")"""
        raise NotImplementedError("Please override me.")

    def errVsDomain(self, data, prediction):
        """Compute a non-negative error vs the surrogate's domain from
        the actual result and the surrogate's prediction"""
        raise NotImplementedError("Please override me.")

#------ Testing the surrogate -----------------------------------------------#

    def test(self, x, data, keys=['Full', 'EI', 'RB']):
        predictions = self._testCall(x, data, keys)
        for k, p in zip(keys, predictions):
            self._recordErrors(x, data, p, k)
        return predictions

    def testFull(self, x, data):
        prediction = self._testCall(x, data, ['Full'])[0]
        self._recordErrors(x, data, prediction, 'Full')
        return prediction

    def testRB(self, x, data):
        prediction = self._testCall(x, data, ['RB'])[0]
        self._recordErrors(x, data, prediction, 'RB')
        return prediction

    def testEI(self, x, data):
        prediction = self._testCall(x, data, ['EI'])[0]
        self._recordErrors(x, data, prediction, 'EI')
        return prediction

    def getMaxCheckedErrors(self, errType, errKey):
        errs = self.testErrors[errType][errKey]
        if len(errs) == 0:
            mine = 0.
        else:
            mine = max(errs)
        allErrs = {self.name: mine}
        for item in self:
            if hasattr(item, "getMaxCheckedErrors"):
                moreErrs = item.getMaxCheckedErrors(errType, errKey)
                allErrs.update(**moreErrs)
        return allErrs

#------ Surrogate Errors ----------------------------------------------------#

    def _recordErrors(self, x, data, prediction, key):
        d = self.testErrors[key]

        err = self.errVsDomain(data, prediction)
        n = len(d["xVals"])
        if n == 0:
            d["xVals"] = [x]
            d["rmsErrVsDomain"] = err
        else:
            d["xVals"].append(x)
            d["rmsErrVsDomain"] = np.sqrt((
                    n*d["rmsErrVsDomain"]**2. + err**2.)/(n+1))
        d["maxErrVsDomain"] = np.amax(np.array([d["maxErrVsDomain"], err]), 0)
        d["LInf"].append(max(err))
        d["RMS"].append(np.sqrt(np.mean(err**2)))

    def clearCheckedErrors(self, recursive=1):
        for key in ['Full', 'EI', 'RB']:
            self.testErrors[key] = {
                    "xVals": [],
                    "LInf": [],
                    "RMS": [],
                    "maxErrVsDomain": np.zeros(len(self.domain)),
                    "rmsErrVsDomain": np.zeros(len(self.domain)),
                        }
        if recursive:
            for sub in self:
                if hasattr(sub, "clearCheckedErrors"):
                    sub.clearCheckedErrors(1)

#------ Adding and retreiving data-------------------------------------------#

    def getDataSet(self, x):
        indices = np.where(np.all(np.array(self.xVals) == x, axis=1))[0]
        if len(indices) == 0:
            warnings.warn('%s found no data set for %s, returning zeros.'%(
                    self.name, x))
            return self.domain*0.
        if len(indices) > 1:
            warnings.warn('%s found multiple data sets for %s.'%(
                    self.name, x))
        return self.dataSets[indices[0]]

    def dropDataSets(self):
        """Removes all data sets from this and subordinate dataHolders"""
        self.dataSets = []
        for sub in self:
            if hasattr(sub, "dropDataSets"):
                sub.dropDataSets()

    def done_adding(self):
        """
Turns xVals and dataSets into arrays. Memory usage is reduced, but adding
data becomes slower.
        """
        self.xVals = np.array(self.xVals)
        self.dataSets = np.array(self.dataSets)
        for sub in self:
            if hasattr(sub, "done_adding"):
                sub.done_adding()

#------ Setting up options --------------------------------------------------#

    def setupEmpiricalInterpolants(self, **kwargs):
        for key in kwargs:
            if key not in self.EIOptions:
                raise ValueError('%s is not a valid EIOption'%(key))
        self.EIOptions.update(**kwargs)
        for item in self:
            if hasattr(item, "setupEmpiricalInterpolants"):
                item.setupEmpiricalInterpolants(**self.EIOptions)

    def setupFits(self, **kwargs):
        self.fitOptions.update(**kwargs)
        for item in self:
            item.setupFits(**self.fitOptions)

#------------- Misc ---------------------------------------------------------#

    def _setupNH(self):
        dx = self.domain[1] - self.domain[0]
        if max(abs((np.diff(self.domain) - dx)/dx)) > 1.e-5:
            print('WARNING: using non-uniform domain with uniform quadrature rule!')
        self.nh = NumericsHandler(dx, len(self.domain))

class NumericsHandler:
    """Silly little class for backwards compatibility with rompy.Integration"""
    def __init__(self, dx, npoints):
        # Use trapezoidal weights to be consistent with rompy default
        self.weights = np.ones(npoints) * dx
        self.weights[0] *= 0.5
        self.weights[-1] *= 0.5

    def dot(self, a, b, dtype=None):
        return np.dot(self.weights, a*b)
