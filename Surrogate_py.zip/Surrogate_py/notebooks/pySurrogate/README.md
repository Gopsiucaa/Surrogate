# README #

### Welcome to pySurrogate! ###

* pySurrogate facilitates building surrogates for structured data, which can be broken down into many simple functions.
* Relies on rompy
* Created by Jonathan Blackman.  Contact jonathan "dot" blackman "dot" 0 "at" gmail "dot" com.

### Instructions ###
#### Clone the repo (note the capitalization of S):
git clone git@bitbucket.org:JonathanBlackman/pysurrogate.git pySurrogate

```bash
cd pySurrogate
git submodule init
git submodule update
```

#### Edit PYTHONPATH 
export PYTHONPATH="<path-to-pySurrogate>:$PYTHONPATH"

Replace <path-to-pySurrogate> with the full path to the repo.  
It is recommended to add the above line to your .bashrc or equivalent.

#### Tests

```bash
pytest                           # run all tests
pytest -v -s                     # run all tests with high verbosity
```

#### Making changes to eval_pysur
eval_pysur is a submodule that handles evaluation of fits. Since this is a submodule, the following steps are required to make changes to it.

```bash
cd eval_pysur
git add <stuff>
git commit -m "comment"
git push
cd ..
git add eval_pysur
git commit -m "updated eval_pysur"
git push
```

### Known Problems ###

Run "pytest -v -s", and if your tests hang here 

```
tests/dataGroup_test.py::complex_exponential_test::test_reIm
```

you have encountered [a known bug in numpy's dot function](https://github.com/numpy/numpy/issues/11046).
The problem is that numpy's dot function uses the BLAS library, and certain versions of the library are
not thread-safe, resulting in a dead-lock. There are three fixes:

* Use Python 2.7. Currently, this bus is only known to affect PySurrogate for 3.X
* Install a different version of parallel BLAS, and rebuild numpy. For example, the 
Bitbucket pipelines docker image points to a version of Python 3 that is known to work on Ubuntu 18.04
* Never call np.dot from multiprocessing pool. For this, you will always need to set "procs=None" in your code.