#!/usr/bin/python
import numpy as np
from math import pi, ceil
import warnings

from .eval_pysur import evaluate_fit

############### Stuff related to greedyFit ###################################

def dot(v1, v2):
    return v1.dot(v2.conjugate())

def norm(v):
    return np.sqrt(abs(dot(v, v)))

def rms(v):
    return np.sqrt(np.mean(abs(v*v)))

def rms_NT(v):
    vv = np.array(v).flatten()
    return rms(vv)

def rms_max(v):
    return rms(np.array([max(abs(tmp)) for tmp in v]))

def normalizeMany(manyVs):
    norms = np.sqrt(np.sum(abs(manyVs**2), 1))
    return (manyVs.T/(norms + 1.*(norms == 0.))).T

def dotMany(manyV1s, v2):
    return np.sum(manyV1s*v2.conjugate(), 1)


DEFAULTS = {
        'bfTypes': 'chebyshev',
        'bfMaxOrders': 'fromData',
        'minVals': 0.,
        'maxVals': 1.,
        'absTol': 0.,
        'relTol': 0.,
        'rmsCutoff': 0.,
        'maxCoefConst': 'nPoints',
        'maxCoefFrac': 0.,
        'useReconstructionErrors': True,
        }

CV_DEFAULTS = {
        'fitType': 'Greedy',
        'bfTypes': 'chebyshev',
        'bfMaxOrders': 'fromData',
        'minVals': 0.,
        'maxVals': 1.,
        'rmsCutoff': 'crossValidation',
        'maxCoefConst': 'nPoints',
        'cv_N': '10percent',
        'cv_nTrials': 1,
        'cv_crucial_indices': [],
        }

def tcString(tc):
    if tc == 1:
        return "All residuals are below or equal (absTol + relTol*yVals)"
    if tc == 2:
        return "The root-mean-square residual is below or equal the rmsCutoff"
    if tc == 3:
        return "Reached maxCoefs coefficients"
    if tc == 4:
        return "The root-mean-square residual would increase if we continued."
    if tc == 5:
        return "All available coefficients were used"
    if tc == 6:
        return "Successful cross-validation fit"
    if tc == -1:
        return "Received zero data points, returned empty fit"
    if tc == -2:
        return "The chosen basis vector has already been used"
    return "Unknown"


def _greedy_fit(xVals, yVals, name, **options):
    for k in options:
        if k not in list(DEFAULTS.keys()):
            raise Exception('Invalid option: {}'.format(k))

    opts = {k: options.get(k, v) for k, v in DEFAULTS.items()}
    res = {
            "minVals": opts["minVals"],
            "maxVals": opts["maxVals"],
            "bfTypes": opts["bfTypes"],
            "coefs": np.array([]),
            "bfOrders": [],
            "rmsResids": [],
            "maxResids": [],
            }

    if not len(xVals) == len(yVals):
        raise ValueError("Cannot fit {} with {} xVals and {} yVals".format(
                name, len(xVals), len(yVals)))
    if len(xVals) == 0:
        warnings.warn("{} has no data, returning empty fit".format(name))
        return res, -1
    dim = len(xVals[0])
    nPoints = len(xVals)

    # Make opts have a standard format
    if opts["maxCoefConst"] == "nPoints":
        opts["maxCoefConst"] = nPoints
    if not type(opts['minVals']) in [list, np.ndarray]:
        opts['minVals'] = np.array([opts['minVals'] for _ in range(dim)])
        res['minVals'] = opts['minVals']
    if not type(opts['maxVals']) in [list, np.ndarray]:
        opts['maxVals'] = np.array([opts['maxVals'] for _ in range(dim)])
        res['maxVals'] = opts['maxVals']
    if type(opts['bfTypes']) == str:
        opts['bfTypes'] = [opts['bfTypes'] for _ in range(dim)]
        res['bfTypes'] = opts['bfTypes']
    if opts['bfMaxOrders'] == 'fromData':
        opts['bfMaxOrders'] = nPoints - 1
    if type(opts['bfMaxOrders']) == int:
        opts['bfMaxOrders'] = [opts['bfMaxOrders'] for _ in range(dim)]

    maxCoefs = opts["maxCoefConst"] + int(nPoints*opts["maxCoefFrac"])
    if maxCoefs > nPoints:
        warnings.warn("{} has maxCoefs > nPoints!".format(name))

    # Set up the (initially non-orthonormal) basis vectors
    allBFOrders = getBFOrders(opts['bfMaxOrders'])
    bVecs = np.array([
              np.prod(
                np.array([
                  evaluate_fit.basisFunction(
                    opts['bfTypes'][j],
                    tmpI[j],
                    opts['minVals'][j],
                    opts['maxVals'][j]
                  )(xVals[:,j])
                  for j in range(dim)]), 0)
              for tmpI in allBFOrders])

    if  opts['useReconstructionErrors']:
        origBVecs = 1.*bVecs

    # We update resids by subtracting projections, and update
    # true resids by evaluating the fit when useReconstructionErrors=True.
    trueResids = 1.*yVals
    resids = 1.*yVals

    innerProducts = dotMany(bVecs, resids).conjugate()
    res['rmsResids'].append(rms(resids))
    res['maxResids'].append(max(abs(resids)))

    # Keep track of the manipulations of the basis functions so we can
    # convert the coefficients for the orthonormal basis functions to
    # coefficients for the original basis functions
    testCoefs = np.identity(len(bVecs))
    if np.iscomplexobj(bVecs):
        testCoefs = (1. + 0.j)*testCoefs

    tol = opts['absTol'] + opts['relTol']*yVals
    coefs = []
    iUsed = []

    while len(iUsed) < min(maxCoefs, len(allBFOrders)):

        # Check for residual termination
        if np.all(abs(trueResids) <= tol):
            return res, 1
        if rms(trueResids) <= opts['rmsCutoff']:
            return res, 2

        # Add another basis vector
        iNext = np.argmax(abs(innerProducts))
        if iNext in iUsed:
            warnings.warn("{}: Already used bVec, have {} coefs".format(
                    name, len(coefs)))
            return res, -2
        n = norm(bVecs[iNext])
        bNext = bVecs[iNext]/n
        testCoefs[iNext] = testCoefs[iNext]/n
        coefs.append(dot(resids, bNext))
        iUsed.append(iNext)
        bVecs[iNext] *= 0.

        # Subtract projections to make remaining bVecs orthogonal.
        # Do NOT re-normalize them, or we would have the wrong testCoefs
        dots = dotMany(bVecs, bNext)
        bVecs -= np.outer(dots, bNext)
        testCoefs -= np.outer(dots, testCoefs[iNext])

        # Update residuals and inner products
        resids -= coefs[-1]*bNext
        if opts['useReconstructionErrors']:
            trueResids = yVals - (np.array(coefs).dot(
                    testCoefs[iUsed][:,iUsed])).dot(origBVecs[iUsed])
        else:
            trueResids -= coefs[-1]*bNext
        if rms(trueResids) > 1.01*res['rmsResids'][-1]:
            warnings.warn("{}: Adding coef {} increased rms resids".format(
                    name, len(coefs)))
            if not opts['useReconstructionErrors']:
                raise Exception('This should never happen')
            return res, 4
        innerProducts = dotMany(bVecs, resids).conjugate()

        # Succesfully added another basis vector, Update res
        res['maxResids'].append(max(abs(trueResids)))
        res['rmsResids'].append(rms(trueResids))
        res['coefs'] = np.array(coefs).dot(testCoefs[iUsed][:,iUsed])
        res['bfOrders'].append(allBFOrders[iNext])

    if len(iUsed) == maxCoefs:
        return res, 3
    return res, 5

##############################################################################

def _cross_validation_fit(xVals, yVals, name, **options):

    for k in options:
        if k not in list(CV_DEFAULTS.keys()):
            raise Exception('Invalid option for cv fit: {}'.format(k))

    opts = {k: options.get(k, v) for k, v in CV_DEFAULTS.items()}
    res = {
            "minVals": opts["minVals"],
            "maxVals": opts["maxVals"],
            "bfTypes": opts["bfTypes"],
            "coefs": np.array([]),
            "bfOrders": [],
            "rmsResids": [],
            "maxResids": [],
            "rmsLSOResids": [],
            "rmsMaxLSOResids": [],
            }

    if not len(xVals) == len(yVals):
        raise ValueError("Cannot fit {} with {} xVals and {} yVals".format(
                name, len(xVals), len(yVals)))
    dim = len(xVals[0])
    nPoints = len(xVals)
    # Make opts have a standard format
    if not type(opts['minVals']) in [list, np.ndarray]:
        opts['minVals'] = np.array([opts['minVals'] for _ in range(dim)])
        res['minVals'] = opts['minVals']
    if not type(opts['maxVals']) in [list, np.ndarray]:
        opts['maxVals'] = np.array([opts['maxVals'] for _ in range(dim)])
        res['maxVals'] = opts['maxVals']
    if type(opts['bfTypes']) == str:
        opts['bfTypes'] = [opts['bfTypes'] for _ in range(dim)]
        res['bfTypes'] = opts['bfTypes']
    if opts['bfMaxOrders'] == 'fromData':
        opts['bfMaxOrders'] = nPoints - 1
    if type(opts['bfMaxOrders']) == int:
        opts['bfMaxOrders'] = [opts['bfMaxOrders'] for _ in range(dim)]
    if type(opts['cv_N']) == str:
        percent = float(opts['cv_N'].split('percent')[0])
        opts['cv_N'] = int(ceil(percent * nPoints)/100.)
    if opts["maxCoefConst"] == "nPoints":
        opts["maxCoefConst"] = nPoints - opts['cv_N']

    if len(xVals) < opts['cv_N']:
        warnings.warn("{} has only {} data points for nLSO={}.\n".format(
                name, len(xVals), opts['cv_N']) + "returning empty fit.")
        return res, -1

    maxCoefs = opts["maxCoefConst"]

    # Set up LSO data
    nTrials = opts['cv_nTrials']
    nLSO = opts['cv_N']
    if nLSO >= nPoints:
        warnings.warn("Lowering nLSO to nPoints - 1 = %s"%(nPoints-1))
        opts['cv_N'] = nPoints-1
        nLSO = nPoints - 1
    nFit = nPoints - nLSO
    if maxCoefs > nFit:
        warnings.warn("Lowering maxCoefs to nPoints - nLSO = %s"%nFit)
        maxCoefs = nFit
    fit_xVals_NT = []
    fit_yVals_NT = []
    lso_xVals_NT = []
    lso_yVals_NT = []
    for i in range(nTrials):
        tmp_fit, tmp_lso = sampleLSO(nPoints, nLSO, opts['cv_crucial_indices'])
        # uncomment to check if parallel fits are sampling correctly
        #import os
        #print("PID %i CV %i of (ntrials = %i)"%(os.getpid(), i,nTrials)+str(tmp_lso))
        fit_xVals_NT.append(xVals[tmp_fit])
        fit_yVals_NT.append(yVals[tmp_fit])
        lso_xVals_NT.append(xVals[tmp_lso])
        lso_yVals_NT.append(yVals[tmp_lso])

    # Set up the (initially non-orthonormal) basis vectors
    allBFOrders = getBFOrders(opts['bfMaxOrders'])
    bVecs_NT = [np.array([
                  np.prod(
                    np.array([
                      evaluate_fit.basisFunction(
                        opts['bfTypes'][j],
                        tmpI[j],
                        opts['minVals'][j],
                        opts['maxVals'][j]
                      )(fit_xVals_NT[iTrial][:,j])
                      for j in range(dim)]), 0)
                  for tmpI in allBFOrders])
                for iTrial in range(nTrials)]

    origBVecs_lso_NT = [np.array([
                  np.prod(
                    np.array([
                      evaluate_fit.basisFunction(
                        opts['bfTypes'][j],
                        tmpI[j],
                        opts['minVals'][j],
                        opts['maxVals'][j]
                      )(lso_xVals_NT[iTrial][:,j])
                      for j in range(dim)]), 0)
                  for tmpI in allBFOrders])
                for iTrial in range(nTrials)]

    # We update fit_resids by subtracting projections, and update
    # lso_resids by evaluating the fit
    lso_resids_NT = [1.*yy for yy in lso_yVals_NT]
    fit_resids_NT = [1.*yy for yy in fit_yVals_NT]

    innerProducts_NT = [dotMany(bVecs, resids).conjugate()
                        for bVecs, resids in zip(bVecs_NT, fit_resids_NT)]
    res['rmsLSOResids'].append(rms_NT(lso_resids_NT))
    res['rmsMaxLSOResids'].append(rms_max(lso_resids_NT))

    # Keep track of the manipulations of the basis functions so we can
    # convert the coefficients for the orthonormal basis functions to
    # coefficients for the original basis functions
    testCoefs_NT = [np.identity(len(bVecs)) for bVecs in bVecs_NT]
    if np.iscomplexobj(bVecs_NT[0]):
        testCoefs_NT = [(1. + 0.j)*testCoefs for testCoefs in testCoefs_NT]

    coefs_NT = [[] for _ in range(nTrials)]
    iUsed_NT = [[] for _ in range(nTrials)]

    while len(iUsed_NT[0]) < min(maxCoefs, len(allBFOrders)):

        for i in range(nTrials):

            # Add another basis vector
            iNext = np.argmax(abs(innerProducts_NT[i]))
            if iNext in iUsed_NT[i]:
                raise Exception("{}: Trying to use already used bVec".format( \
                    name))

            n = norm(bVecs_NT[i][iNext])
            bNext = bVecs_NT[i][iNext]/n
            testCoefs_NT[i][iNext] = testCoefs_NT[i][iNext]/n
            coefs_NT[i].append(dot(fit_resids_NT[i], bNext))
            iUsed_NT[i].append(iNext)
            bVecs_NT[i][iNext] *= 0.

            # Subtract projections to make remaining bVecs orthogonal.
            # Do NOT re-normalize them, or we would have the wrong testCoefs
            dots = dotMany(bVecs_NT[i], bNext)
            bVecs_NT[i] -= np.outer(dots, bNext)
            testCoefs_NT[i] -= np.outer(dots, testCoefs_NT[i][iNext])

            # Update residuals and inner products
            fit_resids_NT[i] -= coefs_NT[i][-1]*bNext
            lso_resids_NT[i] = lso_yVals_NT[i] - (np.array(coefs_NT[i]).dot(
                    testCoefs_NT[i][iUsed_NT[i]][:,iUsed_NT[i]])).dot(
                    origBVecs_lso_NT[i][iUsed_NT[i]])
            innerProducts_NT[i] = dotMany(bVecs_NT[i], fit_resids_NT[i]).conjugate()


        # Succesfully added another basis vector, Update res
        res['rmsMaxLSOResids'].append(rms_max(lso_resids_NT))
        res['rmsLSOResids'].append(rms_NT(lso_resids_NT))


    # Now determine the optimal number of coefficients to use in the fit,
    # but always use at least one.
    n_coefs = max(1, np.argmin(res['rmsMaxLSOResids']))

    # Now we redo the fit using all the data!
    bVecs = np.array([
              np.prod(
                np.array([
                  evaluate_fit.basisFunction(
                    opts['bfTypes'][j],
                    tmpI[j],
                    opts['minVals'][j],
                    opts['maxVals'][j]
                  )(xVals[:,j])
                  for j in range(dim)]), 0)
              for tmpI in allBFOrders])
    resids = 1.*yVals
    innerProducts = dotMany(bVecs, resids).conjugate()
    testCoefs = np.identity(len(bVecs))
    if np.iscomplexobj(bVecs):
        testCoefs = (1. + 0.j)*testCoefs
    coefs = []
    iUsed = []
    res['rmsResids'].append(rms(resids))
    res['maxResids'].append(max(abs(resids)))

    while len(iUsed) < n_coefs:

        # Add another basis vector
        iNext = np.argmax(abs(innerProducts))
        n = norm(bVecs[iNext])
        bNext = bVecs[iNext]/n
        testCoefs[iNext] = testCoefs[iNext]/n
        coefs.append(dot(resids, bNext))
        iUsed.append(iNext)
        bVecs[iNext] *= 0.

        # Subtract projections to make remaining bVecs orthogonal.
        # Do NOT re-normalize them, or we would have the wrong testCoefs
        dots = dotMany(bVecs, bNext)
        bVecs -= np.outer(dots, bNext)
        testCoefs -= np.outer(dots, testCoefs[iNext])

        # Update residuals and inner products
        resids -= coefs[-1]*bNext
        innerProducts = dotMany(bVecs, resids).conjugate()

        # Succesfully added another basis vector, Update res
        res['coefs'] = np.array(coefs).dot(testCoefs[iUsed][:,iUsed])
        res['bfOrders'].append(allBFOrders[iNext])
        res['rmsResids'].append(rms(resids))
        res['maxResids'].append(max(abs(resids)))

    print("%s results: %s coefs, %s rms max test error, %s max residual"%(
            name, len(res['coefs']), min(res['rmsMaxLSOResids']),
            res['maxResids'][-1]))

    return res, 6



def getBFOrders(bfMaxOrders):
    if type(bfMaxOrders) == str and bfMaxOrders[:4] == '4d2s':
        return get_4d2s_max_orders(bfMaxOrders)
    if type(bfMaxOrders) == str and bfMaxOrders[:8] == 'Sin 4d2s':
        return get_4d2s_sin_max_orders(bfMaxOrders)
    if type(bfMaxOrders) == str and bfMaxOrders[:4] == 'test':
        return get_test_max_orders(bfMaxOrders)
    if len(bfMaxOrders) == 0:
        return []
    if len(bfMaxOrders) == 1:
        return [[i] for i in range(bfMaxOrders[0] + 1)]
    recursiveResults = getBFOrders(bfMaxOrders[:-1])
    bfOrders = []
    for c in recursiveResults:
        for i in range(bfMaxOrders[-1] + 1):
            tmp = [j for j in c]
            tmp.append(i)
            bfOrders.append(tmp)
    return bfOrders

def get_4d2s_max_orders(bfMaxOrders):
    if bfMaxOrders[:4] != '4d2s':
        raise Exception("Unexpected bfMaxOrders: %s" % bfMaxOrders)
    print("Using 4d2s bfMaxOrders (n_theta <= n_chi)")
    orders = [int(s) for s in bfMaxOrders[5:].split()]
    if len(orders) != 4:
        raise Exception("4d2s is 4d, not %sd" % len(orders))
    bfOrders = []
    for n1 in range(orders[0]+1):
        for n2 in range(orders[1]+1):
            for n3 in range(n2+1):
                for n4 in range(orders[3] + 1):
                    bfOrders.append([n1, n2, n3, n4])
    return bfOrders

def get_4d2s_sin_max_orders(bfMaxOrders):
    if bfMaxOrders[:8] != 'Sin 4d2s':
        raise Exception("Unexpected bfMaxOrders: %s" % bfMaxOrders)
    print("Using 4d2s sin bfMaxOrders (n_theta <= n_chi - 1)")
    orders = [int(s) for s in bfMaxOrders[9:].split()]
    if len(orders) != 4:
        raise Exception("4d2s is 4d, not %sd" % len(orders))
    bfOrders = []
    for n1 in range(orders[0]+1):
        for n2 in range(1, orders[1]+1):
            for n3 in range(orders[2]+1):
                for n4 in range(orders[3] + 1):
                    bfOrders.append([n1, n2, n3, n4])
    return bfOrders

def get_test_max_orders(bfMaxOrders):
    print("Using test bfMaxOrders")
    orders = [int(s) for s in bfMaxOrders[5:].split()]
    if len(orders) != 3:
        raise Exception("test is 3d, not %sd" % len(orders))
    bfOrders = []
    for n1 in range(orders[0]+1):
        for n2 in range(n1+1):
            for n3 in range(orders[2]+1):
                bfOrders.append([n1, n2, n3])
    return bfOrders



def sampleLSO(nPoints, nLSO, crucialIndices):
    if nLSO + len(crucialIndices) > nPoints:
        raise Exception("%s=nLSO larger than %s - %s crucial points!"%(
                nLSO, nPoints, len(crucialIndices)))
    lso_indices = []
    while len(lso_indices) < nLSO:
        tmp_indices = np.random.choice(range(nPoints), size = nLSO - len(lso_indices), replace=False)
        for i in tmp_indices:
            if (i not in lso_indices) and (i not in crucialIndices):
                lso_indices.append(i)
    fit_indices = [i for i in range(nPoints) if i not in lso_indices]
    return fit_indices, lso_indices


##############################################################################

# ---------------------------------------------------------------------------
def greedy_fit_wrapper(xVals, yVals, name, **options):
    """
Wrapper for _greedy_fit() and _cross_validation_fit()
Does least squares in a greedy way, starting with 0 coefficients
and adding more until we reach one of several termination criteria:
    1. All residuals are below (absTol + relTol*yVals)
    2. The root-mean-square residual is below or equal the rmsCutoff
    3. We reach maxCoefs = int(maxCoefConst + n*maxCoefFrac) coefficients
    4. The root-mean-square residual would increase if we continued,
        indicating numerical roundoff errors
    5. We use all available coefficients
The coefficients multiply normalized basis vectors which are basis
functions evaluated at xVals (or multiplied-combinations of basis
functions for multi-dimensional fits).
At each iteration, we project the residuals onto all unused basis
vectors and add the one with the largest projection,
reducing the root-mean-square residual as much as possible.
The remaining unused basis vectors are then orthonormalized with
respect to the used basis vectors.

inputs:
-------

xVals: A 2d array of domain values, with shape (nPoints, dim).
yVals: A 1d array of real or complex values with shape (nPoints,).
name: An identifying string used in printed output/warnings/errors.

options:
--------
bfTypes: A basis function type or a list/array with one per dim.
    See evaluate_fit.bf_dict.keys() for options. Default 'polynomial'

bfMaxOrders: The maximum 'n' allowed in the basis functions,
    or a list/array with one per dimension.
    For example, [2, 3] would allow quadratic in x[0] and cubic
    in x[1] for 'polynomial' basis functions.
    Default 'fromData', which uses (nPoints - 1).
    Also allowed is '4d2s n1 n2 n3 n4' where n1, ..., n4 are
    integers.  Similar to [n1, n2, n3, n4] except that degrees
    higher than 0 in x[2] are only allowed when the degree of
    x[1] is at least 1 (no theta dependence when |chiA| == 0)

minVals: A minimum value for domain values, or a list/array
    with one value per dimension. Default 0.

maxVals: Similar to minVals. Default 1.

absTol: Absolute tolerance for residuals. Default 0.

relTol: Relative tolerance for residuals. Default 0.

rmsCutoff: Tolerance for the RMS of the residuals. Default 0.
           Also allowed is 'crossValidation' which does a cross-validation fit

cv_N: Number of points to leave out in a cross-validation fit.
      Default 10%

cv_nTrials: Number of different times to perform a trial fit leaving random
            data out for a cross-validation fit. Default 1.

cv_crucial_indices: A list of data indices that should never be left out
                    in a cross-validation fit. Default []

maxCoefConst: Max number of fit coefficients to use. Default 'nPoints'.

useReconstructionErrors: Instead of monitoring projection residuals,
    compute the residuals directly at each greedy iteration.
    More expensive, but addresses numerical roundoff.
    Default True.

returns:
--------
results

results: A dictionary containing all relevant fit information.
    Use evaluate_fit.getFitEvaluator(result) in fit.py to get the fit function.
    """

    if 'rmsCutoff' in options and options['rmsCutoff'] == 'crossValidation':
        res, tc = _cross_validation_fit(xVals, yVals, name, **options)
    else:
        res, tc = _greedy_fit(xVals, yVals, name, **options)

    res["bfOrders"] = np.array(res["bfOrders"])
    res["rmsResids"] = np.array(res["rmsResids"])
    res["maxResids"] = np.array(res["maxResids"])
    res["terminationCriterion"] = tc

    return res
