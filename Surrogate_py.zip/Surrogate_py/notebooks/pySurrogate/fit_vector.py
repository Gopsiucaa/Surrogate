#!/usr/bin/python
import numpy as np
from math import pi, ceil
import warnings

class BasisFunction:
    def __init__(self, name, func, minX, maxX):
        """name: A name (for example, 'cosine')
        func: f(n, x) gives the n'th basis function evaluated at x
            for example, lambda n, x: np.cos(n*x)
        minX, maxX: The default domain (for example, minX=0, maxX=pi)
            If the user's domain is different, linearly maps to the default.
            Can give None, in which case the domain is not mapped.
        """
        self.name = name
        self.func = func
        self.minX = minX
        if len([tmp for tmp in [minX, maxX] if tmp is None]) == 1:
            raise Exception('Must have both or neither minX=None, maxX=None') 
        if self.minX is None:
            self.width = None
        else:
            self.width = maxX - minX

    def __call__(self, n, x):
        return self.func(n, x)

    def mappedFunc(self, n, minX, maxX):
        if self.minX is None:
            return lambda x: self.func(n, x)
        def newFunc(x):
            return self(n, self.minX + (x-minX)*self.width/(maxX-minX))
        return newFunc

################# Define some commonly used BasisFunctions ###################

_polynomial = BasisFunction(
        'polynomial',
        lambda n, x: 1. + 0.*x if n==0 else x**n,
        -1, 1)

_complexPeriodic = BasisFunction(
        'complexPeriodic',
        lambda n, x: np.exp(1.j*n*x/2) if n%2==0 else np.exp(-1.j*(n+1)*x/2),
        0, 2*pi)

_periodic = BasisFunction(
        'periodic',
        lambda n, x: np.cos(n*x/2) if n%2==0 else np.sin((n+1)*x/2),
        0, 2*pi)

_chebychev = BasisFunction(
        'chebyshev',
        lambda n, x: np.polynomial.Chebyshev([0]*n + [1])(x),
        -1, 1)

bf_dict = {
            'polynomial': _polynomial,
            'complexPeriodic': _complexPeriodic,
            'periodic': _periodic,
            'chebyshev': _chebychev,
          }

def basisFunction(typeStr, n, minVal, maxVal, BF_dict=bf_dict):
    return BF_dict[typeStr].mappedFunc(n, minVal, maxVal)

############### Stuff related to greedyVectorFit ###################################

def dot(v1, v2):
    # v1 and v2 both have shape (nPoints, ydim)
    return np.sum(v1 * v2.conjugate())

def norm(v):
    return np.sqrt(abs(dot(v, v)))

def rms(v):
    return np.sqrt(np.mean(abs(v*v)))

def rms_NT(v):
    vv = np.array(v).flatten()
    return rms(vv)

def rms_max(v):
    return rms(np.array([max(tmp) for tmp in v]))

def normalizeMany(manyVs):
    # There is a (n, m) grid of vectors, each with shape (N, d), so
    # manyVs has shape (n, m, N, d).
    norms = np.sqrt(np.sum(abs(manyVs**2), axis=(2, 3)))
    return (manyVs / (norms + 1.*(norms == 0.))[:, np.newaxis, np.newaxis])

def dotMany(manyV1s, v2):
    # manyV1s has shape (n, m, N, d), and v2 has shape (N, d).
    # Each V1 has shape (nPoints, ydim) and v2 has shape (nPoints, ydim)
    return np.sum(manyV1s * v2.conjugate(), axis=(2, 3))

DEFAULTS = {
        'bfTypes': 'chebyshev',
        'bfMaxOrders': 'fromData',
        'minVals': 0.,
        'maxVals': 1.,
        'absTol': 0.,
        'relTol': 0.,
        'rmsCutoff': 0.,
        'maxCoefConst': 'nPoints',
        'maxCoefFrac': 0.,
        'useReconstructionErrors': True,
        }

CV_DEFAULTS = {
        'bfTypes': 'chebyshev',
        'bfMaxOrders': 'fromData',
        'minVals': 0.,
        'maxVals': 1.,
        'rmsCutoff': 'crossValidation',
        'maxCoefConst': 'nPoints',
        'cv_N': '10percent',
        'cv_nTrials': 1,
        'cv_crucial_indices': [],
        }

def tcString(tc):
    if tc == 1:
        return "All residuals are below or equal (absTol + relTol*yVals)"
    if tc == 2:
        return "The root-mean-square residual is below or equal the rmsCutoff"
    if tc == 3:
        return "Reached maxCoefs coefficients"
    if tc == 4:
        return "The root-mean-square residual would increase if we continued."
    if tc == 5:
        return "All available coefficients were used"
    if tc == 6:
        return "Successful cross-validation fit"
    if tc == -1:
        return "Received zero data points, returned empty fit"
    if tc == -2:
        return "The chosen basis vector has already been used"
    return "Unknown"

############### The main fit function ########################################

def parallelVectorGreedyFit(kwargs):

    # process-level seed
    np.random.seed(None)

    return greedyVectorFit(**kwargs)

def greedyVectorFit(bVecs, xVals, yVals, name='Fit', **options):
    """
Like fit_greedy.greedy_fit, but fits vector yVals as a linear combination of
basis vectors bVecs, where each linear coefficient is a function
of the xVals formed through a linear combination of basis function
products.
In otherwords, if there are n bVecs, forms n sets of coefficients,
and has
    vector_fitted_function(x) = \sum_{i=1}^n scalar_fit_i(x) * bVecs[i]
but the n sets of coefficients are determined at the same time.
Can have n != the vector dimension of the bVecs and yVals.
Having a smaller n will likely not give a good fit unless the yVals
belong to a subspace. Having a larger n is fine because we use the
greedy fit method, so including all relelvant vectors can be useful.

inputs:
-------
bVecs: A list or array of n basis vectors. Each basis vector can either
       be a 1d array with length ydim, in which case it is independent
       of x, or it can depend on x in some way and be a 2d array with
       shape (nPoints, ydim). If all vectors are independent of x,
       the fits can be evaluated as usual by simply passing in x.
       Otherwise, an array of shape (n, ydim) must also be passed to
       the vector fit evaluator giving the n basis vectors.
xVals: A 2d array of domain values, with shape (nPoints, xdim).
yVals: A 2d array of real or complex values with shape (nPoints, ydim).
name: An identifying string used in printed output/warnings/errors.

options:
--------
see the regular fit_greedy.greedy_fit docstring.

returns:
--------
results

results: A dictionary containing all relevant fit information.
    Use getVectorFitEvaluator(result) to get the fit function.
    """

    if 'rmsCutoff' in options and options['rmsCutoff'] == 'crossValidation':
        res, tc = _cross_validation_vector_fit(bVecs, xVals, yVals, name, **options)
    else:
        res, tc = _greedyVectorFit(bVecs, xVals, yVals, name, **options)

    res["bfOrders"] = np.array(res["bfOrders"])
    res["rmsResids"] = np.array(res["rmsResids"])
    res["maxResids"] = np.array(res["maxResids"])
    res["terminationCriterion"] = tc
    return res

def _greedyVectorFit(bVec_list, xVals, yVals, name, **options):
    for k in options:
        if k not in list(DEFAULTS.keys()):
            raise Exception('Invalid option: {}'.format(k))

    # Get a bVecs array with shape (n_vecs, n_points, ydim)
    bVecs = []
    all_const_bvecs = True
    for b in bVec_list:
        b = np.array(b)
        if len(b.shape) == 2:
            bVecs.append(b)
            all_const_bvecs = False
        else:
            bVecs.append(np.array([b for _ in yVals]))
    bVecs = np.array(bVecs)

    # If all the bVecs are independent of x, we don't need them
    # to evaluate the fit function
    if all_const_bvecs:
        const_bVecs = np.array(bVec_list)
    else:
        const_bVecs = None

    opts = {k: options.get(k, v) for k, v in DEFAULTS.items()}
    res = {
            "minVals": opts["minVals"],
            "maxVals": opts["maxVals"],
            "bfTypes": opts["bfTypes"],
            "coefs": np.array([]),
            "bfOrders": [],
            "bVecIndices": [],
            "rmsResids": [],
            "maxResids": [],
            "bVecs": const_bVecs,
            }

    if not len(xVals) == len(yVals):
        raise ValueError("Cannot fit {} with {} xVals and {} yVals".format(
                name, len(xVals), len(yVals)))
    if len(xVals) == 0 or len(bVecs) == 0:
        warnings.warn("{} has no data or basis vectors, returning empty fit".format(name))
        return res, -1

    xdim = xVals.shape[1]
    nPoints = xVals.shape[0]
    n = bVecs.shape[0]
    ydim = yVals.shape[1]
    if bVecs.shape[1] != nPoints or bVecs.shape[2] != ydim:
        raise Exception("bVecs shape %s inconsistent with xVals, yVals = %s, %s"%(
                bVecs.shape, xVals.shape, yVals.shape))

    # Make opts have a standard format
    if opts["maxCoefConst"] == "nPoints":
        opts["maxCoefConst"] = nPoints * ydim
    if not type(opts['minVals']) in [list, np.ndarray]:
        opts['minVals'] = np.array([opts['minVals'] for _ in range(xdim)])
        res['minVals'] = opts['minVals']
    if not type(opts['maxVals']) in [list, np.ndarray]:
        opts['maxVals'] = np.array([opts['maxVals'] for _ in range(xdim)])
        res['maxVals'] = opts['maxVals']
    if type(opts['bfTypes']) == str:
        opts['bfTypes'] = [opts['bfTypes'] for _ in range(xdim)]
        res['bfTypes'] = opts['bfTypes']
    if opts['bfMaxOrders'] == 'fromData':
        opts['bfMaxOrders'] = nPoints - 1
    if type(opts['bfMaxOrders']) == int:
        opts['bfMaxOrders'] = [opts['bfMaxOrders'] for _ in range(xdim)]

    maxCoefs = opts["maxCoefConst"] + int(nPoints*opts["maxCoefFrac"]*ydim)
    if maxCoefs > nPoints * ydim:
        warnings.warn("{} has maxCoefs > ydim * nPoints!".format(name))

    # Set up the (initially non-orthonormal) feature vectors.
    # Note that if constant bVecs are given as a 2d array, the (n bVecs X n BFOrders)
    # grid of feature vectors will initially have a tensor product structure but we
    # will lose this structure once we iterate.
    allBFOrders = getBFOrders(opts['bfMaxOrders'])

    scalar_features = np.array([
                    np.prod(
                      np.array([
                        basisFunction(
                          opts['bfTypes'][j],
                          tmpI[j],
                          opts['minVals'][j],
                          opts['maxVals'][j]
                        )(xVals[:,j])
                        for j in range(xdim)]), 0)
                    for tmpI in allBFOrders])

    vector_features = np.array([scalar_features[:, :, np.newaxis] * b for b in bVecs])

    orig_vec_features = np.copy(vector_features)

    # We update resids by subtracting projections, and update
    # true resids by evaluating the fit when useReconstructionErrors=True.
    trueResids = 1.*yVals
    resids = 1.*yVals

    innerProducts = dotMany(vector_features, resids).conjugate()
    res['rmsResids'].append(rms(resids))
    res['maxResids'].append(np.max(abs(resids)))

    # Keep track of the manipulations of the basis functions so we can
    # convert the coefficients for the orthonormal basis functions to
    # coefficients for the original basis functions
    basis_norms = []
    dots_with_basis_vecs = []

    tol = opts['absTol'] + opts['relTol']*yVals
    coefs = []
    iUsed = []
    while len(iUsed) < min(maxCoefs, n * nPoints):
        # Check for residual termination
        if np.all(abs(trueResids) <= tol):
            return res, 1
        if rms(trueResids) <= opts['rmsCutoff']:
            return res, 2

        # Find the next feature vector + basis vector combination
        i1_next = np.argmax(np.amax(abs(innerProducts), axis=1))
        i2_next = np.argmax(abs(innerProducts[i1_next]))
        if (i1_next, i2_next) in iUsed:
            warnings.warn("{}: Already used bVec, have {} coefs".format(
                    name, len(coefs)))
            return res, -2
        nrm = norm(vector_features[i1_next, i2_next])
        basis_norms.append(nrm)
        bNext = 1. * vector_features[i1_next, i2_next] / nrm
        coefs.append(dot(resids, bNext))
        iUsed.append((i1_next, i2_next))
        vector_features[i1_next, i2_next] *= 0.

        # Subtract projections to make remaining featureVecs orthogonal.
        # Do NOT re-normalize them, or we would have the wrong testCoefs
        dots = dotMany(vector_features, bNext)
        vector_features -= np.tensordot(dots, bNext, 0)
        dots_with_basis_vecs.append(dots)

        # Update residuals and inner products
        actual_coefs = _compute_actual_coefs(coefs, iUsed, basis_norms, dots_with_basis_vecs)
        resids -= coefs[-1]*bNext
        if opts['useReconstructionErrors']:
            tmp_vec = np.array([orig_vec_features[i1, i2] for i1, i2 in iUsed])
            yFit = np.tensordot(actual_coefs, tmp_vec, 1)
            trueResids = yVals - yFit
        else:
            trueResids -= coefs[-1]*bNext
        if rms(trueResids) > 1.01*res['rmsResids'][-1]:
            warnings.warn("{}: Adding coef {} increased rms resids".format(
                    name, len(coefs)))
            if not opts['useReconstructionErrors']:
                raise Exception('This should never happen')
            return res, 4
        innerProducts = dotMany(vector_features, resids).conjugate()

        # Succesfully added another basis vector, Update res
        res['maxResids'].append(np.max(abs(trueResids)))
        res['rmsResids'].append(rms(trueResids))
        res['coefs'] = actual_coefs
        res['bfOrders'].append(allBFOrders[i2_next])
        res['bVecIndices'].append(i1_next)

    if len(iUsed) == maxCoefs:
        return res, 3
    return res, 5

##############################################################################
def _compute_actual_coefs(coefs, iUsed, basis_norms, dots_with_basis_vecs):
    """
    Performs identical linear algebra manipulations on the identity matrix
    to transform the coefficients for the modified basis vectors to the
    coefficients for the original basis vectors
    """
    n = len(coefs)

    testCoefs = np.identity(n)
    for i in range(n):
        testCoefs[i] /= basis_norms[i]
        iu1, iu2 = iUsed[i]
        assert dots_with_basis_vecs[i][iu1, iu2] == 0.
        for j, (iu1, iu2) in enumerate(iUsed):
            testCoefs[j] -= testCoefs[i] * dots_with_basis_vecs[i][iu1, iu2]

    return np.array(coefs).dot(testCoefs)

##############################################################################

def _cross_validation_vector_fit(bVec_list, xVals, yVals, name, **options):

    for k in options:
        if k not in list(CV_DEFAULTS.keys()):
            raise Exception('Invalid option for cv fit: {}'.format(k))

    # Get a bVecs array with shape (n_vecs, n_points, ydim)
    bVecs = []
    all_const_bvecs = True
    for b in bVec_list:
        b = np.array(b)
        if len(b.shape) == 2:
            bVecs.append(b)
            all_const_bvecs = False
        else:
            bVecs.append(np.array([b for _ in yVals]))
    bVecs = np.array(bVecs)

    # If all the bVecs are independent of x, we don't need them
    # to evaluate the fit function
    if all_const_bvecs:
        const_bVecs = np.array(bVec_list)
    else:
        const_bVecs = None

    opts = {k: options.get(k, v) for k, v in CV_DEFAULTS.items()}
    res = {
            "minVals": opts["minVals"],
            "maxVals": opts["maxVals"],
            "bfTypes": opts["bfTypes"],
            "coefs": np.array([]),
            "bfOrders": [],
            "bVecIndices": [],
            "rmsResids": [],
            "maxResids": [],
            "rmsLSOResids": [],
            "rmsMaxLSOResids": [],
            "bVecs": const_bVecs,
            }

    if not len(xVals) == len(yVals):
        raise ValueError("Cannot fit {} with {} xVals and {} yVals".format(
                name, len(xVals), len(yVals)))
    if len(xVals) == 0 or len(bVecs) == 0:
        warnings.warn("{} has no data or basis vectors, returning empty fit".format(name))
        return res, -1

    xdim = xVals.shape[1]
    nPoints = xVals.shape[0]
    n = bVecs.shape[0]
    ydim = yVals.shape[1]
    if bVecs.shape[1] != nPoints or bVecs.shape[2] != ydim:
        raise Exception("bVecs shape %s inconsistent with xVals, yVals = %s, %s"%(
                bVecs.shape, xVals.shape, yVals.shape))

    # Make opts have a standard format
    if opts["maxCoefConst"] == "nPoints":
        opts["maxCoefConst"] = nPoints * ydim
    if not type(opts['minVals']) in [list, np.ndarray]:
        opts['minVals'] = np.array([opts['minVals'] for _ in range(xdim)])
        res['minVals'] = opts['minVals']
    if not type(opts['maxVals']) in [list, np.ndarray]:
        opts['maxVals'] = np.array([opts['maxVals'] for _ in range(xdim)])
        res['maxVals'] = opts['maxVals']
    if type(opts['bfTypes']) == str:
        opts['bfTypes'] = [opts['bfTypes'] for _ in range(xdim)]
        res['bfTypes'] = opts['bfTypes']
    if opts['bfMaxOrders'] == 'fromData':
        opts['bfMaxOrders'] = nPoints - 1
    if type(opts['bfMaxOrders']) == int:
        opts['bfMaxOrders'] = [opts['bfMaxOrders'] for _ in range(xdim)]
    if type(opts['cv_N']) == str:
        percent = float(opts['cv_N'].split('percent'))
        opts['cv_N'] = int(ceil(percent*nPoints / 100.0))
    maxCoefs = opts["maxCoefConst"]
    if maxCoefs > nPoints * ydim:
        warnings.warn("{} has maxCoefs > ydim * nPoints!".format(name))

    if not len(xVals) == len(yVals):
        raise ValueError("Cannot fit {} with {} xVals and {} yVals".format(
                name, len(xVals), len(yVals)))
    if len(xVals) < opts['cv_N']:
        warnings.warn("{} has only {} data points for nLSO={}.\n".format(
                name, len(xVals), opts['cv_N']) + "returning empty fit.")
        return res, -1

    # Set up LSO data
    nTrials = opts['cv_nTrials']
    nLSO = opts['cv_N']
    if nLSO >= nPoints:
        warnings.warn("Lowering nLSO to nPoints - 1 = %s"%(nPoints-1))
        opts['cv_N'] = nPoints-1
        nLSO = nPoints - 1
    nFit = nPoints - nLSO
    if maxCoefs > nFit:
        warnings.warn("Lowering maxCoefs to nPoints - nLSO = %s"%nFit)
        maxCoefs = nFit
    fit_xVals_NT = []
    fit_yVals_NT = []
    fit_bVecs_NT = []
    lso_xVals_NT = []
    lso_yVals_NT = []
    lso_bVecs_NT = []
    for i in range(nTrials):
        tmp_fit, tmp_lso = sampleLSO(nPoints, nLSO, opts['cv_crucial_indices'])
        fit_xVals_NT.append(xVals[tmp_fit])
        fit_yVals_NT.append(yVals[tmp_fit])
        fit_bVecs_NT.append(bVecs[:, tmp_fit])
        lso_xVals_NT.append(xVals[tmp_lso])
        lso_yVals_NT.append(yVals[tmp_lso])
        lso_bVecs_NT.append(bVecs[:, tmp_lso])

    allBFOrders = getBFOrders(opts['bfMaxOrders'])

    # Loop over nTrials first so that we don't need to store nTrials
    # copies of everything in memory, only store resids.
    max_lso_resids_NT = [[] for _ in range(nTrials)]
    rms_lso_resids_NT = [[] for _ in range(nTrials)]

    for i in range(nTrials):
        # Setup data (see _greedyVectorFit for comments)
        scalar_features = np.array([
                    np.prod(
                      np.array([
                        basisFunction(
                          opts['bfTypes'][j],
                          tmpI[j],
                          opts['minVals'][j],
                          opts['maxVals'][j]
                        )(fit_xVals_NT[i][:,j])
                        for j in range(xdim)]), 0)
                    for tmpI in allBFOrders])

        lso_scalar_features = np.array([
                    np.prod(
                      np.array([
                        basisFunction(
                          opts['bfTypes'][j],
                          tmpI[j],
                          opts['minVals'][j],
                          opts['maxVals'][j]
                        )(lso_xVals_NT[i][:,j])
                        for j in range(xdim)]), 0)
                    for tmpI in allBFOrders])

        vector_features = np.array([scalar_features[:, :, np.newaxis] * b for b in fit_bVecs_NT[i]])
        lso_vector_features = np.array([lso_scalar_features[:, :, np.newaxis] * b for b in lso_bVecs_NT[i]])

        lso_resids = 1. * lso_yVals_NT[i]
        fit_resids = 1. * fit_yVals_NT[i]

        max_lso_resids_NT[i].append(np.max(abs(lso_resids)))
        rms_lso_resids_NT[i].append(rms(lso_resids))

        innerProducts = dotMany(vector_features, fit_resids).conjugate()

        basis_norms = []
        dots_with_basis_vecs = []
        coefs = []
        iUsed = []

        while len(iUsed) < min(maxCoefs, n * nPoints):
            # Find the next feature vector + basis vector combination
            i1_next = np.argmax(np.amax(abs(innerProducts), axis=1))
            i2_next = np.argmax(abs(innerProducts[i1_next]))
            if (i1_next, i2_next) in iUsed:
                raise Exception("{}: Already used bVec, have {} coefs".format(
                        name, len(coefs)))
            nrm = norm(vector_features[i1_next, i2_next])
            basis_norms.append(nrm)
            bNext = 1. * vector_features[i1_next, i2_next] / nrm
            coefs.append(dot(fit_resids, bNext))
            iUsed.append((i1_next, i2_next))
            vector_features[i1_next, i2_next] *= 0.

            # Subtract projections to make remaining featureVecs orthogonal.
            dots = dotMany(vector_features, bNext)
            vector_features -= np.tensordot(dots, bNext, 0)
            dots_with_basis_vecs.append(dots)

            # Update residuals and inner products
            actual_coefs = _compute_actual_coefs(coefs, iUsed, basis_norms, dots_with_basis_vecs)
            fit_resids -= coefs[-1]*bNext
            tmp_vec = np.array([lso_vector_features[i1, i2] for i1, i2 in iUsed])
            yFit = np.tensordot(actual_coefs, tmp_vec, 1)
            lso_resids = lso_yVals_NT[i] - yFit
            max_lso_resids_NT[i].append(np.max(abs(lso_resids)))
            rms_lso_resids_NT[i].append(rms(np.array(lso_resids)))
            innerProducts = dotMany(vector_features, fit_resids).conjugate()

    # Now determine the optimal number of coefficients to use in the fit
    res['rmsMaxLSOResids'] = [rms(resids) for resids in np.array(max_lso_resids_NT).T]
    res['rmsLSOResids'] = [rms(resids) for resids in np.array(rms_lso_resids_NT).T]
    n_coefs = np.argmin(res['rmsMaxLSOResids'])

    # Now we redo the fit using all the data!
    scalar_features = np.array([
                    np.prod(
                      np.array([
                        basisFunction(
                          opts['bfTypes'][j],
                          tmpI[j],
                          opts['minVals'][j],
                          opts['maxVals'][j]
                        )(xVals[:,j])
                        for j in range(xdim)]), 0)
                    for tmpI in allBFOrders])

    vector_features = np.array([scalar_features[:, :, np.newaxis] * b for b in bVecs])
    orig_vec_features = np.copy(vector_features)

    # We update resids by subtracting projections, and update
    # true resids by evaluating the fit when useReconstructionErrors=True.
    trueResids = 1.*yVals
    resids = 1.*yVals

    innerProducts = dotMany(vector_features, resids).conjugate()
    res['rmsResids'].append(rms(resids))
    res['maxResids'].append(np.max(abs(resids)))

    # Keep track of the manipulations of the basis functions so we can
    # convert the coefficients for the orthonormal basis functions to
    # coefficients for the original basis functions
    basis_norms = []
    dots_with_basis_vecs = []

    coefs = []
    iUsed = []
    while len(iUsed) < n_coefs:

        # Find the next feature vector + basis vector combination
        i1_next = np.argmax(np.amax(abs(innerProducts), axis=1))
        i2_next = np.argmax(abs(innerProducts[i1_next]))
        if (i1_next, i2_next) in iUsed:
            warnings.warn("{}: Already used bVec, have {} coefs".format(
                    name, len(coefs)))
            return res, -2
        nrm = norm(vector_features[i1_next, i2_next])
        basis_norms.append(nrm)
        bNext = 1. * vector_features[i1_next, i2_next] / nrm
        coefs.append(dot(resids, bNext))
        iUsed.append((i1_next, i2_next))
        vector_features[i1_next, i2_next] *= 0.

        # Subtract projections to make remaining featureVecs orthogonal.
        # Do NOT re-normalize them, or we would have the wrong testCoefs
        dots = dotMany(vector_features, bNext)
        vector_features -= np.tensordot(dots, bNext, 0)
        dots_with_basis_vecs.append(dots)

        # Update residuals and inner products
        actual_coefs = _compute_actual_coefs(coefs, iUsed, basis_norms, dots_with_basis_vecs)
        resids -= coefs[-1]*bNext
        tmp_vec = np.array([orig_vec_features[i1, i2] for i1, i2 in iUsed])
        yFit = np.tensordot(actual_coefs, tmp_vec, 1)
        trueResids = yVals - yFit
        innerProducts = dotMany(vector_features, resids).conjugate()

        # Succesfully added another basis vector, Update res
        res['maxResids'].append(np.max(abs(trueResids)))
        res['rmsResids'].append(rms(trueResids))
        res['coefs'] = actual_coefs
        res['bfOrders'].append(allBFOrders[i2_next])
        res['bVecIndices'].append(i1_next)

    print("%s results: %s coefs, %s rms max test error, %s max residual"%(
            name, len(res['coefs']), min(res['rmsMaxLSOResids']),
            res['maxResids'][-1]))

    return res, 6

##############################################################################
def getBFOrders(bfMaxOrders):
    if type(bfMaxOrders) == str and bfMaxOrders[:4] == '4d2s':
        return get_4d2s_max_orders(bfMaxOrders)
    if type(bfMaxOrders) == str and bfMaxOrders[:8] == 'Sin 4d2s':
        return get_4d2s_sin_max_orders(bfMaxOrders)
    if type(bfMaxOrders) == str and bfMaxOrders[:4] == 'test':
        return get_test_max_orders(bfMaxOrders)
    if len(bfMaxOrders) == 0:
        return []
    if len(bfMaxOrders) == 1:
        return [[i] for i in range(bfMaxOrders[0] + 1)]
    recursiveResults = getBFOrders(bfMaxOrders[:-1])
    bfOrders = []
    for c in recursiveResults:
        for i in range(bfMaxOrders[-1] + 1):
            tmp = [j for j in c]
            tmp.append(i)
            bfOrders.append(tmp)
    return bfOrders

def get_4d2s_max_orders(bfMaxOrders):
    if bfMaxOrders[:4] != '4d2s':
        raise Exception("Unexpected bfMaxOrders: %s" % bfMaxOrders)
    print("Using 4d2s bfMaxOrders (n_theta <= n_chi)")
    orders = [int(s) for s in bfMaxOrders[5:].split()]
    if len(orders) != 4:
        raise Exception("4d2s is 4d, not %sd" % len(orders))
    bfOrders = []
    for n1 in range(orders[0]+1):
        for n2 in range(orders[1]+1):
            for n3 in range(n2+1):
                for n4 in range(orders[3] + 1):
                    bfOrders.append([n1, n2, n3, n4])
    return bfOrders

def get_4d2s_sin_max_orders(bfMaxOrders):
    if bfMaxOrders[:8] != 'Sin 4d2s':
        raise Exception("Unexpected bfMaxOrders: %s" % bfMaxOrders)
    print("Using 4d2s sin bfMaxOrders (n_theta <= n_chi - 1)")
    orders = [int(s) for s in bfMaxOrders[9:].split()]
    if len(orders) != 4:
        raise Exception("4d2s is 4d, not %sd" % len(orders))
    bfOrders = []
    for n1 in range(orders[0]+1):
        for n2 in range(1, orders[1]+1):
            for n3 in range(orders[2]+1):
                for n4 in range(orders[3] + 1):
                    bfOrders.append([n1, n2, n3, n4])
    return bfOrders

def get_test_max_orders(bfMaxOrders):
    print("Using test bfMaxOrders")
    orders = [int(s) for s in bfMaxOrders[5:].split()]
    if len(orders) != 3:
        raise Exception("test is 3d, not %sd" % len(orders))
    bfOrders = []
    for n1 in range(orders[0]+1):
        for n2 in range(n1+1):
            for n3 in range(orders[2]+1):
                bfOrders.append([n1, n2, n3])
    return bfOrders


##############################################################################

def getVectorFitEvaluator(res):
    if res['bVecs'] is not None:
        bvec_array = np.array([res['bVecs'][i] for i in res['bVecIndices']])
    else:
        bvec_array = None

    if len(res['coefs']) == 0:
        def fitFunc(x, bVecs=None):
            if res['bVecs'] is None:
                if bVecs is None:
                    raise Exception("For a fit with data-dependent bVecs, must give bVecs!")
                return 0. * bVecs[0]
            return res['bVecs'][0] * 0.
        return fitFunc

    def fitFunc(x, bVecs=None):
        if bvec_array is None:
            if bVecs is None:
                raise Exception("For a fit with data-dependent bVecs, must give bVecs!")
            tmp_bvec_array = np.array([bVecs[i] for i in res['bVecIndices']])
        else:
            tmp_bvec_array = bvec_array

        basisFuncEvals = np.array([
                np.prod(
                  np.array([
                    basisFunction(
                      res['bfTypes'][j],
                      orders[j],
                      res['minVals'][j],
                      res['maxVals'][j])(x[j])
                    for j in range(len(x))]), 0)
                for orders in res['bfOrders']])
        return (res['coefs'] * basisFuncEvals).dot(tmp_bvec_array)
    return fitFunc

##############################################################################

def sampleLSO(nPoints, nLSO, crucialIndices):
    if nLSO + len(crucialIndices) > nPoints:
        raise Exception("%s=nLSO larger than %s - %s crucial points!"%(
                nLSO, nPoints, len(crucialIndices)))
    lso_indices = []
    while len(lso_indices) < nLSO:
        tmp_indices = np.random.choice(range(nPoints), size = nLSO - len(lso_indices), replace=False)
        for i in tmp_indices:
            if (i not in lso_indices) and (i not in crucialIndices):
                lso_indices.append(i)
    fit_indices = [i for i in range(nPoints) if i not in lso_indices]
    return fit_indices, lso_indices

