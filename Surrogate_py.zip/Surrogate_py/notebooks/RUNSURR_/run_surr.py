__authors__ = ["Shaikh., M.A.; Deka, U."]

import os
import sys

pysur_path ="/home/gopalprabhu/Desktop/Surrogate--main/Surrogate_project/Surrogate_py/notebooks/"
sys.path.append(pysur_path)

import numpy as np
from joblib import Parallel, delayed
import lal
import pySurrogate as pysur
from tqdm import tqdm
import pickle
import warnings
from multiprocessing import freeze_support
warnings.filterwarnings("always")
from generate_Ft import Ftilde, PointLens
import time
import logging

# Configure logging
logging.basicConfig(
    filename='run_surr.log',  # Specify the log file name
    level=logging.DEBUG,       # Set the logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)


y_min = 0.05
y_max = 1.0    #This was changed from 2 to 1
param_boundaries = [[y_min, y_max]]
times = np.arange(0.0, 30.0, 1 / 2048)           


def Ft(y, times, Ml, zl, dt_fac=5.0):
    point_lens = PointLens(y)
    ts = 8 * np.pi * lal.MTSUN_SI * Ml * (1 + zl)
    f_min, f_max = 10.0, 1000.0
    t_max = 30
    wmin = ts * f_min
    wmax = ts * f_max
    dt = min(np.pi / wmax / dt_fac, point_lens.img_td / dt_fac)  ##HAD NOTICED REDUCED ERRORS WITH INCREASED dt
    compute_Ft_params = {
        "lens": point_lens,
        "t_max": t_max,
        "dt": dt,
        "verbose": False,
    }
    t, Ft = Ftilde(**compute_Ft_params)
    FtNew = np.interp(times, t, Ft)
    #logging.debug("Ft calculated to be ", {Ft} )
    return FtNew


def create_surrogate(params, times, atol, btol):       ## noticed that atol isnt used anywhere
    sur = pysur.DataModeler(times, "LensAmplification")
    for p in tqdm(params, desc="Training set: "):
    
   
        y = p[0]
        #print("y =",y ,"was set equal to the first element of training set")
        lens_params = {
            "Ml": 100.0,
            "zl": 0.5,
        }
        data = Ft(y, times, **lens_params)
        #print("Ft data generated")
        sur.addKnownDataSet(np.array([np.log(y)]), data)     #np.log (y) changed to just y 
        #print("data set added to sur") 
    print("Creating Empirical Interpolant...")
    sur.createEmpiricalInterpolant(basisTol=btol)
    print("Running GPR fit...")
   
    sur.setupFits(minVals=[np.log(y_min)], maxVals=[np.log(y_max)], fitType="GPR")    ##Could use a different type of fit and try
    sur.fit(nProcs=16)
    print("Surrogate was created and returned")
    return sur


def mismatch(original, prediction, frequencies):
    df = frequencies[1] - frequencies[0]
    match = np.abs(np.sum(original * prediction.conjugate())) * df
    norm_original = np.sqrt(np.sum(np.abs(original) ** 2) * df)
    norm_prediction = np.sqrt(np.sum(np.abs(prediction) ** 2) * df)
    mm = 1 - (match / (norm_original * norm_prediction))                   ## Try defining mismatch in some other way
    return mm


def L2(original, prediction):
    diff = np.sqrt(np.sum(np.abs(original - prediction) ** 2))
    norm = np.sqrt(np.sum(np.abs(original) ** 2))
    return diff / norm


def RandomBulkParams(params_boundaries):
    """Generate a random point in Volume"""
    lower_lims = np.array(params_boundaries).T[0]
    upper_lims = np.array(params_boundaries).T[1]
    # NOTE: np.random.uniform is left inclusive and right exclusive,
    # but that's ok here
    return [
        np.random.uniform(low=lower_lims[i], high=upper_lims[i], size=1)[0]
        for i in range(len(lower_lims))
    ]


def RandomSurfaceParams(params_boundaries):
    """Generate a random point on the surface.
    params_boundaries should be of form:
    [[minVal1, maxVal1],[minVal2, maxVal2],...]
    """
    # NOTE: np.random.randint is left inclusive and right exclusive
    # Choose which param to keep const on the surface
    which_param_surface = np.random.randint(low=0, high=len(params_boundaries), size=1)
    # Choose which end of that param
    which_surface_side = np.random.randint(low=0, high=2, size=1)[0]
    surface_params_boundaries = np.delete(
        np.array(params_boundaries), which_param_surface, axis=0
    )
    # Get params for the non-excluded dims using a Bulk param generator
    surface_params = np.array(RandomBulkParams(surface_params_boundaries))
    const_param = params_boundaries[which_param_surface[0]][which_surface_side]
    return np.insert(surface_params, which_param_surface[0], [const_param], axis=0)


def GenerateRandomParms(size, surface_prob, training_set, params_boundaries):
    """Generate *size* number of random parameters withing the parameter
    ranges.
        Generates points on the surface with probability surface_prob.
        Adds only those parameters not already in the training set.
        params_boundaries should be of form:
    [[minVal1, maxVal1],[minVal2, maxVal2],...]
    """

    if surface_prob < 0 or surface_prob > 1:
        print("ERROR: Invalid probability.")
        exit(-1)

    # We could Start by including all corner points, but we assume those are in
    # the training_set already
    params_list = []
    while len(params_list) < size:
        PickOnSurface = np.random.choice(
            [0, 1], size=1, p=[1 - surface_prob, surface_prob]
        )[0]
        if PickOnSurface:
            new_params = RandomSurfaceParams(params_boundaries)
        else:
            new_params = RandomBulkParams(params_boundaries)

        # Add new_params only if it is not already in the training set
        # This is mainly an issue in 1D (for the boundary cases)

        training_list_of_tuples = set([tuple(i) for i in training_set])
        if tuple(new_params) not in training_list_of_tuples:
            params_list.append(new_params)

        # remove duplicate element
        params_list_of_tuples = [tuple(i) for i in params_list]
        uniqe_param_list_of_tuples = list(set(params_list_of_tuples))
        params_list = [list(i) for i in uniqe_param_list_of_tuples]

    return np.array(params_list)


def find_greedy_params(
    max_size,
    param_boundaries,
    times,
    min_validation_size=100,
    max_validation_size=500,
    max_error=1e-5,
    atol=1e-5,
    btol=1e-5,
    jobs=16,
):
    training_set = []
    for y in param_boundaries[0]:
        training_set.append([y])

    max_mms = []
    for idx in np.arange(max_size):
        sur_model_og = create_surrogate(training_set, times, atol, btol)
        validation_size = min(
            10 * len(training_set) + min_validation_size, max_validation_size
        )
        # print(training_set, param_boundaries)
        validation_space = GenerateRandomParms(
            validation_size, 0.3, training_set, param_boundaries
        )
        print("This is the validation space",validation_space)

        # print(validation_space)
        def mismatchNew(params):
            y = params[0]
            lens_params = {
                "Ml": 100.0,
                "zl": 0.5,
            }
            print("Actual function:",Ft(y, times, **lens_params))
            print("surrogate evaluated function:",sur_model_og([np.log(y)]))
            return L2(Ft(y, times, **lens_params), sur_model_og([np.log(y)]))

        print("...Validating")
        mismatchNew(validation_space[0])
        mm = Parallel(n_jobs=jobs)(
            delayed(mismatchNew)(params) for params in tqdm(validation_space)
        )
        print("...Validation done")

        greedy_param = validation_space[np.argmax(mm)]
        max_mms.append(max(mm))

        print(f"...Maximum mismatch with {len(training_set)} waveforms is {max(mm)}...")
        if max(mm) < max_error:
            break
        else:
            print("...max_error threshold is not reached. Continuing iterations...")
            training_set.append(greedy_param)
    return training_set, max_mms


def main():
   
    
    
    greedy_params, mismatches = find_greedy_params(
        110, param_boundaries, times, max_error=5e-5, atol=1e-6, btol=1e-6, jobs=16
    )
    print(greedy_params)

    greedy_metadata = {
        "greedy_params": greedy_params,
        "mismatch": mismatches,
    }
    outfile = "greedy_data_4.pkl"
    with open(outfile, "wb") as f:
        pickle.dump(greedy_metadata, f)
    print(f"Greedy params found and saved in {outfile}")

    print("\nGenerating surrogate model")
    t1 = time.perf_counter()
    sur_model_og = create_surrogate(greedy_params, times, atol=1e-6, btol=1e-6)
    t2 = time.perf_counter()
    print(f"Time taken to generate the model= {t2-t1}")
    if not os.path.exists("SURR_dir_FINAL_4/"):
        sur_model_og.save("SURR_dir_FINAL_4/")
        print(f"Surrogate model saved.")
    else:
        print("surrogate model already exists")
    return 


if __name__ == "__main__":
    main()
