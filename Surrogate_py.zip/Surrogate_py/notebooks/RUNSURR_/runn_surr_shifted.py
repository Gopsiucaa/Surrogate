import os
import sys



pysur_path ="/home/gopalprabhu/Desktop/Surrogate--main/Surrogate_project/Surrogate_py/notebooks/"
sys.path.append(pysur_path)
import numpy as np
from joblib import Parallel, delayed
import lal
import pySurrogate as pysur
from tqdm import tqdm
import pickle
import warnings
from multiprocessing import freeze_support
warnings.filterwarnings("always")
from generate_Ft import Ftilde, PointLens
import time
import logging

# Configure logging
logging.basicConfig(
    filename='run_surr.log',  # Specify the log file name
    level=logging.DEBUG,       # Set the logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

Ml=100.0
zl=0.5
y_min = 0.1
y_max = 1.0    #This was changed from 2 to 1
param_boundaries = [[y_min, y_max]]
times = np.arange(0.0, 30.0, 1 / 2048)           






def Ft(y, times, Ml, zl, dt_fac=5.0):
    point_lens = PointLens(y)
    ts = 8 * np.pi * lal.MTSUN_SI * Ml * (1 + zl)
    f_min, f_max = 10.0, 1000.0
    t_max = 30
    wmin = ts * f_min
    wmax = ts * f_max
    dt = min(np.pi / wmax / dt_fac, point_lens.img_td / dt_fac)  ##HAD NOTICED REDUCED ERRORS WITH INCREASED dt
    compute_Ft_params = {
        "lens": point_lens,
        "t_max": t_max,
        "dt": dt,
        "verbose": False,
    }
    t, Ft = Ftilde(**compute_Ft_params)
    FtNew = np.interp(times, t, Ft)
    #logging.debug("Ft calculated to be ", {Ft} )
    return FtNew

'''def t_reference_calculator():
    Ft_ymax=Ft(y_max,times,Ml=100,zl=0.5,dt_fac=5.0)
    max_index=np.argmax(Ft_ymax)
    return times[max_index]

t_reference=t_reference_calculator()

def extended_time():
    Ft_ymin=Ft(y_min,times,100,0.5)
    Ft_min_peak_index=np.argmax(Ft_ymin)
    t_ymin_peak=Ft_ymin[Ft_min_peak_index]
    extended_time_value=np.abs(t_reference-t_ymin_peak)
    return extended_time_value

extended_time_value=extended_time()

new_extended_times=np.arange(0.1,30.0+extended_time_value,1/2048)

def Ft_shifted(y, times,t_ref=t_reference, Ml=100.0, zl=0.5, dt_fac=5.0):   #t_ref=4.58544921875
    print("Ft shifted function called with y =",y)
    point_lens = PointLens(y)
    #print(lal.MTSUN_SI,"<--M_sun", Ml,"<--ML",zl,"<--zl")
    ts = 8 * np.pi * lal.MTSUN_SI * 100.0 * (1 + 0.5)
    f_min, f_max = 10.0, 1000.0
    t_max = 30
    wmin = ts * f_min
    wmax = ts * f_max
    dt = min(np.pi / wmax / dt_fac, point_lens.img_td / dt_fac)  ##HAD NOTICED REDUCED ERRORS WITH INCREASED dt
    compute_Ft_params = {
        "lens": point_lens,
        "t_max": t_max,
        "dt": dt,
        "verbose": False,
    }
    t, Ft = Ftilde(**compute_Ft_params)
    
    FtNew=np.interp(times, t, Ft)
    peak_index=np.argmax(FtNew)
    t_peak=times[peak_index]                                                      #Find the peak time
    t_shift=np.abs(t_ref-t_peak)                                                    #Fine how much to shift the time to align the peak with t_ref
    print("t_shift is:",t_shift)
        
    
    
    Ft_extended=[]
    for time in new_extended_times:
        if time<t_shift:                                              # find t_shift of the rightmost shifted Ft function 
            Ft_extended.extend([0])
        elif time>30.0+t_shift:
            Ft_extended.extend([0])

        else:
            Ft_extended.extend([FtNew[np.argmin(np.abs(times-np.abs((time -t_shift))))]])    
            #print("This is the result of the Ft_extended function:", Ft_extended)
    print("Ft extended was calculated and returned")        
    return Ft_extended'''
 

#---------------------------------------------------------\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\----------------------------------------
times_left=np.arange(0.0, 3.5, 1 / 2048)  

def t_shift_calculator(y):
    ymin_index=np.argmax(Ft(0.1,times,Ml=100,zl=0.5))
    y_index=np.argmax(Ft(y,times,Ml=100,zl=0.5))
    tshift=np.abs(times[ymin_index]-times[y_index])
    return tshift
print(t_shift_calculator(0.9))

tshift_max=t_shift_calculator(1)

def Ft_shifted_left(y, Ml=100.0, zl=0.5, dt_fac=5.0):  
    print("Ft shifted function called with y =",y)
    point_lens = PointLens(y)
    #print(lal.MTSUN_SI,"<--M_sun", Ml,"<--ML",zl,"<--zl")
    ts = 8 * np.pi * lal.MTSUN_SI * 100.0 * (1 + 0.5)
    f_min, f_max = 10.0, 1000.0
    t_max = 3.5+tshift_max
    wmin = ts * f_min
    wmax = ts * f_max
    dt = min(np.pi / wmax / dt_fac, point_lens.img_td / dt_fac)  ##HAD NOTICED REDUCED ERRORS WITH INCREASED dt
    compute_Ft_params = {
        "lens": point_lens,
        "t_max": t_max,
        "dt": dt,
        "verbose": False,
    }
    t, Ft = Ftilde(**compute_Ft_params)
    shifted_time=t_shift_calculator(y)
    adjusted_times=np.arange(0.0+shifted_time, 3.5+shifted_time, 1 / 2048)
    FtNew=np.interp(adjusted_times, t, Ft)
    return FtNew

#---------------------------------------------------------\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\----------------------------------------




def create_surrogate(params, times_left, atol, btol):       ## noticed that atol isnt used anywhere
    print("create_surrogate:  create_surrogate function called")
    print()
    print()
    print()
    sur = pysur.DataModeler(times_left, "LensAmplification")   # new_extended_times to be changed to the restricted time interval
    print("Surrogate created")
    for p in tqdm(params, desc="Training set: "):
    #print("starting loop")
    #for p in params:
        y = p[0]
        print("y =",y ,"create_surrogate:was set equal to the first element of training set")
        lens_params = {
            "Ml": 100.0,
            "zl": 0.5,
            "dt_fac":5.0,
        }
        print(" create surrogate: Ft_shifted function was called")
        data_pre= Ft_shifted_left(y, **lens_params)
        data_post=np.array(data_pre)
        data=data_post.astype(float)
        print("create_surrogate: Ft data was ceated")
    
        
        
        #time_shift=data_pre[1]
        
        sur.addKnownDataSet(np.array([np.log(y)]), data)     #np.log (y) changed to just y 
        print("data set added to sur") 
    print("Creating Empirical Interpolant...")
    sur.createEmpiricalInterpolant(basisTol=btol)
    print("Running GPR fit...")
   
    sur.setupFits(minVals=[np.log(y_min)], maxVals=[np.log(y_max)], fitType="GPR")    ##Could use a different type of fit and try
    sur.fit(nProcs=16)
    print("create surrogate: Surrogate was created and returned")
    print()
    print()
    print()
    
    return sur


def mismatch(original, prediction, frequencies):
    df = frequencies[1] - frequencies[0]
    match = np.abs(np.sum(original * prediction.conjugate())) * df
    norm_original = np.sqrt(np.sum(np.abs(original) ** 2) * df)
    norm_prediction = np.sqrt(np.sum(np.abs(prediction) ** 2) * df)
    mm = 1 - (match / (norm_original * norm_prediction))                   ## Try defining mismatch in some other way
    return mm


def L2(original, prediction):
    diff = np.sqrt(np.sum(np.abs(original - prediction) ** 2))
    norm = np.sqrt(np.sum(np.abs(original) ** 2))
    return diff / norm


def RandomBulkParams(params_boundaries):
    """Generate a random point in Volume"""
    lower_lims = np.array(params_boundaries).T[0]
    upper_lims = np.array(params_boundaries).T[1]
    # NOTE: np.random.uniform is left inclusive and right exclusive,
    # but that's ok here
    return [
        np.random.uniform(low=lower_lims[i], high=upper_lims[i], size=1)[0]
        for i in range(len(lower_lims))
    ]


def RandomSurfaceParams(params_boundaries):
    """Generate a random point on the surface.
    params_boundaries should be of form:
    [[minVal1, maxVal1],[minVal2, maxVal2],...]
    """
    # NOTE: np.random.randint is left inclusive and right exclusive
    # Choose which param to keep const on the surface
    which_param_surface = np.random.randint(low=0, high=len(params_boundaries), size=1)
    # Choose which end of that param
    which_surface_side = np.random.randint(low=0, high=2, size=1)[0]
    surface_params_boundaries = np.delete(
        np.array(params_boundaries), which_param_surface, axis=0
    )
    # Get params for the non-excluded dims using a Bulk param generator
    surface_params = np.array(RandomBulkParams(surface_params_boundaries))
    const_param = params_boundaries[which_param_surface[0]][which_surface_side]
    return np.insert(surface_params, which_param_surface[0], [const_param], axis=0)


def GenerateRandomParms(size, surface_prob, training_set, params_boundaries):
    """Generate *size* number of random parameters withing the parameter
    ranges.
        Generates points on the surface with probability surface_prob.
        Adds only those parameters not already in the training set.
        params_boundaries should be of form:
    [[minVal1, maxVal1],[minVal2, maxVal2],...]
    """

    if surface_prob < 0 or surface_prob > 1:
        print("ERROR: Invalid probability.")
        exit(-1)

    # We could Start by including all corner points, but we assume those are in
    # the training_set already
    params_list = []
    while len(params_list) < size:
        PickOnSurface = np.random.choice(
            [0, 1], size=1, p=[1 - surface_prob, surface_prob]
        )[0]
        if PickOnSurface:
            new_params = RandomSurfaceParams(params_boundaries)
        else:
            new_params = RandomBulkParams(params_boundaries)

        # Add new_params only if it is not already in the training set
        # This is mainly an issue in 1D (for the boundary cases)

        training_list_of_tuples = set([tuple(i) for i in training_set])
        if tuple(new_params) not in training_list_of_tuples:
            params_list.append(new_params)

        # remove duplicate element
        params_list_of_tuples = [tuple(i) for i in params_list]
        uniqe_param_list_of_tuples = list(set(params_list_of_tuples))
        params_list = [list(i) for i in uniqe_param_list_of_tuples]

    return np.array(params_list)

initial_training_set=[0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]

def find_greedy_params(
    max_size,
    param_boundaries,
    times_left,
    min_validation_size=100,
    max_validation_size=200,
    max_error=5e-5,
    atol=1e-6,
    btol=1e-6,
    jobs=16,
):
    training_set = []
    for y in initial_training_set:
        training_set.append([y])

    max_mms = []
    for idx in np.arange(max_size):
        sur_model_og = create_surrogate(training_set, times_left, atol, btol)
        validation_size = min(
            5 * len(training_set) + min_validation_size, max_validation_size
        )
        # print(training_set, param_boundaries)
        validation_space = GenerateRandomParms(
            validation_size, 0.3, training_set, param_boundaries
        )
        print("This is the validation space",validation_space)

        # print(validation_space)
        def mismatchNew(params):
            y = params[0]
            lens_params = {
                "Ml": 100.0,
                "zl": 0.5,
            }
            Ft_og=Ft_shifted_left(y, **lens_params)
            Ft_model=sur_model_og([np.log(y)])
            return L2(Ft_og,Ft_model)+(np.abs(max(Ft_og)-max(Ft_model))/max(Ft_og))

        print("...Validating")
        mismatchNew(validation_space[0])
        mm = Parallel(n_jobs=jobs)(
            delayed(mismatchNew)(params) for params in tqdm(validation_space)
        )
        print("...Validation done")

        greedy_param = validation_space[np.argmax(mm)]
        max_mms.append(max(mm))

        print(f"...Maximum mismatch with {len(training_set)} waveforms is {max(mm)}...")
        if max(mm) < max_error:
            break
        else:
            print("...max_error threshold is not reached. Continuing iterations...")
            training_set.append(greedy_param)
    return training_set, max_mms


def main():
 
    
    
    greedy_params, mismatches = find_greedy_params(
        90, param_boundaries, times_left, max_error=5e-5, atol=1e-6, btol=1e-6, jobs=16
    )
 

    greedy_metadata = {
        "greedy_params": greedy_params,
        "mismatch": mismatches,
    }
    outfile = "truncated_greedy_params_2.pkl"
    with open(outfile, "wb") as f:
        pickle.dump(greedy_metadata, f)
    print(f"Greedy params found and saved in {outfile}")

    print("\nGenerating surrogate model")
    t1 = time.perf_counter()
    sur_model= create_surrogate(greedy_params, times_left, atol=1e-6, btol=1e-6)
   
    t2 = time.perf_counter()
    print(f"Time taken to generate the model= {t2-t1}")
    if not os.path.exists("Truncated_surr_dir_2/"):
        sur_model.save("Truncated_surr_dir_2/")
        print(f"Surrogate model saved.")
    else:
        print("surrogate model already exists")
    return 


if __name__ == "__main__":
    main()