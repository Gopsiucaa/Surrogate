

import os
import sys
from colored import fg
from termcolor import colored
color = fg('blue')

pysur_path ="/home/gopalprabhu/Desktop/Surrogate--main/Surrogate_project/Surrogate_py/notebooks/"
sys.path.append(pysur_path)

import numpy as np
from joblib import Parallel, delayed
import lal
import pySurrogate as pysur
from tqdm import tqdm
import pickle
import warnings
from multiprocessing import freeze_support
warnings.filterwarnings("always")
from generate_Ft import Ftilde, PointLens
import time
import logging

# Configure logging
logging.basicConfig(
    filename='run_surr.log',  # Specify the log file name
    level=logging.DEBUG,       # Set the logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
lens_params = {
        "Ml": 100.0,
        "zl": 0.5,
    }

y_min = 0.1
y_max = 1.0    #This was changed from 2 to 1
param_boundaries = [[y_min, y_max]]
times = np.arange(0.0, 30.0, 1 / 2048)           


def Ft(y, times, Ml, zl, dt_fac=5.0):
    point_lens = PointLens(y)
    ts = 8 * np.pi * lal.MTSUN_SI * Ml * (1 + zl)
    f_min, f_max = 10.0, 1000.0
    t_max = 30
    wmin = ts * f_min
    wmax = ts * f_max
    dt = min(np.pi / wmax / dt_fac, point_lens.img_td / dt_fac)  ##HAD NOTICED REDUCED ERRORS WITH INCREASED dt
    compute_Ft_params = {
        "lens": point_lens,
        "t_max": t_max,
        "dt": dt,
        "verbose": False,
    }
    t, Ft = Ftilde(**compute_Ft_params)
    FtNew = np.interp(times, t, Ft)
    #logging.debug("Ft calculated to be ", {Ft} )
    return FtNew

def t_shift_calculator(y):
    ymin_index=np.argmax(Ft(0.1,times,Ml=100,zl=0.5))
    
    y_index=np.argmax(Ft(y,times,Ml=100,zl=0.5))
    
    tshift=np.abs(times[ymin_index]-times[y_index])
    return y_index-ymin_index
#print(t_shift_calculator(0.339999))

times_left=np.arange(0.0, 3.0, 1 / 2048) 

def Ft_shifted_left(y, Ml=100.0, zl=0.5, dt_fac=20.0):   #t_ref=4.58544921875

    FtNew=Ft(y,times,Ml=100,zl=0.5)
    shifted_time_index=t_shift_calculator(y)
    #adjusted_times=np.arange(0.0+shifted_time, 3.5+shifted_time, 1 /2048) ###
    #Ftfinal=np.interp(adjusted_times, times, FtNew)
    return FtNew[shifted_time_index:shifted_time_index+(3*2048)]

Ft_array=[]
y_array=np.linspace(0.1,1,500)
for i in range(len(y_array)):
    Ft_array.append(Ft_shifted_left(y_array[i],**lens_params))



# Define consecutive mismatch calculator
def consecutive_mismatch_calculator(i):
    
    return L2(Ft_array[i+1],Ft_array[i])


#Define index array 
mm=np.zeros(499)
for i in range(len(mm)):
    print(i)
    mm[i]=consecutive_mismatch_calculator(i)


import numpy as np
import matplotlib.pyplot as plt



# Set the degree of the polynomial fit
degree = 4

# Fit the polynomial
coefficients = np.polyfit(y_array[1:], mm, degree)

# Create a polynomial function using the coefficients
poly_function = np.poly1d(coefficients)

# Generate y_array[1:] values for the fitted polynomial curve
#x_fit = np.linspace(min(y_array[1:]), max(y_array[1:]), 100)

# Calculate mm values using the fitted polynomial function
#y_fit = poly_function(x_fit)
'''plt.figure(dpi=200)
# Plot the original data points and the fitted polynomial curve
plt.scatter(y_array[1:], mm, label='Data Points',s=2)
plt.plot(x_fit, y_fit, label=f'Polynomial Fit (Degree {degree})', color='red')
plt.xlabel('y')
plt.ylabel('Mismatch between consecutive waves')
plt.legend()
plt.show()'''



def greedy_points_calculator(N,ymax=1,ymin=0.1): # Optimize this to include taking input values of y_min and y_max. For now the y range is fixed from 0.1 to 1
    scaled_y_array=np.linspace(0.1,1,N)
    greedy_points=np.zeros_like(scaled_y_array)
    greedy_points[0]=0.1
    y_range=(ymax-ymin)
    mm_range=max(mm)-min(mm)

    for i in range(len(scaled_y_array)-1):
        mm_scale_factor= np.abs(poly_function(scaled_y_array[N-(i+2)])-poly_function(scaled_y_array[N-(i+1)])    )
        greedy_points[i+1]=greedy_points[i]+ (y_range*mm_scale_factor/mm_range)
        greedy_scale_factor=y_max/max(greedy_points)
        greedy_points=greedy_points*greedy_scale_factor
    return greedy_points    

greedy_points=greedy_points_calculator(100)

def create_surrogate(params, times, atol, btol):       ## noticed that atol isnt used anywhere
    #print("create_surrogate function called")
    sur = pysur.DataModeler(times, "LensAmplification")
    #print("Surrogate created")
    for p in tqdm(params, desc="Training set: "):
    #print("starting loop")
    #for p in parms:
        y = p
        #print("y =",y ,"was set equal to the first element of training set")
        lens_params = {
            "Ml": 100.0,
            "zl": 0.5,
        }
        data = Ft_shifted_left(y, times_left, **lens_params)
        #print("Ft data generated")
        sur.addKnownDataSet(np.array([y]), data)     #np.log (y) changed to just y 
        #print("data set added to sur") 
    print("Creating Empirical Interpolant...")
    sur.createEmpiricalInterpolant(basisTol=btol)
    print("Running GPR fit...")
   
    sur.setupFits(minVals=[np.log(y_min)], maxVals=[np.log(y_max)], fitType="GPR")    ##Could use a different type of fit and try
    sur.fit(nProcs=16)
    print("Surrogate was created and returned")
    return sur
"""GPR works better if the prediciton point is close to other points

 """

def mismatch(original, prediction, frequencies):
    df = frequencies[1] - frequencies[0]
    match = np.abs(np.sum(original * prediction.conjugate())) * df
    norm_original = np.sqrt(np.sum(np.abs(original) ** 2) * df)
    norm_prediction = np.sqrt(np.sum(np.abs(prediction) ** 2) * df)
    mm = 1 - (match / (norm_original * norm_prediction))                   ## Try defining mismatch in some other way
    return mm


def L2(original, prediction):
    diff = np.sqrt(np.sum(np.abs(original - prediction) ** 2))
    norm = np.sqrt(np.sum(np.abs(original) ** 2))
    return diff / norm



def main():
    
    
    
    


    greedy_metadata = {
        "greedy_params": greedy_points,
        
    }
    outfile = "greedy_data_mismatch_density.pkl"
    with open(outfile, "wb") as f:
        pickle.dump(greedy_metadata, f)
    print(f"Greedy params found and saved in {outfile}")

    print("\nGenerating surrogate model")
    t1 = time.perf_counter()
    sur_model = create_surrogate(greedy_points, times_left, atol=1e-2, btol=1e-2)
    t2 = time.perf_counter()
    print(f"Time taken to generate the model= {t2-t1}")
    if not os.path.exists("Consecutive_mismatch_surrogate/"):
        #os.mkdir("Compare_surr_dir_2/")
        sur_model.save("Consecutive_mismatch_surrogate/")
        print(f"Surrogate model saved.")
    else:
        print("'Consecutive_mismatch_surrogate' directory not found.")
    return 


if __name__ == "__main__":
    main()
