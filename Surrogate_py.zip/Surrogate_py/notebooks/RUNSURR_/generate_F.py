#__author__ = "Deka, U."

import pyfftw
import numpy as np
import matplotlib.pyplot as plt
import sys
import lal
import time
import os
import timeit
import math
import scipy.fft as sfft
from pycbc import types
from pycbc.types import frequencyseries
from pycbc.types import timeseries
## UNCOMMENT THE FOLLOWING IF YOU HAVE THE LOOKUP TABLE FILE
# from isolated_lens_ampfac import ampfac_hybrid
# import pickle
# from plotsettings import plotsettings
# plotsettings(col=True)
# hyp_fn_intp = "/home/uddeepta.deka/data/intrp_cubic_hyp1f1_data_Ngrid3000x10000.pkl"
# open_file = open(hyp_fn_intp, "rb")
# intrp_hyp1f1 = pickle.load(open_file)
# open_file.close()


class PointLens(object):
    """
    Class defining an isolated point mass lens at the origin
    params:
    ---------------
    y: dimensionless impact parameter
    """

    def __init__(self, y):
        self.y1 = y
        self.y2 = 0.0
        self.img = self.imageLocations()
        self.img_mag = self.magnification(self.img[0], self.img[1])
        self.img_midx = self.morseIdx()
        abs_img_td = self.timeDelay(self.img[0], self.img[1])
        self.img_td = abs(abs_img_td[1] - abs_img_td[0])

    def potential(self, x1, x2):
        """Lensing potential at (x1, x2)"""
        return np.log(np.sqrt(x1 * x1 + x2 * x2))

    def timeDelay(self, x1, x2, minimize=False):
        """
        Returns the absolute time delay at lens plane coordinate (x1, x2)
        Eqn 7, Diego et al 2019 A&A.
        params
        ---------------
        dim: dimensionless timedelay if False
        minimize: Time delay w.r.t. the global minima if True
        """
        td_ = 0.5 * ((x2 - self.y2) ** 2 + (x1 - self.y1) ** 2) - self.potential(x1, x2)
        if minimize:
            td_ -= td_.min()
        return td_
    def imageLocations(self):
        """
        Returns the analytically found image locations
        in the format: x1list, x2list
        """
        x_image = np.zeros(shape=(2, 2))
        y_1 = np.sqrt(self.y1**2 + self.y2**2)
        y_2 = np.sqrt(4.0 + self.y1**2 + self.y2**2)
        x_image[0] = [
            0.5 * self.y1 * (1 - (y_2 / y_1)),
            0.5 * self.y1 * (1 + (y_2 / y_1)),
        ]
        x_image[1] = [
            0.5 * self.y2 * (1 - (y_2 / y_1)),
            0.5 * self.y2 * (1 + (y_2 / y_1)),
        ]
        return x_image

    def magnification(self, x1, x2):
        """Returns the magnification at (x1, x2)"""
        xn = (x1 * x1 + x2 * x2) ** 2
        return xn / (xn - 1)

    def morseIdx(self):
        """Returns the morse idx for the images"""
        res = []
        for m in self.img_mag:
            if m < 0:
                res.append(0.5)
            else:
                res.append(0.0)
        return res

    def alpha(self, x1, x2):
        """Deflection angle as a function of the coordinates (x1, x2)"""
        a1 = x1 / (x1 * x1 + x2 * x2)
        a2 = x2 / (x1 * x1 + x2 * x2)
        return a1, a2

    def gradTimeDelay(self, x1, x2):
        """Returns dTdx1, dTdx2 as function of coordinates (x1, x2)"""
        x_ = x1**2 + x2**2
        dtdx1 = x1 * (1.0 - 1.0 / x_) - self.y1
        dtdx2 = x2 * (1.0 - 1.0 / x_) - self.y2
        return dtdx1, dtdx2


def Ftilde(lens, t_max, dt, verbose):
    """Computing the raw F(t)"""
    x_max = np.sqrt(2.0 * t_max)
    x_max += 0.5 * np.log(x_max)
    dtdx1, dtdx2 = lens.gradTimeDelay(x_max, x_max)
    dx1 = dt / dtdx1
    dx2 = dt / dtdx2
    x1_ = np.arange(-x_max + lens.y1, x_max + lens.y1, dx1)
    x2_ = np.arange(-x_max + lens.y2, x_max + lens.y2, dx2)
    X1, X2 = np.meshgrid(x1_, x2_)
    td_samples = lens.timeDelay(X1, X2, minimize=True).ravel()
    bins = int(max(td_samples) / dt)
    td_hist, bin_edges = np.histogram(td_samples, bins=bins)
    t_mid = (bin_edges[1:] + bin_edges[:-1]) / 2.0
    Ft = dx1 * dx2 * td_hist / dt / 2.0 / np.pi
    if verbose:
        print(f"x_max = {x_max} | t_max = {t_max} | dx1 = {dx1}, dx2 = {dx2}")
        print(f"Number of td samples = {len(td_samples)}")
    cutidx = np.where(t_mid > t_max)[0][0]
    return t_mid[:cutidx], Ft[:cutidx]

def sigmoid(xvec, xshift=0.0, xscaling=1.0, yscaling=1.0):
    """Returns the `modified` sigmoid function"""
    yvec = 1 / (1 + np.exp(-xscaling * (xvec + xshift)))
    if np.sign(yscaling) == -1:
        yvec = yscaling * yvec - yscaling
        yvec -= yvec[-1]
    else:
        yvec = yscaling * yvec
        yvec -= yvec[0]
    return yvec


def modify_Ft(
    t, Ft, t_len_fac=5.0, stiffness=0.2, asymp_pad=True, zero_pad=True, exp_fac=3
):
    """
    It modifies the F(t) values by:
    - padding with the asymptotic value of F(t) if asymp_pad=True
      (it assumes that F(t) has reached an asymptotic value)
    - tapering with sigmoid
    - padding with zeros if zero_pad=True
    Returns the modified t, Ft
    """
    dt = t[1] - t[0]
    tf = t[-1]
    if asymp_pad:
        # pad with the asymptotic values
        pad_len = int(0.5 * len(Ft))
        Ft = np.pad(Ft, (0, pad_len), "constant", constant_values=(0, Ft[-1]))
        tf = t[0] + dt * len(Ft)
    # Here we add the sigmoid at large time delay
    x_ = np.arange(tf, t_len_fac * tf, dt)
    y_ = sigmoid(x_, xscaling=stiffness, xshift=-0.5 * (x_[-1] + tf), yscaling=-Ft[-1])
    t_mod = np.arange(t[0], x_[-1], dt)
    Ft_mod = np.concatenate((Ft, y_[:-1]))
    if zero_pad:
        expon = math.ceil(math.log(len(t_mod), 2))
        pad_len = int(2 ** (expon + exp_fac)) - len(t_mod)
        Ft_mod = np.pad(Ft_mod, (0, pad_len), "constant", constant_values=(0, 0))
        t_mod = np.linspace(t_mod[0], t_mod[0] + dt * len(Ft_mod), len(Ft_mod))
    return t_mod, Ft_mod


def ampFac(t, Ft):
    """
    Returns the angular frequency (dimensionless)
    and amplification factor
    Input params:
    ---------------
    t: time array
    Ft: time series data
    """
    
    fft_ = np.fft.rfft(Ft) * (t[1] - t[0])
    

    freq_ = np.fft.rfftfreq(len(t), t[1] - t[0]) * 2.0 * np.pi
    
    ampfac = fft_ * freq_ * 1j
    ampfac = np.conj(ampfac) * np.exp(1j * freq_ * t[0])
    return freq_, ampfac

def ampFac_2(t, Ft):
    """
    Returns the angular frequency (dimensionless)
    and amplification factor
    Input params:
    ---------------
    t: time array
    Ft: time series data
    """
    #print("This is the time array:",t)
    #print("This is the Ft array:",Ft)
    fft_ = pyfftw.interfaces.numpy_fft.rfft(Ft) * (t[1] - t[0])
    #print("This is t[o]:",t[0])

    freq_ = pyfftw.interfaces.numpy_fft.rfftfreq(len(t), t[1] - t[0]) * 2.0 * np.pi
    #print("This is the fft frequency samples",freq_)
    ampfac = fft_ * freq_ * 1j
    ampfac = np.conj(ampfac) * np.exp(1j * freq_ * t[0])
    return freq_, ampfac

def ampFac_3(t,Ft):
 # Byte-aligned inputs are supposedly faster
 in_array = pyfftw.empty_aligned(len(Ft), dtype=np.float64)
 
 # Required, even if we don't explicitly reference it again
 out_array = pyfftw.empty_aligned(len(Ft)//2 + 1, dtype=np.complex128)

 fftw_object = pyfftw.FFTW(in_array,
                          out_array,
                          direction="FFTW_FORWARD",
                          flags=("FFTW_ESTIMATE", ),
                          threads=1)
 np_total = 0
 fftw_total = 0
 



 in_array=Ft
 # Numpy
 np_start = time.perf_counter()
 np_output = np.fft.rfft(in_array)
 np_total += time.perf_counter() - np_start 
 # FFTW
 fftw_start = time.perf_counter()
 fftw_output = fftw_object(in_array)
 fftw_total += time.perf_counter() - fftw_start 
 # Show that Numpy and FFTW give the same answers
 np.testing.assert_allclose(np_output, fftw_output) 
 # Remind ourselves that FFTW has modified and returned out_array
 assert fftw_output is out_array
 freq_ = np.fft.rfftfreq(len(t), t[1] - t[0]) * 2.0 * np.pi
 print("np total:", np_total)
 print("fftw total:", fftw_total)
 return freq_,fftw_output


def ampFac_4(t,Ft):
 Ft_object = types.TimeSeries(Ft, delta_t =t[1]-t[0]) 
 # perform FFT                                                                                                          # THIS FUNCTION CALCULATES THE FOURIER TRANSFORM OF FT USING PYCBC
 fft=Ft_object.to_frequencyseries()

 
 
 
# def remove_saddle(lens, t, Ft):
#     """ Removes the contribution of the saddle image. """
#     print("Removing the saddle contribution...")
#     return np.exp(-Ft)
    
def usage():
    print(
        "Computes the lensing amplification factor in time domain due to a point mass lens."
    )
    print("")
    print("The following options can be used to overwrite default parameters")
    print("\t-y: Impact parameter, assuming y2=0 [Default: 0.1]")
    print("\t-t_max: max absolute time to integrate [Default: 30]")
    print("\t-Ml: lens mass in solar mass units [Default: 100]")
    print("\t-zl: lens redshift [Default: 0.5]")
    print("\t-verbose: flag to print output")
    print("\t-dt_fac: Factor to downscale time spacing [Default: 7.5]")
    print("\t-f_min: Minimum frequency to be resolved in freq. domain [default: 18]")
    print("\t-f_max: Maximum frequency to be resolved in freq. domain [default: 1000]")
    print(
        "\t-folder_path: Relative path to the folder to store results [default: Ft_data]"
    )


def main():
    print(" --------------------------------------------------------")
    print(" -- generate_Ft.py --- use flag -h for list of options --")
    print(" --------------------------------------------------------")
    # set default values for variables
    # impact parameter
    y = 0.1
    # integrate to time t_max
    t_max = 30.0
    # lens mass
    Ml = 300.0
    # lens redshift
    zl = 0.5
    # print output
    verbose = False
    # dt factor
    dt_fac = 5
    # minimum frequency
    f_min = 10.0
    # maximum frequency
    f_max = 1000.0
    # folder path
    folder_path = os.getcwd() + "/Ft_data/"
    print("The lens mass is:", Ml)

    # now look for flags to overwrite default values
    #
    for i in range(len(sys.argv)):
        if sys.argv[i] == "-h":
            usage()
            return
        if sys.argv[i] == "-y":
            y = float(sys.argv[i + 1])
        if sys.argv[i] == "-t_max":
            t_max = float(sys.argv[i + 1])
        if sys.argv[i] == "-Ml":
            Ml = float(sys.argv[i + 1])
        if sys.argv[i] == "-zl":
            zl = float(sys.argv[i + 1])
        if sys.argv[i] == "-verbose":
            verbose = True
        if sys.argv[i] == "-dt_fac":
            dt_fac = float(sys.argv[i + 1])
        if sys.argv[i] == "-f_min":
            f_min = float(sys.argv[i + 1])
        if sys.argv[i] == "-f_max":
            f_max = float(sys.argv[i + 1])
        if sys.argv[i] == "-folder_path":
            folder_path = os.getcwd() + "/" + str(sys.argv[i + 1]) + "/"
    isExist = os.path.exists(folder_path)
    if not isExist:
        os.makedirs(folder_path)
        print("Created new folder to store data.")
    start = time.perf_counter()
    lens = PointLens(y)
    
    t_sec = 8 * np.pi * lal.MTSUN_SI * Ml * (1 + zl)
    wmin = t_sec * f_min
    wmax = t_sec * f_max
    dt = min(np.pi / wmax / dt_fac, lens.img_td / dt_fac)
    t, Ft = Ftilde(lens, t_max, dt, verbose)
    end = time.perf_counter()

    ### Adding the sigmoid tapering
    modify_start=time.perf_counter()
    t_mod, Ft_mod = modify_Ft(t, Ft)
    modify_end=time.perf_counter()
    #end=time.time()
    print("Time taken to modify Ft is:", modify_end-modify_start)
    print(len(t_mod),"This is the length of time array")

    #Create the FFT object for pycbc 
   

    FFT_start= time.perf_counter()
    ws, ampfac_num = ampFac(t_mod, Ft_mod)                                                     #Replace this line with the pycbc code
    FFT_end=time.perf_counter()

    FFTW_start= time.perf_counter()
    ws, ampfac_num = ampFac_2(t_mod, Ft_mod)
    FFTW_end=time.perf_counter()    
    print("Time taken to do the FFT is:",FFT_end-FFT_start)
    print("Time taken to do the FFTW is:",FFTW_end-FFTW_start)
    idxs = (ws >= wmin) & (ws <= wmax)
    ws = ws[idxs]
    freqs = ws / t_sec
    
    
    # Doing the FFT
    ampfac_num = ampfac_num[idxs]
    
    # ampfac_ana = ampfac_hybrid(ws, y, intrp_hyp1f1=intrp_hyp1f1)
    
    
    
    fig, ax = plt.subplots(nrows=1, ncols=3, figsize=(18, 4))
    
    ax[0].plot(t, Ft, lw=5, ls='-', alpha=0.5, label='vanilla')
    ax[0].plot(t_mod, Ft_mod, label='sigmoid tapering')
    ax[0].legend()
    ax[0].set_xlabel(r"$t$")
    ax[0].set_ylabel(r"$\widetilde{F}(t)$")
    ax[0].set_xscale("log")
    
    # ax[1].plot(freqs, np.abs(ampfac_ana), lw=5, ls='-', alpha=0.5, label='analytic')
    ax[1].plot(freqs, np.abs(ampfac_num), label='numeric')
    ax[1].legend()
    ax[1].set_xlabel(r"$f$[Hz]")
    ax[1].set_ylabel(r"$|F(f)|$")
    ax[1].set_xscale("log")
    
    # ax[2].plot(freqs, np.angle(ampfac_ana), lw=5, ls='-', alpha=0.5, label='analytic')
    ax[2].plot(freqs, np.angle(ampfac_num), label='numeric')
    ax[2].legend()
    ax[2].set_xlabel(r"$f$[Hz]")
    ax[2].set_ylabel(r"arg$(F(f))$")
    ax[2].set_xscale("log")
    
    pngfile = folder_path + "Ft_ampfac_joint_plot.png"
    plt.tight_layout()
    plt.savefig(pngfile, bbox_inches="tight", dpi=200)
    
    Ft_datafile = folder_path + "Ft_data.txt"
    header = f"Created using generate_Ft.py\nUsage: \nimport numpy as np\ndata = np.loadtxt('{Ft_datafile}')\nt = data[:,0]\nFt = data[:,1]\n"
    np.savetxt(Ft_datafile, np.array([t, Ft]).T, header=header)
    
    # Ff_datafile = folder_path + "Ff_data.txt"
    # usage_statement = f"Usage:\n===============\nimport numpy as np\ndata = np.loadtxt('{Ff_datafile}', dtype='complex')\nws = np.abs(data[:,0])\nfs = np.abs(data[:,1])\nFf_num = data[:,2]\nFf_ana = data[:,3]\n"
    # with open(Ff_datafile, 'w') as f:
    #     np.savetxt(f, np.array([ws, freqs, ampfac_num, ampfac_ana]).T, header=header+usage_statement)
    
    print(f"Data saved in {folder_path}\nTime taken: {end-start}s.\n")

if __name__ == "__main__":
    main()