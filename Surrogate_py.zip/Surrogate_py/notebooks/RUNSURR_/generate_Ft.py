import numpy as np
import matplotlib as plt
import sys
import lal
import time

class PointLens(object):
    """
    Class defining an isolated point mass lens at the origin
    params: 
    ---------------
    y: dimensionless impact parameter
    """
    def __init__(self, y):
        self.y1 = y
        self.y2 = 0.
        self.img = self.imageLocations()
        self.img_mag = self.magnification(self.img[0], self.img[1])
        self.img_midx = self.morseIdx()
        abs_img_td = self.timeDelay(self.img[0], self.img[1])
        self.img_td = abs(abs_img_td[1]-abs_img_td[0])
    
    def potential(self, x1, x2):
        """ Lensing potential at (x1, x2) """
        return np.log(np.sqrt(x1 * x1 + x2 * x2))

    def timeDelay(self, x1, x2, minimize=False):
        """
        Returns the absolute time delay at lens plane coordinate (x1, x2)
        Eqn 7, Diego et al 2019 A&A.
        params
        ---------------
        dim: dimensionless timedelay if False
        minimize: Time delay w.r.t. the global minima if True
        """
        td_ = (0.5 * ((x2 - self.y2) ** 2 + (x1 - self.y1) ** 2) - self.potential(x1, x2))
        if minimize:
            td_ -= td_.min()
        return td_
    
    def imageLocations(self):
        """ 
        Returns the analytically found image locations
        in the format: x1list, x2list
        """
        x_image = np.zeros(shape=(2,2))
        y_1 = np.sqrt(self.y1**2 + self.y2**2)
        y_2 = np.sqrt(4. + self.y1**2 + self.y2**2)
        x_image[0] = [0.5 * self.y1 * (1 - (y_2 / y_1)), 
                      0.5 * self.y1 * (1 + (y_2 / y_1))]
        x_image[1] = [0.5 * self.y2 * (1 - (y_2 / y_1)), 
                      0.5 * self.y2 * (1 + (y_2 / y_1))]
        return (x_image)
    
    def magnification(self, x1, x2):
        """ Returns the magnification at (x1, x2) """
        xn = (x1 * x1 + x2 * x2) **2
        return xn / (xn - 1)
    
    def morseIdx(self):
        """ Returns the morse idx for the images """
        res = []
        for m in self.img_mag:
            if m<0:
                res.append(0.5)
            else: 
                res.append(0.)
        return res
    
    def alpha(self, x1, x2):
        """ Deflection angle as a function of the coordinates (x1, x2) """
        a1 = x1 / (x1 * x1 + x2 * x2)
        a2 = x2 / (x1 * x1 + x2 * x2)
        return a1, a2
    
    def gradTimeDelay(self, x1, x2):
        """ Returns dTdx1, dTdx2 as function of coordinates (x1, x2) """
        x_ = x1 ** 2 + x2 ** 2
        dtdx1 = x1 * (1. - 1. / x_) - self.y1
        dtdx2 = x2 * (1. - 1. / x_) - self.y2
        return dtdx1, dtdx2
    
def Ftilde(lens, t_max, dt, verbose):
    """ Computing the raw F(t) """
    x_max = np.sqrt(2. * t_max)
    x_max += 0.5 * np.log(x_max)
    dtdx1, dtdx2 = lens.gradTimeDelay(x_max, x_max)
    dx1 = dt / dtdx1
    dx2 = dt / dtdx2
    x1_ = np.arange(-x_max+lens.y1, x_max+lens.y1, dx1)
    x2_ = np.arange(-x_max+lens.y2, x_max+lens.y2, dx2)
    X1, X2 = np.meshgrid(x1_, x2_)
    td_samples = lens.timeDelay(X1, X2, minimize=True).flatten()
    bins = int(max(td_samples)/dt)
    td_hist, bin_edges = np.histogram(td_samples, bins=bins)
    t_mid = (bin_edges[1:] + bin_edges[:-1]) / 2.
    Ft = dx1 * dx2 * td_hist / dt / 2. / np.pi
    if verbose:
        print(f"x_max = {x_max} | t_max = {t_max} | dx1 = {dx1}, dx2 = {dx2}")
        print(f"Number of td samples = {len(td_samples)}")
    cutidx = np.where(t_mid>t_max)[0][0]
    return t_mid[:cutidx], Ft[:cutidx]



def usage():
    print("Computes the lensing amplification factor in time domain due to a point mass lens.")
    print("")
    print("The following options can be used to overwrite default parameters")
    print("\t-y: Impact parameter, assuming y2=0 [Default: 0.1]")
    print("\t-t_max: max absolute time to integrate [Default: 30]")
    print("\t-Ml: lens mass in solar mass units [Default: 100]")
    print("\t-zl: lens redshift [Default: 0.5]")
    print("\t-verbose: flag to print output")
    print("\t-dt_fac: Factor to downscale time spacing [Default: 7.5]")
    print("\t-f_max: Maximum frequency to be resolved in freq. domain [default: 1000]")



def main(y):
    
    # set default values for variables
    # impact parameter
    #y=0.1
    # integrate to time t_max
    t_max = 30.
    # lens mass
    Ml = 100.
    # lens redshift
    zl = 0.5
    # print output
    verbose = False
    # dt factor
    dt_fac = 5  #this was changed from 7.5 to 10
    # maximum frequency
    f_max = 1000.

    # now look for flags to overwrite default values
    #
    for i in range(len(sys.argv)):
        if sys.argv[i] == "-h":
            usage()
            return
        if sys.argv[i] == "-y":
            y = float(sys.argv[i+1])
        if sys.argv[i] == "-t_max":
            t_max = float(sys.argv[i+1])
        if sys.argv[i] == "-Ml":
            Ml = float(sys.argv[i+1])
        if sys.argv[i] == "-zl":
            zl = float(sys.argv[i+1])
        if sys.argv[i] == "-verbose":
            verbose = True
        if sys.argv[i] == "-dt_fac":
            dt_fac = float(sys.argv[i+1])
        if sys.argv[i] == "-f_max":
            f_max = float(sys.argv[i+1])
    start = time.perf_counter()
    lens = PointLens(y)
    t_sec = 8*np.pi * lal.MTSUN_SI * Ml * (1+zl)
    wmax = t_sec * f_max
    dt = min(np.pi/wmax/dt_fac, lens.img_td/dt_fac)
    #dt = np.pi/wmax/dt_fac
    t, Ft = Ftilde(lens, t_max, dt, verbose)
    return t,Ft
    
    #np.savetxt("data_matrix.txt", np.c_[t,Ft])
    




   
     


#end = time.perf_counter()
    
   

#if  __name__ == '__main__':
#    main()
#if __name__ == '__main__':
#   y_value =  # Set the value of y you want to use
#  main(y_value)